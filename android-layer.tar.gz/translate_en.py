#!/usr/bin/env python3
"""Translate the Chinese UI strings of the PhotoCraft Android port to English.

Run from the repository root, before building. It rewrites exact string literals
in a few source files, so the repo itself stays identical to the original and
"Sync fork" keeps working. Re-running it is harmless.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Exact string literals ("..." in Rust and Java). Replaced including the quotes,
# so substrings of longer sentences are never touched by accident.
LITERALS = {
    # --- apps/photocraft-android/src/android.rs ---
    "字体文件不能超过 32 MiB": "Font file must be 32 MiB or smaller",
    "无法识别字体，请选择 TTF、OTF 或 TTC 字体": "Font not recognised. Choose a TTF, OTF or TTC font",
    "已导入字体：{}": "Imported font: {}",
    "设置": "Settings",
    "新建": "New",
    "文件管理 / 打开": "Files / Open",
    "保存": "Save",
    "另存": "Save As",
    "撤销": "Undo",
    "重做": "Redo",
    "适合屏幕": "Fit",
    "文件管理": "Files",
    "图层": "Layers",
    "选项": "Options",
    "文字工具": "Text tool",
    "输入 / 编辑文字": "Type / edit text",
    "上传字体": "Upload font",
    # --- pixel pencil ---
    "像素铅笔": "Pixel pencil",
    "整像素绘制 · 无抗锯齿": "Whole-pixel drawing, no anti-aliasing",
    "自动擦除": "Auto erase",
    "双指放大画布后更方便逐像素绘制": "Pinch to zoom the canvas for pixel-level drawing",
    # --- file_browser.rs ---
    "作品.psd": "Artwork.psd",
    "我的作品.psd": "My Artwork.psd",
    "作品": "Artwork",
    "选择文件夹": "Choose folder",
    "另存为": "Save As",
    "选择字体": "Choose font",
    "文件管理器": "File manager",
    "← 返回": "← Back",
    "刷新": "Refresh",
    "添加手机目录": "Add phone folder",
    "系统选择器": "System picker",
    "搜索当前目录": "Search this folder",
    "新建文件夹": "New folder",
    "已选 {} 个文件": "{} file(s) selected",
    "正在读取…": "Loading…",
    "目录": "Folder",
    "文件": "File",
    "{} 字节": "{} bytes",
    "重命名": "Rename",
    "删除": "Delete",
    "当前目录没有匹配的文件": "No matching files in this folder",
    "文件名（通过后缀选择格式）": "File name (the extension picks the format)",
    "文件名": "File name",
    "文件夹名称": "Folder name",
    "新名称": "New name",
    "输入名称": "Enter name",
    "确认名称": "Confirm name",
    "取消修改": "Cancel",
    "{}「{}」？": "{} '{}'?",
    "确认删除": "Confirm delete",
    "覆盖已有文件": "Overwrite existing file",
    "确认": "Confirm",
    "取消操作": "Cancel",
    "关闭": "Close",
    "选择此文件夹": "Use this folder",
    "保存到此目录": "Save here",
    "打开所选文件": "Open selected",
    # --- panels.rs / links.rs / menus.rs ---
    "QQ 社群": "QQ group",
    "左滑多选 · 已选 {} 层": "Swipe left to multi-select · {} layer(s) selected",
    "长按后拖动排序 · 拖到项目标签复制": "Long-press and drag to reorder · drop on a tab to copy",
    "加入我们的 QQ 社群": "Join our QQ group",
    "QQ群号：{COMMUNITY_GROUP}（可在 QQ 中搜索加入）": "QQ group number: {COMMUNITY_GROUP} (search for it in QQ)",
    "加入 QQ 社群（1129505510）…": "Join QQ group (1129505510)…",
    "{}（{}）": "{} ({})",
    # --- prefs_ui.rs (UI size) ---
    "界面设置": "Interface settings",
    "UI 大小": "UI size",
    "缩小 UI": "Smaller UI",
    "放大 UI": "Larger UI",
    "第 {} / 10 档 · {:.0}%": "Level {} / 10 · {:.0}%",
    "恢复默认（第 5 档）": "Reset to default (level 5)",
    "1～10 档，默认第 5 档。修改即时生效并自动保存。": "Levels 1-10, default 5. Changes apply instantly and are saved automatically.",
    # --- type_tool.rs (floating text toolbar) ---
    "左对齐": "Left",
    "居中": "Center",
    "右对齐": "Right",
    "完成": "Done",
    "撤销输入": "Undo typing",
    # --- Java: FileBrowserBridge.java ---
    "无法创建作品目录": "Cannot create the works folder",
    "目录不在授权范围内": "Folder is outside the authorised area",
    "请重新添加目录，授予访问权限": "Please add the folder again to grant access",
    "文件名称无效": "Invalid file name",
    "手机目录": "Phone folder",
    "无法读取目录": "Cannot read folder",
    "目录文件过多，请使用更小的子目录": "Too many files in this folder, use a smaller subfolder",
    "目录提供程序未返回文件列表": "The folder provider returned no file list",
    "应用作品": "App works",
    "同名文件或文件夹已存在": "A file or folder with this name already exists",
    "创建失败": "Create failed",
    "目录提供程序未创建文件": "The folder provider did not create the file",
    "请选择 1～16 个文件": "Select 1-16 files",
    "此批处理功能需要应用作品目录；手机目录中的单文件仍可正常打开与保存":
        "Batch operations need the app works folder; single files in phone folders still open and save normally",
    "请选择文件夹": "Please choose a folder",
    "同名项是文件夹，请更换文件名": "An item with this name is a folder, choose another name",
    "同名项已存在": "An item with this name already exists",
    "重命名失败": "Rename failed",
    "删除失败；请先清空文件夹": "Delete failed; empty the folder first",
    "请先清空文件夹": "Empty the folder first",
    "不能删除授权目录本身": "Cannot delete the authorised folder itself",
    "删除失败": "Delete failed",
    "未知文件操作": "Unknown file operation",
    # --- Java: PhotoCraftActivity.java ---
    "输入文字": "Enter text",
    "应用": "Apply",
    "取消": "Cancel",
    "确定": "OK",
    "文件操作失败：": "File operation failed: ",
    "原文件没有写入权限或授权已失效，保存未完成。请重新打开文件授权，或使用另存为。":
        "No write permission for the original file, or access has expired, so the save did not finish. Re-open the file to grant access, or use Save As.",
    "保存未完成：": "Save did not finish: ",
    "复制群号": "Copy group number",
    "QQ群号": "QQ group number",
}

# Raw substring replacements for text that sits inside longer or escaped literals.
SUBSTRINGS = {
    r'QQ群号：1129505510\n请在 QQ 中搜索群号申请加入。': r'QQ group number: 1129505510\nSearch for it in QQ to join.',
    r'\"文件操作失败\"': r'\"File operation failed\"',
}

FILES = [
    "apps/photocraft-android/src/android.rs",
    "apps/photocraft-android/src/pixel_pencil.rs",
    "apps/photocraft-android/src/file_browser.rs",
    "apps/photocraft-android/src/documents/tests.rs",
    "packaging/android/java/ai/storyteller/photocraft/FileBrowserBridge.java",
    "packaging/android/java/ai/storyteller/photocraft/PhotoCraftActivity.java",
    "crates/ui-egui/src/panels.rs",
    "crates/ui-egui/src/links.rs",
    "crates/ui-egui/src/menus.rs",
    "crates/ui-egui/src/prefs_ui.rs",
    "crates/ui-egui/src/type_tool.rs",
]

CJK = re.compile(r"[\u4e00-\u9fff]")


def main() -> int:
    changed = 0
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"skip (missing): {rel}")
            continue
        text = path.read_text(encoding="utf-8")
        original = text
        # Longest literals first so a short key never pre-empts a longer one.
        for zh in sorted(LITERALS, key=len, reverse=True):
            text = text.replace(f'"{zh}"', f'"{LITERALS[zh]}"')
        for zh, en in SUBSTRINGS.items():
            text = text.replace(zh, en)
        # Single-character helper used in the pixel-pencil title, e.g. "{}（{}）".
        if text != original:
            path.write_text(text, encoding="utf-8")
            changed += 1
            print(f"translated: {rel}")

    # Report anything still Chinese inside a string literal (informational only).
    lit = re.compile(r'"((?:[^"\\]|\\.)*)"')
    leftovers = []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            continue
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            for m in lit.finditer(line):
                if CJK.search(m.group(1)):
                    leftovers.append(f"{rel}:{n}: {m.group(1)[:60]}")
    print(f"\n{changed} file(s) changed.")
    if leftovers:
        print("Still Chinese (tests/sample data are fine to leave):")
        for item in leftovers:
            print("  " + item)
    return 0


if __name__ == "__main__":
    sys.exit(main())
