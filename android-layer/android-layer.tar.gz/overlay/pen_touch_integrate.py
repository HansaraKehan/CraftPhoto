#!/usr/bin/env python3
"""Hook the Pen & Touch module into upstream PhotoCraft.

Anchor-based and idempotent: each edit finds one known line and inserts next to it, so it keeps
working when upstream moves code around. If an anchor disappears the build stops with a clear
message instead of silently dropping a feature.
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
UI = ROOT / "crates/ui-egui/src"
failures = []


def replace(path, old, new, marker, required=True):
    p = ROOT / path
    s = p.read_text()
    if marker in s:
        return
    if s.count(old) != 1:
        if required:
            failures.append(f"{path}: anchor found {s.count(old)} times: {old!r}")
        return
    p.write_text(s.replace(old, new))


L = "crates/ui-egui/src/lib.rs"
A = "crates/ui-egui/src/app.rs"
F = "crates/ui-egui/src/app/frame.rs"
replace(L, "pub mod panels;", "pub mod panels;\npub mod pen_touch;", "pub mod pen_touch;")
replace(L, "pub(crate) prefs_rt: prefs_ui::Runtime,",
        "pub(crate) prefs_rt: prefs_ui::Runtime,\n    /// Pen barrel buttons, simulated keys and the soft-key strip (see `pen_touch`).\n    pub pen_touch: pen_touch::PenTouch,",
        "pub pen_touch: pen_touch::PenTouch")
replace(A, "prefs_rt: Default::default(),", "prefs_rt: Default::default(),\n            pen_touch: Default::default(),", "pen_touch: Default::default()")
replace(A, "stylus::pen_hold_is_no_right_click(ctx, pen_down);",
        "crate::pen_touch::raw_input(self, ctx, raw_input);\n        crate::pen_touch::long_press(self, ctx, pen_down);",
        "pen_touch::raw_input(")
replace(F, "paint_mouse::sync_tool_brush(self);", "paint_mouse::sync_tool_brush(self);\n        crate::pen_touch::apply(self, &ctx);", "pen_touch::apply(")
replace(F, "panels::title_bar(self, ui);", "panels::title_bar(self, ui);\n            crate::pen_touch::ui::soft_key_strip(self, ui);", "soft_key_strip(self, ui);")
replace(F, "view_cmds::persist(self, &ctx);", "view_cmds::persist(self, &ctx);\n        crate::pen_touch::finish(self, &ctx);", "pen_touch::finish(")

PD = "crates/ui-egui/src/prefs/prefs_ui/"
replace(PD + "startup.rs", "crate::view_cmds::restore(app);", "crate::view_cmds::restore(app);\n    crate::pen_touch::restore(app);", "crate::pen_touch::restore")
replace(PD + "fields.rs", "prefs_body(ui, f, system);", "prefs_body(app, ui, f, system);", "prefs_body(app, ui")
replace(PD + "fields.rs", "fn prefs_body(ui: &mut egui::Ui,", "fn prefs_body(app: &mut PhotocraftApp, ui: &mut egui::Ui,", "fn prefs_body(app:")
replace(PD + "fields.rs", "if !has_visible_fields(&values, &section) {",
        'if section == "tools" {\n                    crate::pen_touch::ui::settings_block(app, ui);\n                    ui.add_space(8.0);\n                }\n                if !has_visible_fields(&values, &section) {',
        "pen_touch::ui::settings_block")

replace("crates/ui-egui/src/input/stylus.rs", "impl PenContacts {",
        "impl PenContacts {\n    /// Is touch contact `id` a pen that is down? (Valid after [`Self::observe`] saw its start.)\n    pub(crate) fn is_pen(&self, id: egui::TouchId) -> bool {\n        self.down.iter().any(|(c, pen)| *c == id && *pen)\n    }\n",
        "fn is_pen(")

replace("crates/engine/src/prefs.rs", "pub view_extras: Value,",
        "pub view_extras: Value,\n    /// Pen & Touch settings, JSON owned by the shell (`pen_touch` in photocraft-ui-egui).\n    pub pen_touch: Value,",
        "pub pen_touch: Value")

# Desktop launcher (not used by the Android build; skipped when the anchor moved).
replace("apps/photocraft/src/main.rs", "app.custom_titlebar = custom_titlebar;", "app.custom_titlebar = custom_titlebar;\n            app.enable_pen_touch_prompt();", "enable_pen_touch_prompt", required=False)

# Help menu: reopen the quick tour.
replace("crates/engine/src/shell_commands.rs", '    ("help.discord", "Join the ArtCraft Discord…", &["Help"], None),',
        '    ("help.penTouchTour", "Quick tour: pen and touch…", &["Help"], None),\n    ("help.discord", "Join the ArtCraft Discord…", &["Help"], None),', "help.penTouchTour", required=False)
replace("crates/ui-egui/src/menus/state.rs", '"help.about" | "help.systemInfo" | "edit.search" => true,',
        '"help.about" | "help.systemInfo" | "help.penTouchTour" | "edit.search" => true,', "help.penTouchTour")
replace("crates/ui-egui/src/menus/invoke.rs", "    // Help › Discord, website, GitHub, Report an Issue.\n",
        '    if id == "help.penTouchTour" {\n        app.pen_touch.tour.start();\n        return Ok(Value::Null);\n    }\n    // Help › Discord, website, GitHub, Report an Issue.\n', "help.penTouchTour")

# Branding: the upstream Discord invitation becomes a link to this edition's developer.
DEV_URL = "https://github.com/HansaraKehan"
replace("crates/ui-egui/src/links.rs", 'pub const DISCORD: &str = "https://discord.gg/artcraft";',
        f'pub const DISCORD: &str = "{DEV_URL}";', DEV_URL, required=False)
replace("crates/ui-egui/src/links.rs", 'tl!("Join us on Discord")', '"Follow the developer on GitHub"',
        "Follow the developer on GitHub", required=False)
replace("crates/engine/src/shell_commands.rs", '("help.discord", "Join the ArtCraft Discord…", &["Help"], None),',
        '("help.discord", "Follow the developer on GitHub…", &["Help"], None),', "Follow the developer on GitHub", required=False)

if failures:
    print("pen_touch_integrate: upstream changed; update the anchors:", *failures, sep="\n  ", file=sys.stderr)
    sys.exit(1)
print("pen_touch_integrate: ok")
