#!/usr/bin/env python3
"""Hook the Pen & Touch module into upstream PhotoCraft.

Anchor-based and idempotent: each edit finds one known line and inserts next to it, so it keeps
working when upstream moves code around. If an anchor disappears the build stops with a clear
message instead of silently dropping a feature.
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
UI = ROOT / "crates/ui-egui/src"
failures = []


def replace(path, old, new, marker, required=True):
    p = ROOT / path
    s = p.read_text()
    if marker in s:
        return
    if s.count(old) != 1:
        if required:
            failures.append(f"{path}: anchor found {s.count(old)} times: {old!r}")
        return
    p.write_text(s.replace(old, new))


L = "crates/ui-egui/src/lib.rs"
replace(L, "pub mod perspective_crop_ui;", "pub mod pen_touch;\npub mod perspective_crop_ui;", "pub mod pen_touch;")
replace(L, "pub(crate) prefs_rt: prefs_ui::Runtime,",
        "pub(crate) prefs_rt: prefs_ui::Runtime,\n    /// Pen barrel buttons, simulated keys and the soft-key strip (see `pen_touch`).\n    pub pen_touch: pen_touch::PenTouch,",
        "pub pen_touch: pen_touch::PenTouch")
replace(L, "prefs_rt: Default::default(),", "prefs_rt: Default::default(),\n            pen_touch: Default::default(),", "pen_touch: Default::default()")
replace(L, "stylus::pen_hold_is_no_right_click(ctx, pen_down);",
        "pen_touch::raw_input(self, ctx, raw_input);\n        stylus::pen_hold_is_no_right_click(ctx, pen_down || pen_touch::suppresses_long_press(self));",
        "pen_touch::raw_input(")
replace(L, "paint_mouse::sync_tool_brush(self);", "paint_mouse::sync_tool_brush(self);\n        pen_touch::apply(self, &ctx);", "pen_touch::apply(")
replace(L, "panels::title_bar(self, ui);", "panels::title_bar(self, ui);\n            pen_touch::ui::soft_key_strip(self, ui);", "soft_key_strip(self, ui);")
replace(L, "view_cmds::persist(self, &ctx);", "view_cmds::persist(self, &ctx);\n        pen_touch::finish(self, &ctx);", "pen_touch::finish(")

P = "crates/ui-egui/src/prefs_ui.rs"
replace(P, "crate::view_cmds::restore(app);", "crate::view_cmds::restore(app);\n    crate::pen_touch::restore(app);", "crate::pen_touch::restore")
replace(P, "prefs_body(ui, f, system);", "prefs_body(app, ui, f, system);", "prefs_body(app, ui")
replace(P, "fn prefs_body(ui: &mut egui::Ui,", "fn prefs_body(app: &mut PhotocraftApp, ui: &mut egui::Ui,", "fn prefs_body(app:")
replace(P, "if !has_visible_fields(&values, &section) {",
        'if section == "tools" {\n                    crate::pen_touch::ui::settings_block(app, ui);\n                    ui.add_space(8.0);\n                }\n                if !has_visible_fields(&values, &section) {',
        "pen_touch::ui::settings_block")

replace("crates/ui-egui/src/stylus.rs", "impl PenContacts {",
        "impl PenContacts {\n    /// Is touch contact `id` a pen that is down? (Valid after [`Self::observe`] saw its start.)\n    pub(crate) fn is_pen(&self, id: egui::TouchId) -> bool {\n        self.down.iter().any(|(c, pen)| *c == id && *pen)\n    }\n",
        "fn is_pen(")

replace("crates/engine/src/prefs.rs", "pub view_extras: Value,",
        "pub view_extras: Value,\n    /// Pen & Touch settings, JSON owned by the shell (`pen_touch` in photocraft-ui-egui).\n    pub pen_touch: Value,",
        "pub pen_touch: Value")

# Desktop launcher (not used by the Android build; skipped when the anchor moved).
replace("apps/photocraft/src/main.rs", "app.custom_titlebar = custom_titlebar;", "app.custom_titlebar = custom_titlebar;\n            app.enable_pen_touch_prompt();", "enable_pen_touch_prompt", required=False)

if failures:
    print("pen_touch_integrate: upstream changed; update the anchors:", *failures, sep="\n  ", file=sys.stderr)
    sys.exit(1)
print("pen_touch_integrate: ok")
