package ai.storyteller.photocraft;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Looks for a newer build on this project's GitHub Releases and offers to download it.
 *
 * The release workflow stamps each APK with a version code of "minutes since 1970 at build time",
 * so a release published clearly after the installed build's version code is a newer build. The
 * check runs in the background at most once every few hours, never blocks the app and stays silent
 * when offline. A dialog offers Download / Later / Skip this version.
 */
final class UpdateChecker {
    static final String REPO = "HansaraKehan/CraftPhoto";
    private static final String API = "https://api.github.com/repos/" + REPO + "/releases/latest";
    private static final String PREFS = "photocraft_update";
    private static final long EVERY_MS = 6L * 60 * 60 * 1000;
    /** A release is published a few minutes after its version code is stamped. */
    private static final long SLACK_MINUTES = 20;

    private UpdateChecker() {}

    /** Check in the background. `manual` also reports "up to date" and failures. */
    static void check(final Activity activity, final boolean manual) {
        final SharedPreferences prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE);
        if (!manual && System.currentTimeMillis() - prefs.getLong("last_check", 0) < EVERY_MS) return;
        Thread t = new Thread(() -> {
            try {
                run(activity, prefs, manual);
            } catch (Throwable e) {
                if (manual) toast(activity, "Could not check for updates.");
            }
        }, "photocraft-update-check");
        t.setDaemon(true);
        t.start();
    }

    private static void run(Activity activity, SharedPreferences prefs, boolean manual) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "PhotoCraft-Android-update-check");
        if (c.getResponseCode() != 200) {
            if (manual) toast(activity, "Could not check for updates.");
            return;
        }
        String body;
        try (InputStream in = c.getInputStream(); BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0 && sb.length() < 1_000_000) sb.append(buf, 0, n);
            body = sb.toString();
        } finally {
            c.disconnect();
        }
        prefs.edit().putLong("last_check", System.currentTimeMillis()).apply();

        JSONObject release = new JSONObject(body);
        final String tag = release.optString("tag_name");
        final String title = release.optString("name", tag);
        final String page = release.optString("html_url", "https://github.com/" + REPO + "/releases");
        final String notes = release.optString("body", "");
        String download = page;
        JSONArray assets = release.optJSONArray("assets");
        for (int i = 0; assets != null && i < assets.length(); i++) {
            JSONObject a = assets.getJSONObject(i);
            if (a.optString("name").endsWith(".apk")) {
                download = a.optString("browser_download_url", page);
                break;
            }
        }
        final String target = download;

        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date published = f.parse(release.optString("published_at"));
        long releaseMinutes = published.getTime() / 60000L;
        long installed = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).getLongVersionCode();

        boolean newer = releaseMinutes > installed + SLACK_MINUTES;
        if (!newer) {
            if (manual) toast(activity, "PhotoCraft is up to date.");
            return;
        }
        if (!manual && tag.equals(prefs.getString("skip_tag", ""))) return;

        activity.runOnUiThread(() -> {
            if (activity.isFinishing()) return;
            String text = "A newer build is available:\n" + title;
            String trimmed = notes.trim();
            if (!trimmed.isEmpty()) text += "\n\n" + (trimmed.length() > 500 ? trimmed.substring(0, 500) + "…" : trimmed);
            new AlertDialog.Builder(activity)
                .setTitle("Update available")
                .setMessage(text)
                .setPositiveButton("Download", (d, w) -> {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(target)));
                    } catch (Exception e) {
                        toast(activity, "No browser found to download the update.");
                    }
                })
                .setNeutralButton("Skip this version", (d, w) -> prefs.edit().putString("skip_tag", tag).apply())
                .setNegativeButton("Later", null)
                .show();
        });
    }

    private static void toast(final Activity activity, final String message) {
        activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_LONG).show());
    }
}
