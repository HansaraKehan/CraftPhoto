# Android layer attribution

## Android window input adapter

| Path | Title | Author | Source | License |
|---|---|---|---|---|
| `vendor/winit/` | winit 0.30.13 with a local Android hardware-input patch | The winit contributors; PhotoCraft local modifications | https://crates.io/crates/winit/0.30.13 | Apache-2.0 (`vendor/winit/LICENSE`) |

The local patch is documented in `vendor/winit/PHOTOCRAFT-PATCH.md`.

## Android port

The native Android port (`apps/photocraft-android`, `packaging/android`) is based on the work of
SnowOwlLeader (https://github.com/SnowOwlLeader/photocraft-for-android), built on upstream
PhotoCraft by storytold (https://github.com/storytold/photocraft).
