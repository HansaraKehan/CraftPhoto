//! Touch gestures of the Layers panel rows (Android layer): swipe to add to the selection,
//! hold to pick up a layer, hold-and-move to reorder, and a menu that stays open after the finger
//! lifts. `layer_row.rs` calls these through a few one-line hooks (see `pen_touch_integrate.py`).

use super::{PhotocraftApp, Sense, Value, json};
use photocraft_doc::LayerId;

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum TouchLayerMode {
    Pending,
    Scrolling,
    Swiped,
    Held,
    Dragging,
}

#[derive(Clone)]
pub(super) struct TouchLayerGesture {
    document: photocraft_doc::DocId,
    layer: photocraft_doc::LayerId,
    start: egui::Pos2,
    at: f64,
    mode: TouchLayerMode,
    popup: egui::Id,
}

pub(super) fn layer_pointer_is_touch(ctx: &egui::Context) -> bool {
    ctx.input(|i| i.any_touches() || i.events.iter().any(|e| matches!(e, egui::Event::Touch { .. })))
}

pub(super) fn touch_layer_key() -> egui::Id {
    egui::Id::new("touch-layer-gesture")
}

pub(super) fn touch_layer_mode(delta: egui::Vec2, elapsed: f64) -> TouchLayerMode {
    if delta.x < -24.0 && -delta.x > delta.y.abs() * 1.3 {
        TouchLayerMode::Swiped
    } else if (delta.y.abs() > 18.0 && delta.y.abs() >= delta.x.abs()) || delta.x > 18.0 || delta.length() > 60.0 {
        TouchLayerMode::Scrolling
    } else if elapsed >= 0.48 && delta.length() <= 14.0 {
        TouchLayerMode::Held
    } else {
        TouchLayerMode::Pending
    }
}

pub(super) fn touch_layer_dragging(ctx: &egui::Context) -> bool {
    ctx.data(|d| {
        d.get_temp::<TouchLayerGesture>(touch_layer_key())
            .is_some_and(|g| matches!(g.mode, TouchLayerMode::Swiped | TouchLayerMode::Held | TouchLayerMode::Dragging))
    })
}

pub(super) fn advance_touch_layer_gesture(app: &mut PhotocraftApp, ctx: &egui::Context, actions: &mut Vec<(String, Value)>) {
    let Some(mut gesture) = ctx.data(|d| d.get_temp::<TouchLayerGesture>(touch_layer_key())) else { return };
    let (down, released, pos, time) = ctx.input(|i| (i.pointer.primary_down(), i.pointer.any_released(), i.pointer.interact_pos(), i.time));
    if !down {
        if !released {
            ctx.data_mut(|d| d.remove::<TouchLayerGesture>(touch_layer_key()));
            return;
        }
        if !matches!(gesture.mode, TouchLayerMode::Pending | TouchLayerMode::Held) {
            return;
        }
    }
    let Some(pos) = pos else { return };
    // A stationary hold opens the menu. Moving the same finger dismisses it and starts
    // transfer, so the popup cannot take the existing hold-and-drag gesture away.
    if gesture.mode == TouchLayerMode::Held && (pos - gesture.start).length() > 14.0 {
        egui::Popup::close_id(ctx, gesture.popup);
        gesture.mode = TouchLayerMode::Dragging;
        // Share the existing mouse reorder/drop path. The transfer is already armed for
        // document tabs; only the source document may accept a local reorder.
        if app.session.active().is_some_and(|st| st.doc.id == gesture.document) {
            ctx.data_mut(|d| d.insert_temp(egui::Id::new("layer-drag"), gesture.layer.0));
        }
        ctx.data_mut(|d| d.insert_temp(touch_layer_key(), gesture.clone()));
    }
    if gesture.mode == TouchLayerMode::Pending {
        let mode = touch_layer_mode(pos - gesture.start, time - gesture.at);
        match mode {
            TouchLayerMode::Swiped => {
                if app.session.active().is_some_and(|st| st.doc.id == gesture.document) {
                    actions.push(("layer.select".into(), json!({"layer": gesture.layer.0, "mode": "add"})));
                }
            }
            TouchLayerMode::Held => {
                if app.session.active().is_some_and(|st| st.doc.id == gesture.document) {
                    // Arm before the next frame's tab hit-test, including move/release in one frame.
                    crate::layer_transfer::begin_from_panel(app, ctx, gesture.layer);
                    egui::Popup::open_id(ctx, gesture.popup);
                }
            }
            _ => {}
        }
        gesture.mode = mode;
        ctx.data_mut(|d| d.insert_temp(touch_layer_key(), gesture));
    }
}


/// The row's sense: a finger scrolls the list, so it only clicks; a mouse also drags.
pub(super) fn row_sense(ctx: &egui::Context) -> Sense {
    if is_touch(ctx) { Sense::click() } else { Sense::click_and_drag() }
}

/// The current gesture is a finger's (not a mouse's), or a finger gesture is still being tracked.
fn is_touch(ctx: &egui::Context) -> bool {
    layer_pointer_is_touch(ctx) || ctx.data(|d| d.get_temp::<TouchLayerGesture>(touch_layer_key()).is_some())
}

/// A press on a row starts a gesture to classify (swipe, hold, scroll).
pub(super) fn begin_gesture(ctx: &egui::Context, ui: &egui::Ui, doc: &photocraft_doc::Document, l: &photocraft_doc::Layer, rect: egui::Rect, resp: &egui::Response) {
    if !is_touch(ctx) {
        return;
    }
    let (pressed, pos, time) = ui.input(|i| (i.pointer.primary_pressed(), i.pointer.interact_pos(), i.time));
    if pressed
        && ui.rect_contains_pointer(rect)
        && let Some(pos) = pos.filter(|p| rect.contains(*p) && p.x >= rect.left() + 30.0)
    {
        ctx.data_mut(|d| {
            d.insert_temp(
                touch_layer_key(),
                TouchLayerGesture {
                    document: doc.id,
                    layer: l.id,
                    start: pos,
                    at: time,
                    mode: TouchLayerMode::Pending,
                    popup: egui::Popup::default_response_id(resp),
                },
            );
        });
        ctx.request_repaint_after(std::time::Duration::from_millis(500));
    }
}

/// Did a touch gesture already act on this row (so the plain click and double click must not)?
pub(super) fn gesture_used(ctx: &egui::Context, doc: &photocraft_doc::Document, l: &photocraft_doc::Layer) -> bool {
    is_touch(ctx)
        && ctx.data(|d| {
            d.get_temp::<TouchLayerGesture>(touch_layer_key()).is_some_and(|g| g.layer == l.id && g.document == doc.id && g.mode != TouchLayerMode::Pending)
        })
}

/// The row's context menu: the usual right-click menu for a mouse; for a finger a menu that keeps
/// its anchor and close policy after the finger is lifted.
pub(super) fn context_popup<'a>(
    ctx: &egui::Context,
    resp: &'a egui::Response,
    doc: &photocraft_doc::Document,
    l: &photocraft_doc::Layer,
    rect: egui::Rect,
) -> egui::Popup<'a> {
    let touch = is_touch(ctx);
    let popup_id = egui::Popup::default_response_id(resp);
    let origin_key = popup_id.with("touch-origin");
    if !egui::Popup::is_id_open(ctx, popup_id) {
        ctx.data_mut(|d| d.remove::<bool>(origin_key));
    } else if touch {
        ctx.data_mut(|d| d.insert_temp(origin_key, true));
    }
    let touch_menu = touch || ctx.data(|d| d.get_temp::<bool>(origin_key)).unwrap_or(false);
    if touch_menu {
        // Keep the initial release from closing the menu or activating an item under the finger.
        let holding = ctx.data(|d| {
            d.get_temp::<TouchLayerGesture>(touch_layer_key()).is_some_and(|g| g.layer == l.id && g.document == doc.id && g.mode == TouchLayerMode::Held)
        });
        let close_behavior = if holding { egui::PopupCloseBehavior::IgnoreClicks } else { egui::PopupCloseBehavior::CloseOnClickOutside };
        let open = (resp.secondary_clicked() && !resp.long_touched()).then_some(egui::SetOpenCommand::Bool(true));
        egui::Popup::menu(resp).open_memory(open).anchor(rect).close_behavior(close_behavior)
    } else {
        egui::Popup::context_menu(resp)
    }
}
