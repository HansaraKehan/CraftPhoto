//! Compact text toolbar for touch shells (Android layer), hooked in by `pen_touch_integrate.py`.

use super::defaults::{apply, target_text};
use super::editing::{cancel, commit};
use super::fonts::font_picker;
use super::{PhotocraftApp, hex, json};

/// Compact floating toolbar for touch shells, sharing the desktop formatting commands.
pub fn mobile_options_bar(app: &mut PhotocraftApp, ui: &mut egui::Ui) {
    let shown = target_text(app).map(|t| (t.font_family.clone(), t.size_pt, t.color.to_rgb()));
    let mut family = shown.as_ref().map_or_else(|| app.ui.tool_options.type_font.clone(), |t| t.0.clone());
    let mut size = shown.as_ref().map_or(app.ui.tool_options.type_size, |t| t.1);
    ui.horizontal_wrapped(|ui| {
        if font_picker(app, ui, &mut family, 145.0).is_some() {
            app.ui.tool_options.type_font = family.clone();
            apply(app, ui.ctx(), json!({"font": family}));
        }
        if ui.add(egui::DragValue::new(&mut size).range(1.0..=1296.0).suffix(" pt")).changed() {
            app.ui.tool_options.type_size = size;
            apply(app, ui.ctx(), json!({"size": size}));
        }
        let mut rgb = shown.as_ref().map_or_else(
            || {
                let c = app.session.tools.foreground;
                [c[0], c[1], c[2]]
            },
            |t| t.2,
        );
        if ui.color_edit_button_rgb(&mut rgb).changed() {
            app.session.tools.foreground = [rgb[0], rgb[1], rgb[2], 1.0];
            apply(app, ui.ctx(), json!({"color": hex([rgb[0], rgb[1], rgb[2], 1.0])}));
        }
    });
    ui.horizontal_wrapped(|ui| {
        for (align, label) in [("left", "左对齐"), ("center", "居中"), ("right", "右对齐")] {
            if ui.selectable_label(app.ui.tool_options.type_align == align, label).clicked() {
                app.ui.tool_options.type_align = align.into();
                apply(app, ui.ctx(), json!({"align": align}));
            }
        }
        if app.ui.text_edit.is_some() {
            if ui.button("完成").clicked() {
                commit(app);
            }
            if ui.button("撤销输入").clicked() {
                cancel(app);
            }
        }
    });
}
