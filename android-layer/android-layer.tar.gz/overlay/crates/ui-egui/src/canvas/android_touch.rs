//! Touch navigation of the canvas (Android layer): two fingers pan, zoom and rotate the view.
//! `canvas.rs` calls `mobile_gesture` through a hook added by `pen_touch_integrate.py`.

use super::{Pos2, View, ViewXform};

/// Transform the view around the moving finger midpoint, in screen points.
fn apply_touch_view(view: &mut View, xf: &ViewXform, center: Pos2, translation: egui::Vec2, scale: f32, radians: f32, ppp: f32) {
    if !scale.is_finite() || scale <= 0.0 || !radians.is_finite() || !translation.is_finite() || !center.is_finite() {
        return;
    }
    let anchor = xf.to_doc(center - translation);
    view.zoom = (view.zoom * scale).clamp(0.01, 256.0);
    view.rotation = crate::rotate_view::wrap_deg(view.rotation + radians.to_degrees());
    let next = ViewXform { zoom: view.zoom / ppp, rotation: view.rotation, ..*xf };
    let offset = next.unmap_vec(center - xf.rect.center()) / next.zoom;
    view.center = [anchor[0] as f32 - offset.x, anchor[1] as f32 - offset.y];
    view.fit_pending = false;
    view.fill_pending = false;
}

pub(super) fn mobile_gesture(ctx: &egui::Context, idx: usize, xf: &ViewXform, view: &mut View, ppp: f32) -> bool {
    let key = egui::Id::new(("canvas-touch-navigation", idx));
    let held = ctx.data(|d| d.get_temp::<bool>(key).unwrap_or(false));
    let (gesture, touching) = ctx.input(|i| (i.multi_touch(), i.any_touches()));
    let gesture = gesture.filter(|g| held || xf.rect.contains(g.start_pos));
    if let Some(g) = gesture {
        apply_touch_view(view, xf, g.center_pos, g.translation_delta, g.zoom_delta, g.rotation_delta, ppp);
        ctx.data_mut(|d| d.insert_temp(key, true));
        return true;
    }
    if held {
        if !touching {
            ctx.data_mut(|d| d.remove::<bool>(key));
        }
        return true;
    }
    false
}

