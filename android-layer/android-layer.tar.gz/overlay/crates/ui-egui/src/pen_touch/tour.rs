//! The first-launch quick tour: a few short pages that show, with small animations, what the pen
//! and touch features do, point at the buttons they live on, and end by saying everything can be
//! changed in Preferences › Tools › Pen & Touch.
//!
//! The pages are drawn over the app. The part of the screen a page talks about is left bright and
//! ringed with a pulsing outline; the rest is dimmed. The tour swallows taps while it is open (its
//! own buttons excepted), so a stray touch cannot change a document.

use egui::{Align2, Color32, FontId, Pos2, Rect, RichText, Sense, Stroke, pos2, vec2};

use super::settings::{PenTouchSettings, RECENT};
use crate::PhotocraftApp;

/// The part of the real interface a page points at.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Target {
    Nothing,
    Mode,
    Keys,
    More,
}

/// Where the strip's buttons were drawn last frame (set by the strip, read by the tour).
#[derive(Clone, Copy, Debug, Default)]
pub struct Rects {
    pub mode: Option<Rect>,
    pub keys: Option<Rect>,
    pub more: Option<Rect>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Page {
    Welcome,
    Mode,
    Canvas,
    Taps,
    PenButton,
    SoftKeys,
    Customize,
}

const PAGES: [Page; 7] = [Page::Welcome, Page::Mode, Page::Canvas, Page::Taps, Page::PenButton, Page::SoftKeys, Page::Customize];

impl Page {
    fn target(self) -> Target {
        match self {
            Page::Mode => Target::Mode,
            Page::SoftKeys => Target::Keys,
            Page::Customize => Target::More,
            _ => Target::Nothing,
        }
    }

    fn title(self) -> &'static str {
        match self {
            Page::Welcome => "Quick tour: pen and touch",
            Page::Mode => "Finger or Pen only",
            Page::Canvas => "Move the canvas with your fingers",
            Page::Taps => "Tap with 2 or 3 fingers",
            Page::PenButton => "The button on your pen",
            Page::SoftKeys => "Soft keys",
            Page::Customize => "Make it yours",
        }
    }
}

#[derive(Debug, Default)]
pub struct Tour {
    pub open: bool,
    /// The tour started on its own (or was asked for) in this session.
    begun: bool,
    page: usize,
    page_started: Option<f64>,
    pub rects: Rects,
}

impl Tour {
    /// Open the tour at its first page (the Preferences button, or the first launch).
    pub fn start(&mut self) {
        self.open = true;
        self.begun = true;
        self.page = 0;
        self.page_started = None;
    }
}

/// What a key combination does, in words.
fn describe(keys: &str) -> String {
    let k = keys.trim();
    match k {
        "" => "nothing yet".into(),
        RECENT => "previous tool".into(),
        "Ctrl+Z" => "Undo".into(),
        "Ctrl+Shift+Z" | "Ctrl+Y" => "Redo".into(),
        "Space" => "Space (moves the canvas)".into(),
        other => other.into(),
    }
}

fn tap_text(cfg: &super::settings::FingerTapCfg) -> String {
    if cfg.keys().is_some() { describe(&cfg.action) } else { "off".into() }
}

/// The lines under the animation.
fn lines(page: Page, s: &PenTouchSettings) -> Vec<String> {
    match page {
        Page::Welcome => vec![
            "A short look at the gestures and pen actions of this Android edition.".into(),
            "They come ready to use with default actions, and you can change every one of them at the end.".into(),
        ],
        Page::Mode => vec![
            "Tap this button in the top bar to switch.".into(),
            "Finger: fingers and the pen both draw.".into(),
            "Pen only: only the pen draws, so resting a hand or finger never leaves a mark.".into(),
        ],
        Page::Canvas => vec![
            "In Pen only mode, one finger drags the canvas.".into(),
            "Two fingers pan it, pinch to zoom and twist to rotate.".into(),
        ],
        Page::Taps => vec![
            format!("Tap the canvas quickly with two fingers: {}.", tap_text(&s.tap2)),
            format!("Tap with three fingers: {}.", tap_text(&s.tap3)),
            "Works in Pen only mode, and on active-stylus screens where fingers move things.".into(),
        ],
        Page::PenButton => {
            let b = &s.button1;
            let show = |label: &str, k: &str| format!("{label}: {}", describe(k));
            vec![
                "No need to touch the screen with the pen: it can just hover.".into(),
                show("Press", &b.tap),
                show("Hold", &b.hold),
                show("Press twice", &b.double),
                show("Press 3 times", &b.triple),
            ]
        }
        Page::SoftKeys => vec![
            "Ctrl, Alt and Shift stay on after one tap and turn off with the next tap.".into(),
            "Enter and Esc work like the keyboard keys. « hides the bar.".into(),
        ],
        Page::Customize => vec![
            "Everything you saw can be changed: turn gestures on or off, pick what each tap and pen press does, add your own soft keys.".into(),
            "Open Preferences › Tools › Pen & Touch any time. You can replay this tour there too.".into(),
        ],
    }
}

// ------------------------------------------------------------------ animations

const ACCENT: Color32 = Color32::from_rgb(124, 108, 255);
const GOLD: Color32 = Color32::from_rgb(255, 200, 40);
const MINT: Color32 = Color32::from_rgb(80, 220, 170);
const PINK: Color32 = Color32::from_rgb(255, 110, 150);
const PEN_BODY: Color32 = Color32::from_rgb(244, 244, 252);
const PEN_EDGE: Color32 = Color32::from_rgb(70, 70, 86);

fn fade(c: Color32, k: f32) -> Color32 {
    Color32::from_rgba_unmultiplied(c.r(), c.g(), c.b(), (255.0 * k.clamp(0.0, 1.0)) as u8)
}

fn smooth(x: f32) -> f32 {
    let x = x.clamp(0.0, 1.0);
    x * x * (3.0 - 2.0 * x)
}

fn lerp(a: f32, b: f32, k: f32) -> f32 {
    a + (b - a) * k
}

fn lerp_pos(a: Pos2, b: Pos2, k: f32) -> Pos2 {
    pos2(lerp(a.x, b.x, k), lerp(a.y, b.y, k))
}

/// 0 → 1 → 0 pulse for `x` in 0..1.
fn pulse(x: f32) -> f32 {
    if !(0.0..=1.0).contains(&x) { 0.0 } else { (x * std::f32::consts::PI).sin() }
}

/// A soft glow: stacked translucent discs.
fn glow(p: &egui::Painter, at: Pos2, radius: f32, colour: Color32, strength: f32) {
    for i in 0..6 {
        let k = i as f32 / 6.0;
        p.circle_filled(at, radius * (1.0 - k * 0.8), fade(colour, 0.05 * strength * (1.0 + k * 1.4)));
    }
}

/// A fingertip: a glowing disc with a bright core. `down` presses it in.
fn finger(p: &egui::Painter, at: Pos2, down: f32) {
    glow(p, at, 30.0 + 6.0 * down, ACCENT, 1.0 + down);
    p.circle_filled(at, 13.0 - 2.0 * down, fade(Color32::WHITE, 0.30 + 0.35 * down));
    p.circle_stroke(at, 13.0 - 2.0 * down, Stroke::new(1.6, fade(Color32::WHITE, 0.9)));
}

/// A ring that grows and fades as `k` runs 0 to 1.
fn ripple(p: &egui::Painter, at: Pos2, k: f32, colour: Color32) {
    if !(0.0..1.0).contains(&k) {
        return;
    }
    let e = smooth(k);
    p.circle_stroke(at, 12.0 + 40.0 * e, Stroke::new(2.5 * (1.0 - e) + 0.5, fade(colour, 1.0 - e)));
}

/// A rounded label.
fn pill(p: &egui::Painter, centre: Pos2, text: &str, colour: Color32, appear: f32) {
    if appear <= 0.01 {
        return;
    }
    let font = FontId::proportional(15.0);
    let w = text.chars().count() as f32 * 8.4 + 28.0;
    let r = Rect::from_center_size(centre + vec2(0.0, (1.0 - smooth(appear)) * 8.0), vec2(w, 28.0));
    p.rect_filled(r, 14.0, fade(colour, 0.95 * appear));
    p.text(r.center(), Align2::CENTER_CENTER, text, font, fade(Color32::BLACK, appear));
}

/// The stage every animation plays on: a dark panel with a faint dot grid.
fn stage(p: &egui::Painter, r: Rect) {
    p.rect_filled(r, 14.0, Color32::from_rgb(22, 22, 30));
    p.rect_stroke(r, 14.0, Stroke::new(1.0, Color32::from_rgb(52, 52, 70)), egui::StrokeKind::Inside);
    let step = 22.0;
    let mut y = r.top() + step;
    while y < r.bottom() - 6.0 {
        let mut x = r.left() + step;
        while x < r.right() - 6.0 {
            p.circle_filled(pos2(x, y), 1.0, Color32::from_rgb(44, 44, 58));
            x += step;
        }
        y += step;
    }
}

/// The pen in the style of a stylus: a white barrel with a dark tip and a barrel button that
/// glows when it is pressed. `press` is 0..1 how far the button is pushed.
fn pen(p: &egui::Painter, tip: Pos2, press: f32) {
    let dir = vec2(0.5, -0.866);
    let len = 150.0;
    let tail = tip + dir * len;
    // Shadow on the surface under the tip.
    p.circle_filled(pos2(tip.x, tip.y + 2.0), 9.0, fade(Color32::BLACK, 0.18));
    // Outline, barrel, nib.
    p.line_segment([tip, tail], Stroke::new(17.0, PEN_EDGE));
    p.circle_filled(tip, 8.5, PEN_EDGE);
    p.circle_filled(tail, 8.5, PEN_EDGE);
    p.line_segment([tip + dir * 10.0, tail - dir * 2.0], Stroke::new(13.0, PEN_BODY));
    p.circle_filled(tail - dir * 2.0, 6.5, PEN_BODY);
    p.line_segment([tip, tip + dir * 22.0], Stroke::new(13.0, Color32::from_rgb(120, 120, 140)));
    p.circle_filled(tip, 6.5, Color32::from_rgb(120, 120, 140));
    // The barrel button.
    let btn = tip + dir * (len * 0.5);
    glow(p, btn, 46.0, ACCENT, 3.0 * press);
    p.line_segment([btn - dir * 9.0, btn + dir * 9.0], Stroke::new(8.0 - 2.0 * press, lerp_color(Color32::from_rgb(150, 150, 170), GOLD, press)));
}

fn lerp_color(a: Color32, b: Color32, k: f32) -> Color32 {
    let m = |x: u8, y: u8| lerp(f32::from(x), f32::from(y), k.clamp(0.0, 1.0)) as u8;
    Color32::from_rgb(m(a.r(), b.r()), m(a.g(), b.g()), m(a.b(), b.b()))
}

/// A smooth stroke across `r` up to `k` (0..1) with a fading tail. Returns the tip.
fn trail(p: &egui::Painter, r: Rect, k: f32, colour: Color32) -> Pos2 {
    let n = 60;
    let point = |f: f32| pos2(r.left() + 20.0 + f * (r.width() - 40.0), r.center().y + (f * 7.0).sin() * r.height() * 0.2 - (f * 2.3).cos() * r.height() * 0.05);
    let upto = ((n as f32) * k.clamp(0.0, 1.0)) as usize;
    for i in 0..upto {
        let f0 = i as f32 / n as f32;
        let f1 = (i + 1) as f32 / n as f32;
        let age = 1.0 - (upto - i) as f32 / n as f32;
        p.line_segment([point(f0), point(f1)], Stroke::new(3.5, fade(colour, 0.35 + 0.65 * age.clamp(0.0, 1.0))));
    }
    point(upto as f32 / n as f32)
}

fn canvas_card(p: &egui::Painter, c: Pos2, half: egui::Vec2, angle: f32, lit: f32) {
    let (s, co) = angle.sin_cos();
    let pts: Vec<Pos2> = [vec2(-half.x, -half.y), vec2(half.x, -half.y), vec2(half.x, half.y), vec2(-half.x, half.y)]
        .iter()
        .map(|v| c + vec2(v.x * co - v.y * s, v.x * s + v.y * co))
        .collect();
    p.add(egui::Shape::convex_polygon(pts.clone(), Color32::from_rgb(244, 244, 250), Stroke::new(2.0, fade(ACCENT, 0.4 + 0.6 * lit))));
    // A little picture on the card so rotation and zoom are visible.
    let at = |u: f32, v: f32| c + vec2((u * half.x) * co - (v * half.y) * s, (u * half.x) * s + (v * half.y) * co);
    p.circle_filled(at(-0.35, -0.2), half.y * 0.28, fade(PINK, 0.9));
    p.add(egui::Shape::convex_polygon(vec![at(0.0, 0.6), at(0.45, -0.5), at(0.85, 0.6)], fade(MINT, 0.95), Stroke::NONE));
}

/// Draw the animation of `page` into `r` at `t` seconds since the page opened.
fn animate(p: &egui::Painter, r: Rect, page: Page, t: f32, s: &PenTouchSettings) {
    stage(p, r);
    let c = r.center();
    let top = pos2(c.x, r.top() + 26.0);
    match page {
        Page::Welcome => {
            let cycle = 4.0;
            let k = smooth(((t % cycle) / 3.0).min(1.0));
            let card = Rect::from_center_size(c + vec2(-70.0, 14.0), vec2(r.width() * 0.52, r.height() * 0.62));
            p.rect_filled(card, 10.0, Color32::from_rgb(244, 244, 250));
            let tip = trail(p, card, k, ACCENT);
            pen(p, tip + vec2(0.0, 0.0), 0.0);
            let f = pos2(r.right() - 90.0, c.y + 40.0);
            finger(p, f + vec2(0.0, 5.0 * (t * 2.0).sin()), 0.0);
            ripple(p, f, ((t * 0.6) % 1.0) * 1.3 - 0.1, ACCENT);
            pill(p, top, "Pen and touch, made for Android", GOLD, smooth(t * 2.0));
        }
        Page::Mode => {
            let cycle = (t % 8.0) / 8.0;
            let pen_only = cycle >= 0.5;
            let slide = smooth(((cycle * 8.0) % 4.0 - 0.2) / 0.5).min(1.0);
            let on = if pen_only { slide } else { 1.0 - slide.min(1.0) };
            // Segmented switch.
            let sw = Rect::from_center_size(pos2(c.x, r.top() + 30.0), vec2(220.0, 32.0));
            p.rect_filled(sw, 16.0, Color32::from_rgb(40, 40, 56));
            let knob_x = lerp(sw.left() + 55.0, sw.right() - 55.0, if pen_only { slide } else { 1.0 - slide });
            let _ = on;
            p.rect_filled(Rect::from_center_size(pos2(knob_x, sw.center().y), vec2(106.0, 26.0)), 13.0, ACCENT);
            p.text(pos2(sw.left() + 55.0, sw.center().y), Align2::CENTER_CENTER, "Finger", FontId::proportional(14.0), Color32::WHITE);
            p.text(pos2(sw.right() - 55.0, sw.center().y), Align2::CENTER_CENTER, "Pen only", FontId::proportional(14.0), Color32::WHITE);
            // Drawing area.
            let area = Rect::from_min_max(pos2(r.left() + 24.0, r.top() + 58.0), pos2(r.right() - 24.0, r.bottom() - 16.0));
            p.rect_filled(area, 10.0, Color32::from_rgb(244, 244, 250));
            let local = ((cycle * 8.0) % 4.0 - 0.7).max(0.0) / 3.0;
            let k = smooth(local.min(1.0));
            if !pen_only {
                let tip = trail(p, area, k, ACCENT);
                finger(p, tip, 1.0);
            } else {
                // The finger tries and nothing is drawn; the pen draws.
                let fpos = lerp_pos(pos2(area.left() + 50.0, area.bottom() - 30.0), pos2(area.left() + 130.0, area.bottom() - 30.0), k);
                finger(p, fpos, 1.0);
                p.text(fpos + vec2(0.0, -34.0), Align2::CENTER_CENTER, "no mark", FontId::proportional(13.0), fade(PINK, (k * 3.0).min(1.0)));
                let tip = trail(p, Rect::from_min_max(pos2(area.left() + 150.0, area.top()), area.max), k, MINT);
                pen(p, tip, 0.0);
            }
        }
        Page::Canvas => {
            let cycle = t % 9.0;
            let mid = c + vec2(0.0, 14.0);
            if cycle < 4.0 {
                let k = smooth(cycle / 3.6);
                let at = mid + vec2(lerp(-90.0, 90.0, k), 0.0);
                canvas_card(p, at, vec2(70.0, 44.0), 0.0, 0.0);
                finger(p, at + vec2(12.0, 6.0), 1.0);
                pill(p, top, "One finger: move the canvas", ACCENT, smooth(cycle * 3.0));
            } else {
                let k = (cycle - 4.0) / 5.0;
                let w = (k * std::f32::consts::TAU).sin();
                let ang = 0.55 * w;
                let zoom = 1.0 + 0.35 * w;
                canvas_card(p, mid, vec2(70.0, 44.0) * zoom, ang, 1.0);
                let (sn, cs) = ang.sin_cos();
                let off = vec2(cs, sn) * (34.0 + 30.0 * zoom);
                p.line_segment([mid - off, mid + off], Stroke::new(1.5, fade(Color32::WHITE, 0.35)));
                finger(p, mid - off, 1.0);
                finger(p, mid + off, 1.0);
                pill(p, top, "Two fingers: pan, pinch and twist", GOLD, smooth((cycle - 4.0) * 3.0));
            }
        }
        Page::Taps => {
            let cycle = t % 6.0;
            let three = cycle >= 3.0;
            let local = if three { cycle - 3.0 } else { cycle };
            let n = if three { 3 } else { 2 };
            let down = pulse(local / 0.5);
            for i in 0..n {
                let x = c.x - 70.0 + (i as f32 - (n as f32 - 1.0) / 2.0) * 50.0;
                let at = pos2(x, c.y + 6.0);
                finger(p, at, down);
                ripple(p, at, (local - 0.2) / 1.0, if three { PINK } else { ACCENT });
            }
            // The result slides in as a toast.
            let (text, on) = if three { (tap_text(&s.tap3), s.tap3.keys().is_some()) } else { (tap_text(&s.tap2), s.tap2.keys().is_some()) };
            let appear = smooth((local - 0.5) / 0.4) * (1.0 - smooth((local - 2.5) / 0.4));
            let toast = pos2(c.x + 100.0, c.y + 6.0);
            let label = format!("{n} fingers: {text}");
            pill(p, toast, &label, if on { MINT } else { Color32::from_gray(150) }, appear);
            pill(p, top, "Quick tap on the canvas", ACCENT, smooth(t * 2.0));
        }
        Page::PenButton => {
            let cycle = t % 12.0;
            // Surface line, slightly angled like a tablet edge.
            let surface = r.bottom() - 26.0;
            p.line_segment([pos2(r.left() + 16.0, surface), pos2(r.right() - 16.0, surface)], Stroke::new(3.0, Color32::from_rgb(90, 90, 110)));
            let tip = pos2(c.x - 40.0, surface - 20.0 + 3.0 * (t * 2.0).sin());
            // Hover rings under the tip: the pen is never touching.
            let ring = (t * 0.9) % 1.0;
            p.circle_stroke(pos2(tip.x, surface), 8.0 + 18.0 * ring, Stroke::new(1.5, fade(Color32::WHITE, 0.5 * (1.0 - ring))));
            // Tip sparks.
            for i in 0..3 {
                let ang = -2.6 + i as f32 * 0.35;
                let d = vec2(ang.cos(), ang.sin());
                p.line_segment([tip + d * 22.0, tip + d * 32.0], Stroke::new(2.5, fade(Color32::WHITE, 0.55)));
            }
            // Which gesture is playing: press, hold, press twice, press 3 times (3 s each).
            let (label, press, count) = match (cycle / 3.0) as u32 {
                0 => {
                    let l = cycle;
                    (format!("Press: {}", describe(&s.button1.tap)), pulse((l - 0.6) / 0.5), 1)
                }
                1 => {
                    let l = cycle - 3.0;
                    let h = smooth((l - 0.4) / 0.4) * (1.0 - smooth((l - 2.4) / 0.4));
                    (format!("Hold: {}", describe(&s.button1.hold)), h, 0)
                }
                2 => {
                    let l = cycle - 6.0;
                    (format!("Press twice: {}", describe(&s.button1.double)), pulse((l - 0.4) / 0.4).max(pulse((l - 1.1) / 0.4)), 2)
                }
                _ => {
                    let l = cycle - 9.0;
                    (format!("Press 3 times: {}", describe(&s.button1.triple)), pulse((l - 0.3) / 0.35).max(pulse((l - 0.9) / 0.35)).max(pulse((l - 1.5) / 0.35)), 3)
                }
            };
            pen(p, tip, press);
            // Dots counting the presses.
            for i in 0..count {
                p.circle_filled(pos2(c.x + 90.0 + i as f32 * 20.0, c.y), 6.0, fade(GOLD, 0.35 + 0.65 * press));
            }
            if count == 0 {
                // Hold: a ring that fills.
                let k = smooth(((cycle - 3.0) - 0.4) / 2.0);
                let centre = pos2(c.x + 100.0, c.y);
                p.circle_stroke(centre, 15.0, Stroke::new(3.0, Color32::from_rgb(60, 60, 80)));
                let steps = (40.0 * k) as usize;
                for i in 0..steps {
                    let a0 = -std::f32::consts::FRAC_PI_2 + i as f32 / 40.0 * std::f32::consts::TAU;
                    let a1 = a0 + std::f32::consts::TAU / 40.0;
                    p.line_segment([centre + vec2(a0.cos(), a0.sin()) * 15.0, centre + vec2(a1.cos(), a1.sin()) * 15.0], Stroke::new(3.5, GOLD));
                }
            }
            pill(p, top, &label, GOLD, 1.0);
            p.text(pos2(r.right() - 16.0, surface + 14.0), Align2::RIGHT_CENTER, "pen hovering, no touch needed", FontId::proportional(12.0), Color32::from_gray(150));
        }
        Page::SoftKeys => {
            let keys = ["Ctrl", "Alt", "Shift", "Enter", "Esc"];
            let step = 1.4;
            let lit = ((t / step) as usize) % keys.len();
            let local = (t % step) / step;
            let w = (r.width() - 60.0) / keys.len() as f32;
            let y = c.y + 6.0;
            let target_x = |i: usize| r.left() + 30.0 + w * (i as f32 + 0.5);
            for (i, name) in keys.iter().enumerate() {
                let pressed = i == lit && local > 0.35;
                let latched = i == lit && i < 3 && local > 0.35;
                let at = pos2(target_x(i), y + if pressed { 3.0 } else { 0.0 });
                let rect = Rect::from_center_size(at, vec2(w - 10.0, 40.0));
                p.rect_filled(rect.translate(vec2(0.0, 4.0)), 9.0, Color32::from_rgb(12, 12, 18));
                p.rect_filled(rect, 9.0, if latched { GOLD } else { Color32::from_rgb(58, 58, 78) });
                p.text(rect.center(), Align2::CENTER_CENTER, *name, FontId::proportional(14.0), if latched { Color32::BLACK } else { Color32::WHITE });
                if latched {
                    p.circle_filled(rect.right_top() + vec2(-8.0, 8.0), 3.5, Color32::BLACK);
                }
            }
            let prev = (lit + keys.len() - 1) % keys.len();
            let fx = lerp(target_x(prev), target_x(lit), smooth(local / 0.35));
            finger(p, pos2(fx, y + 30.0), pulse((local - 0.3) / 0.3));
            ripple(p, pos2(target_x(lit), y), (local - 0.35) / 0.6, GOLD);
            pill(p, top, if lit < 3 { "Tap once to hold, tap again to release" } else { "Works like the keyboard key" }, ACCENT, 1.0);
        }
        Page::Customize => {
            let rows = ["Tap with 2 fingers", "Tap with 3 fingers", "Pen button: press", "Pen button: hold"];
            for (i, name) in rows.iter().enumerate() {
                let y = r.top() + 38.0 + i as f32 * 38.0;
                let row = Rect::from_min_max(pos2(r.left() + 24.0, y - 15.0), pos2(r.right() - 24.0, y + 15.0));
                p.rect_filled(row, 8.0, Color32::from_rgb(34, 34, 48));
                p.text(pos2(row.left() + 14.0, y), Align2::LEFT_CENTER, *name, FontId::proportional(14.0), Color32::WHITE);
                let wave = ((t * 0.7 + i as f32 * 0.9).sin() * 0.5 + 0.5).powf(0.6);
                let on = smooth(wave * 1.4 - 0.2);
                let sw = Rect::from_center_size(pos2(row.right() - 40.0, y), vec2(44.0, 22.0));
                p.rect_filled(sw, 11.0, lerp_color(Color32::from_rgb(74, 74, 92), MINT, on));
                p.circle_filled(pos2(lerp(sw.left() + 11.0, sw.right() - 11.0, on), y), 8.0, Color32::WHITE);
                p.text(pos2(row.right() - 100.0, y), Align2::RIGHT_CENTER, "your action", FontId::proportional(12.0), Color32::from_gray(150));
            }
            pill(p, top, "All of this is yours to change", GOLD, 1.0);
        }
    }
}

// ------------------------------------------------------------------ drawing the tour

/// Show the tour (and start it on first launch). Called at the end of every frame.
pub fn show(app: &mut PhotocraftApp, ctx: &egui::Context) {
    if !app.pen_touch.tour.open {
        let pt = &mut app.pen_touch;
        if pt.prompt_enabled && pt.prompt.is_done() && !pt.settings.tour_done && !pt.tour.begun {
            pt.tour.start();
            // The tour points at the soft keys, so they must be showing.
            pt.settings.soft_keys_visible = true;
            pt.settings.soft_keys_open = true;
        }
        if !app.pen_touch.tour.open {
            return;
        }
    }
    ctx.request_repaint();
    let now = ctx.input(|i| i.time);
    let started = *app.pen_touch.tour.page_started.get_or_insert(now);
    let t = (now - started) as f32;
    let index = app.pen_touch.tour.page.min(PAGES.len() - 1);
    let page = PAGES[index];
    let tokens = crate::theme::Tokens::get(ctx);
    let screen = ctx.content_rect();
    let rects = app.pen_touch.tour.rects;
    let target = match page.target() {
        Target::Nothing => None,
        Target::Mode => rects.mode,
        Target::Keys => rects.keys,
        Target::More => rects.more,
    }
    .filter(|r| r.is_positive() && screen.intersects(*r))
    .map(|r| r.expand(6.0));

    // Dim everything but the target, ring it, and swallow taps.
    egui::Area::new(egui::Id::unique("pen-touch-tour-dim")).order(egui::Order::Tooltip).fixed_pos(screen.min).show(ctx, |ui| {
        ui.allocate_rect(screen, Sense::click_and_drag());
        let p = ui.painter();
        let dim = Color32::from_black_alpha(175);
        match target {
            Some(hole) => {
                p.rect_filled(Rect::from_min_max(screen.min, pos2(screen.max.x, hole.min.y)), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(screen.min.x, hole.max.y), screen.max), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(screen.min.x, hole.min.y), pos2(hole.min.x, hole.max.y)), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(hole.max.x, hole.min.y), pos2(screen.max.x, hole.max.y)), 0.0, dim);
                let pulse = 0.5 + 0.5 * (t * 5.0).sin();
                p.rect_stroke(hole.expand(1.0 + 3.0 * pulse), 8.0, Stroke::new(3.0, GOLD), egui::StrokeKind::Outside);
                let k = (t * 0.9).fract();
                p.circle_stroke(hole.center(), 10.0 + 26.0 * k, Stroke::new(2.0, Color32::from_rgba_unmultiplied(255, 200, 40, ((1.0 - k) * 230.0) as u8)));
                p.text(pos2(hole.center().x, hole.max.y + 10.0 + 3.0 * pulse), Align2::CENTER_TOP, "this button", FontId::proportional(13.0), GOLD);
            }
            None => {
                p.rect_filled(screen, 0.0, dim);
            }
        }
    });

    // The card.
    let width = 580.0f32.min(screen.width() - 32.0).max(220.0);
    let anim_height = (width * 0.42).min(screen.height() * 0.34).clamp(110.0, 250.0);
    let mut go: i32 = 0;
    let mut skip = false;
    let mut open_settings = false;
    let settings = app.pen_touch.settings.clone();
    let body = lines(page, &settings);
    let mut area = egui::Area::new(egui::Id::unique("pen-touch-tour-card")).order(egui::Order::Tooltip);
    area = match target {
        // Below a target in the top half of the screen, otherwise centred.
        Some(hole) if hole.center().y < screen.center().y => {
            let x = (hole.center().x - width / 2.0 - 14.0).clamp(screen.min.x + 6.0, (screen.max.x - width - 34.0).max(screen.min.x + 6.0));
            area.fixed_pos(pos2(x, hole.max.y + 34.0))
        }
        _ => area.anchor(Align2::CENTER_CENTER, vec2(0.0, 0.0)),
    };
    area.show(ctx, |ui| {
        egui::Frame::NONE
            .fill(tokens.card)
            .stroke(Stroke::new(2.0, GOLD))
            .corner_radius(tokens.radius)
            .inner_margin(egui::Margin::same(18))
            .show(ui, |ui| {
                ui.set_width(width);
                ui.label(RichText::new(page.title()).strong().size(22.0).color(tokens.text));
                ui.add_space(6.0);
                let (rect, _) = ui.allocate_exact_size(vec2(width, anim_height), Sense::hover());
                animate(&ui.painter_at(rect), rect, page, t, &settings);
                ui.add_space(8.0);
                for line in &body {
                    ui.add(egui::Label::new(RichText::new(line.as_str()).size(15.5).color(tokens.text_dim)).wrap());
                }
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    for i in 0..PAGES.len() {
                        let on = i == index;
                        let (dot, _) = ui.allocate_exact_size(vec2(10.0, 10.0), Sense::hover());
                        ui.painter().circle_filled(dot.center(), if on { 4.0 } else { 3.0 }, if on { GOLD } else { tokens.text_faint });
                    }
                });
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    if ui.button("Skip").clicked() {
                        skip = true;
                    }
                    if page == Page::Customize && ui.button("Open settings").clicked() {
                        open_settings = true;
                    }
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let last = index + 1 == PAGES.len();
                        if ui.add(egui::Button::new(RichText::new(if last { "Finish" } else { "Next" }).strong()).fill(GOLD)).clicked() {
                            go = 1;
                        }
                        if index > 0 && ui.button("Back").clicked() {
                            go = -1;
                        }
                    });
                });
            });
    });

    let tour = &mut app.pen_touch.tour;
    if go != 0 {
        tour.page_started = None;
        if go < 0 {
            tour.page = index.saturating_sub(1);
        } else if index + 1 >= PAGES.len() {
            skip = true;
        } else {
            tour.page = index + 1;
        }
    }
    if skip || open_settings {
        tour.open = false;
        app.pen_touch.settings.tour_done = true;
    }
    if open_settings {
        crate::prefs_ui::open_preferences(app, "tools");
    }
}
