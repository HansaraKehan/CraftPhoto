//! The first-launch quick tour: a few short pages that show, with small animations, what the pen
//! and touch features do, point at the buttons they live on, and end by saying everything can be
//! changed in Preferences › Tools › Pen & Touch.
//!
//! The pages are drawn over the app. The part of the screen a page talks about is left bright and
//! ringed with a pulsing outline; the rest is dimmed. The tour swallows taps while it is open (its
//! own buttons excepted), so a stray touch cannot change a document.

use egui::{Align2, Color32, FontId, Pos2, Rect, RichText, Sense, Stroke, pos2, vec2};

use super::settings::{PenTouchSettings, RECENT};
use crate::PhotocraftApp;

/// The part of the real interface a page points at.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Target {
    Nothing,
    Mode,
    Keys,
    More,
}

/// Where the strip's buttons were drawn last frame (set by the strip, read by the tour).
#[derive(Clone, Copy, Debug, Default)]
pub struct Rects {
    pub mode: Option<Rect>,
    pub keys: Option<Rect>,
    pub more: Option<Rect>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Page {
    Welcome,
    Mode,
    Canvas,
    Taps,
    PenButton,
    SoftKeys,
    Customize,
}

const PAGES: [Page; 7] = [Page::Welcome, Page::Mode, Page::Canvas, Page::Taps, Page::PenButton, Page::SoftKeys, Page::Customize];

impl Page {
    fn target(self) -> Target {
        match self {
            Page::Mode => Target::Mode,
            Page::SoftKeys => Target::Keys,
            Page::Customize => Target::More,
            _ => Target::Nothing,
        }
    }

    fn title(self) -> &'static str {
        match self {
            Page::Welcome => "Quick tour: pen and touch",
            Page::Mode => "Finger or Pen only",
            Page::Canvas => "Move the canvas with your fingers",
            Page::Taps => "Tap with 2 or 3 fingers",
            Page::PenButton => "The button on your pen",
            Page::SoftKeys => "Soft keys",
            Page::Customize => "Make it yours",
        }
    }
}

#[derive(Debug, Default)]
pub struct Tour {
    pub open: bool,
    /// The tour started on its own (or was asked for) in this session.
    begun: bool,
    page: usize,
    page_started: Option<f64>,
    pub rects: Rects,
}

impl Tour {
    /// Open the tour at its first page (the Preferences button, or the first launch).
    pub fn start(&mut self) {
        self.open = true;
        self.begun = true;
        self.page = 0;
        self.page_started = None;
    }
}

/// What a key combination does, in words.
fn describe(keys: &str) -> String {
    let k = keys.trim();
    match k {
        "" => "nothing yet".into(),
        RECENT => "previous tool".into(),
        "Ctrl+Z" => "Undo".into(),
        "Ctrl+Shift+Z" | "Ctrl+Y" => "Redo".into(),
        "Space" => "Space (moves the canvas)".into(),
        other => other.into(),
    }
}

fn tap_text(cfg: &super::settings::FingerTapCfg) -> String {
    if cfg.keys().is_some() { describe(&cfg.action) } else { "off".into() }
}

/// The lines under the animation.
fn lines(page: Page, s: &PenTouchSettings) -> Vec<String> {
    match page {
        Page::Welcome => vec![
            "A short look at the gestures and pen actions of this Android edition.".into(),
            "They come ready to use with default actions, and you can change every one of them at the end.".into(),
        ],
        Page::Mode => vec![
            "Tap this button in the top bar to switch.".into(),
            "Finger: fingers and the pen both draw.".into(),
            "Pen only: only the pen draws, so resting a hand or finger never leaves a mark.".into(),
        ],
        Page::Canvas => vec![
            "In Pen only mode, one finger drags the canvas.".into(),
            "Two fingers pan it, pinch to zoom and twist to rotate.".into(),
        ],
        Page::Taps => vec![
            format!("Tap the canvas quickly with two fingers: {}.", tap_text(&s.tap2)),
            format!("Tap with three fingers: {}.", tap_text(&s.tap3)),
            "Works in Pen only mode, and on active-stylus screens where fingers move things.".into(),
        ],
        Page::PenButton => {
            let b = &s.button1;
            let show = |label: &str, k: &str| format!("{label}: {}", describe(k));
            vec![
                "No need to touch the screen with the pen: it can just hover.".into(),
                show("Press", &b.tap),
                show("Hold", &b.hold),
                show("Press twice", &b.double),
                show("Press 3 times", &b.triple),
            ]
        }
        Page::SoftKeys => vec![
            "Ctrl, Alt and Shift stay on after one tap and turn off with the next tap.".into(),
            "Enter and Esc work like the keyboard keys. « hides the bar.".into(),
        ],
        Page::Customize => vec![
            "Everything you saw can be changed: turn gestures on or off, pick what each tap and pen press does, add your own soft keys.".into(),
            "Open Preferences › Tools › Pen & Touch any time. You can replay this tour there too.".into(),
        ],
    }
}

// ------------------------------------------------------------------ animations

const BLUE: Color32 = Color32::from_rgb(90, 150, 255);
const GOLD: Color32 = Color32::from_rgb(255, 200, 40);

fn finger(p: &egui::Painter, at: Pos2, down: bool) {
    let alpha = if down { 200 } else { 110 };
    p.circle_filled(at, 11.0, Color32::from_rgba_unmultiplied(110, 170, 255, alpha));
    p.circle_stroke(at, 11.0, Stroke::new(1.5, Color32::WHITE));
}

/// A ripple that grows from `at` as `k` runs 0 to 1.
fn ripple(p: &egui::Painter, at: Pos2, k: f32) {
    if !(0.0..1.0).contains(&k) {
        return;
    }
    let a = ((1.0 - k) * 220.0) as u8;
    p.circle_stroke(at, 8.0 + 22.0 * k, Stroke::new(2.0, Color32::from_rgba_unmultiplied(255, 255, 255, a)));
}

fn chip(p: &egui::Painter, centre: Pos2, text: &str, on: bool) {
    let w = 14.0 * 0.62 * text.chars().count() as f32 + 18.0;
    let r = Rect::from_center_size(centre, vec2(w, 22.0));
    p.rect_filled(r, 6.0, if on { GOLD } else { Color32::from_gray(70) });
    p.text(centre, Align2::CENTER_CENTER, text, FontId::proportional(14.0), if on { Color32::BLACK } else { Color32::WHITE });
}

/// A wavy stroke across `r`, drawn up to `k` (0..1). Returns the tip.
fn stroke_path(p: &egui::Painter, r: Rect, k: f32, colour: Color32) -> Pos2 {
    let n = 28;
    let upto = ((n as f32) * k.clamp(0.0, 1.0)) as usize;
    let at = |i: usize| {
        let f = i as f32 / n as f32;
        pos2(r.left() + 16.0 + f * (r.width() - 32.0), r.center().y + (f * 9.0).sin() * r.height() * 0.22)
    };
    for i in 0..upto {
        p.line_segment([at(i), at(i + 1)], Stroke::new(3.0, colour));
    }
    at(upto)
}

fn pen_icon(p: &egui::Painter, tip: Pos2, button_down: bool) {
    let tail = tip + vec2(34.0, -62.0);
    p.line_segment([tip, tail], Stroke::new(7.0, Color32::from_gray(235)));
    p.line_segment([tip, tip + vec2(3.0, -5.5)], Stroke::new(7.0, Color32::from_gray(40)));
    let btn = tip + (tail - tip) * 0.45;
    p.circle_filled(btn, 5.0, if button_down { GOLD } else { Color32::from_gray(130) });
    p.circle_stroke(btn, 5.0, Stroke::new(1.0, Color32::from_gray(30)));
}

fn rotated_rect(p: &egui::Painter, c: Pos2, half: egui::Vec2, angle: f32, colour: Color32) {
    let (s, co) = angle.sin_cos();
    let pts: Vec<Pos2> = [vec2(-half.x, -half.y), vec2(half.x, -half.y), vec2(half.x, half.y), vec2(-half.x, half.y)]
        .iter()
        .map(|v| c + vec2(v.x * co - v.y * s, v.x * s + v.y * co))
        .collect();
    for i in 0..4 {
        p.line_segment([pts[i], pts[(i + 1) % 4]], Stroke::new(2.5, colour));
    }
}

/// Draw the animation of `page` into `r` at `t` seconds since the page opened.
fn animate(p: &egui::Painter, r: Rect, page: Page, t: f32, s: &PenTouchSettings) {
    p.rect_filled(r, 8.0, Color32::from_gray(38));
    let c = r.center();
    match page {
        Page::Welcome => {
            let k = (t * 0.45).fract();
            let tip = stroke_path(p, r, k, Color32::from_rgb(120, 200, 140));
            pen_icon(p, tip, false);
            finger(p, pos2(r.right() - 34.0, r.bottom() - 26.0 - 4.0 * (t * 3.0).sin()), false);
        }
        Page::Mode => {
            let cycle = t % 5.0;
            let pen_mode = cycle >= 2.5;
            let k = if pen_mode { (cycle - 2.5) / 2.5 } else { cycle / 2.5 };
            let area = Rect::from_center_size(c + vec2(0.0, 6.0), vec2(r.width() - 24.0, r.height() - 40.0));
            p.rect_stroke(area, 4.0, Stroke::new(1.0, Color32::from_gray(90)), egui::StrokeKind::Outside);
            let tip = stroke_path(p, area, k, if pen_mode { Color32::WHITE } else { BLUE });
            if pen_mode {
                pen_icon(p, tip, false);
            } else {
                finger(p, tip, true);
            }
            chip(p, pos2(c.x, r.top() + 14.0), if pen_mode { "Pen only: the finger leaves no mark" } else { "Finger: fingers draw too" }, pen_mode);
        }
        Page::Canvas => {
            let cycle = t % 6.0;
            let canvas_c;
            let label;
            if cycle < 3.0 {
                let k = cycle / 3.0;
                let dx = (k * std::f32::consts::TAU).sin() * 40.0;
                canvas_c = c + vec2(dx, 6.0);
                rotated_rect(p, canvas_c, vec2(60.0, 32.0), 0.0, Color32::from_gray(200));
                finger(p, canvas_c + vec2(10.0, 4.0), true);
                label = "One finger: move";
            } else {
                let k = (cycle - 3.0) / 3.0;
                let zoom = 1.0 + 0.35 * (k * std::f32::consts::TAU).sin();
                let ang = 0.5 * (k * std::f32::consts::TAU).sin();
                canvas_c = c + vec2(0.0, 6.0);
                rotated_rect(p, canvas_c, vec2(60.0, 32.0) * zoom * 0.8, ang, Color32::from_gray(200));
                let (sn, cs) = ang.sin_cos();
                let off = vec2(cs, sn) * (30.0 * zoom);
                finger(p, canvas_c - off, true);
                finger(p, canvas_c + off, true);
                label = "Two fingers: pinch and twist";
            }
            chip(p, pos2(c.x, r.top() + 14.0), label, true);
        }
        Page::Taps => {
            let cycle = t % 5.0;
            let three = cycle >= 2.5;
            let local = if three { cycle - 2.5 } else { cycle };
            let n = if three { 3 } else { 2 };
            let down = local < 0.35;
            for i in 0..n {
                let x = c.x + (i as f32 - (n as f32 - 1.0) / 2.0) * 44.0;
                let at = pos2(x, c.y + 6.0);
                finger(p, at, down);
                ripple(p, at, (local - 0.25) / 1.1);
            }
            let (text, on) = if three { (format!("3 fingers: {}", tap_text(&s.tap3)), s.tap3.keys().is_some()) } else { (format!("2 fingers: {}", tap_text(&s.tap2)), s.tap2.keys().is_some()) };
            chip(p, pos2(c.x, r.top() + 14.0), &text, on);
        }
        Page::PenButton => {
            let cycle = t % 7.5;
            let surface = r.bottom() - 18.0;
            p.line_segment([pos2(r.left() + 14.0, surface), pos2(r.right() - 14.0, surface)], Stroke::new(2.0, Color32::from_gray(120)));
            let bob = 3.0 * (t * 2.2).sin();
            let tip = pos2(c.x - 10.0, surface - 24.0 + bob);
            // The hover ring on the screen under the tip.
            p.circle_stroke(pos2(tip.x, surface), 9.0, Stroke::new(1.5, Color32::from_rgba_unmultiplied(255, 255, 255, 140)));
            let (down, label) = if cycle < 2.5 {
                ((0.4..0.8).contains(&cycle), format!("Press: {}", describe(&s.button1.tap)))
            } else if cycle < 5.0 {
                ((2.9..4.6).contains(&cycle), format!("Hold: {}", describe(&s.button1.hold)))
            } else {
                let l = cycle - 5.0;
                ((0.3..0.55).contains(&l) || (0.8..1.05).contains(&l) || (1.4..1.65).contains(&l), "Press twice or 3 times: your actions".to_string())
            };
            pen_icon(p, tip, down);
            chip(p, pos2(c.x, r.top() + 14.0), &label, true);
            p.text(pos2(r.right() - 10.0, surface - 10.0), Align2::RIGHT_BOTTOM, "hovering", FontId::proportional(11.0), Color32::from_gray(160));
        }
        Page::SoftKeys => {
            let keys = ["Ctrl", "Alt", "Shift", "Enter", "Esc"];
            let lit = ((t * 0.7) as usize) % keys.len();
            for (i, name) in keys.iter().enumerate() {
                let x = r.left() + 34.0 + i as f32 * ((r.width() - 68.0) / (keys.len() as f32 - 1.0));
                let on = i == lit && i < 3;
                let at = pos2(x, c.y);
                p.rect_filled(Rect::from_center_size(at, vec2(46.0, 26.0)), 5.0, if on { GOLD } else { Color32::from_gray(75) });
                p.text(at, Align2::CENTER_CENTER, *name, FontId::proportional(13.0), if on { Color32::BLACK } else { Color32::WHITE });
                if i == lit {
                    finger(p, at + vec2(8.0, 14.0), true);
                    ripple(p, at, (t * 0.7).fract() * 1.4 - 0.2);
                }
            }
            p.text(pos2(c.x, r.top() + 14.0), Align2::CENTER_CENTER, "Tap to hold, tap again to release", FontId::proportional(12.0), Color32::from_gray(190));
        }
        Page::Customize => {
            let rows = ["Tap with 2 fingers", "Tap with 3 fingers", "Pen button: press", "Pen button: hold"];
            for (i, name) in rows.iter().enumerate() {
                let y = r.top() + 16.0 + i as f32 * 22.0;
                p.text(pos2(r.left() + 14.0, y), Align2::LEFT_CENTER, *name, FontId::proportional(13.0), Color32::WHITE);
                let on = ((t * 0.8 + i as f32 * 0.37).sin()) > -0.3;
                let sw = Rect::from_center_size(pos2(r.right() - 34.0, y), vec2(34.0, 16.0));
                p.rect_filled(sw, 8.0, if on { Color32::from_rgb(70, 170, 100) } else { Color32::from_gray(90) });
                p.circle_filled(pos2(if on { sw.right() - 8.0 } else { sw.left() + 8.0 }, y), 6.0, Color32::WHITE);
            }
        }
    }
}

// ------------------------------------------------------------------ drawing the tour

/// Show the tour (and start it on first launch). Called at the end of every frame.
pub fn show(app: &mut PhotocraftApp, ctx: &egui::Context) {
    if !app.pen_touch.tour.open {
        let pt = &mut app.pen_touch;
        if pt.prompt_enabled && pt.prompt.is_done() && !pt.settings.tour_done && !pt.tour.begun {
            pt.tour.start();
            // The tour points at the soft keys, so they must be showing.
            pt.settings.soft_keys_visible = true;
            pt.settings.soft_keys_open = true;
        }
        if !app.pen_touch.tour.open {
            return;
        }
    }
    ctx.request_repaint();
    let now = ctx.input(|i| i.time);
    let started = *app.pen_touch.tour.page_started.get_or_insert(now);
    let t = (now - started) as f32;
    let index = app.pen_touch.tour.page.min(PAGES.len() - 1);
    let page = PAGES[index];
    let tokens = crate::theme::Tokens::get(ctx);
    let screen = ctx.content_rect();
    let rects = app.pen_touch.tour.rects;
    let target = match page.target() {
        Target::Nothing => None,
        Target::Mode => rects.mode,
        Target::Keys => rects.keys,
        Target::More => rects.more,
    }
    .filter(|r| r.is_positive() && screen.intersects(*r))
    .map(|r| r.expand(6.0));

    // Dim everything but the target, ring it, and swallow taps.
    egui::Area::new(egui::Id::unique("pen-touch-tour-dim")).order(egui::Order::Tooltip).fixed_pos(screen.min).show(ctx, |ui| {
        ui.allocate_rect(screen, Sense::click_and_drag());
        let p = ui.painter();
        let dim = Color32::from_black_alpha(175);
        match target {
            Some(hole) => {
                p.rect_filled(Rect::from_min_max(screen.min, pos2(screen.max.x, hole.min.y)), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(screen.min.x, hole.max.y), screen.max), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(screen.min.x, hole.min.y), pos2(hole.min.x, hole.max.y)), 0.0, dim);
                p.rect_filled(Rect::from_min_max(pos2(hole.max.x, hole.min.y), pos2(screen.max.x, hole.max.y)), 0.0, dim);
                let pulse = 0.5 + 0.5 * (t * 5.0).sin();
                p.rect_stroke(hole.expand(1.0 + 3.0 * pulse), 8.0, Stroke::new(3.0, GOLD), egui::StrokeKind::Outside);
                let k = (t * 0.9).fract();
                p.circle_stroke(hole.center(), 10.0 + 26.0 * k, Stroke::new(2.0, Color32::from_rgba_unmultiplied(255, 200, 40, ((1.0 - k) * 230.0) as u8)));
                p.text(pos2(hole.center().x, hole.max.y + 10.0 + 3.0 * pulse), Align2::CENTER_TOP, "this button", FontId::proportional(13.0), GOLD);
            }
            None => p.rect_filled(screen, 0.0, dim),
        }
    });

    // The card.
    let width = 340.0f32.min(screen.width() - 24.0).max(200.0);
    let mut go: i32 = 0;
    let mut skip = false;
    let mut open_settings = false;
    let settings = app.pen_touch.settings.clone();
    let body = lines(page, &settings);
    let mut area = egui::Area::new(egui::Id::unique("pen-touch-tour-card")).order(egui::Order::Tooltip);
    area = match target {
        // Below a target in the top half of the screen, otherwise centred.
        Some(hole) if hole.center().y < screen.center().y => {
            let x = (hole.center().x - width / 2.0 - 14.0).clamp(screen.min.x + 6.0, (screen.max.x - width - 34.0).max(screen.min.x + 6.0));
            area.fixed_pos(pos2(x, hole.max.y + 34.0))
        }
        _ => area.anchor(Align2::CENTER_CENTER, vec2(0.0, 0.0)),
    };
    area.show(ctx, |ui| {
        egui::Frame::NONE
            .fill(tokens.card)
            .stroke(Stroke::new(2.0, GOLD))
            .corner_radius(tokens.radius)
            .inner_margin(egui::Margin::same(14))
            .show(ui, |ui| {
                ui.set_width(width);
                ui.label(RichText::new(page.title()).strong().size(18.0).color(tokens.text));
                ui.add_space(6.0);
                let (rect, _) = ui.allocate_exact_size(vec2(width, 112.0), Sense::hover());
                animate(&ui.painter_at(rect), rect, page, t, &settings);
                ui.add_space(8.0);
                for line in &body {
                    ui.add(egui::Label::new(RichText::new(line.as_str()).color(tokens.text_dim)).wrap());
                }
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    for i in 0..PAGES.len() {
                        let on = i == index;
                        let (dot, _) = ui.allocate_exact_size(vec2(10.0, 10.0), Sense::hover());
                        ui.painter().circle_filled(dot.center(), if on { 4.0 } else { 3.0 }, if on { GOLD } else { tokens.text_faint });
                    }
                });
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    if ui.button("Skip").clicked() {
                        skip = true;
                    }
                    if page == Page::Customize && ui.button("Open settings").clicked() {
                        open_settings = true;
                    }
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let last = index + 1 == PAGES.len();
                        if ui.add(egui::Button::new(RichText::new(if last { "Finish" } else { "Next" }).strong()).fill(GOLD)).clicked() {
                            go = 1;
                        }
                        if index > 0 && ui.button("Back").clicked() {
                            go = -1;
                        }
                    });
                });
            });
    });

    let tour = &mut app.pen_touch.tour;
    if go != 0 {
        tour.page_started = None;
        if go < 0 {
            tour.page = index.saturating_sub(1);
        } else if index + 1 >= PAGES.len() {
            skip = true;
        } else {
            tour.page = index + 1;
        }
    }
    if skip || open_settings {
        tour.open = false;
        app.pen_touch.settings.tour_done = true;
    }
    if open_settings {
        crate::prefs_ui::open_preferences(app, "tools");
    }
}
