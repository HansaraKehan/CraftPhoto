//! Pen & Touch screens: the start-up question, the soft-key strip under the menu bar, and the
//! settings block shown at the top of Preferences › Tools. Labels are plain English for now.

use egui::{RichText, Ui, vec2};

use super::settings::{DeviceKind, InputMode, MAX_SOFT_KEYS, PenButtonCfg, SoftKey, default_soft_keys};
use super::virtual_keys;
use crate::PhotocraftApp;

/// State of the start-up question.
#[derive(Debug, Default)]
pub struct Prompt {
    /// The question was answered or skipped this session.
    done: bool,
    /// The option picked so far.
    choice: Option<DeviceKind>,
}

// ------------------------------------------------------------------ start-up question

/// Ask once per launch which kind of device this is, unless the user said not to.
pub fn prompt(app: &mut PhotocraftApp, ctx: &egui::Context) {
    if !app.pen_touch.prompt_enabled || app.pen_touch.prompt.done {
        return;
    }
    if !app.pen_touch.settings.ask_at_start {
        app.pen_touch.prompt.done = true;
        return;
    }
    let current = match app.pen_touch.settings.device {
        DeviceKind::Unset => DeviceKind::Touch,
        d => d,
    };
    let mut choice = app.pen_touch.prompt.choice.unwrap_or(current);
    let mut answer: Option<bool> = None; // Some(dont_ask_again)
    egui::Modal::new(egui::Id::new("pen-touch-device-question")).show(ctx, |ui| {
        ui.set_max_width(360.0);
        ui.heading("Which device are you using?");
        ui.add_space(4.0);
        ui.label("PhotoCraft adapts touch and pen input to your screen. You can change this later in Preferences › Tools › Pen & Touch.");
        ui.add_space(8.0);
        ui.radio_value(&mut choice, DeviceKind::ActiveStylus, "Device with an active stylus");
        ui.label(RichText::new("The pen paints and fingers move things.").weak().small());
        ui.add_space(4.0);
        ui.radio_value(&mut choice, DeviceKind::Touch, "Device without an active stylus");
        ui.label(RichText::new("Fingers paint. Nothing presses Enter for you.").weak().small());
        ui.add_space(10.0);
        ui.horizontal(|ui| {
            if ui.button("Continue").clicked() {
                answer = Some(false);
            }
            if ui.button("Don't ask again").clicked() {
                answer = Some(true);
            }
        });
    });
    app.pen_touch.prompt.choice = Some(choice);
    if let Some(dont_ask) = answer {
        app.pen_touch.settings.device = choice;
        if dont_ask {
            app.pen_touch.settings.ask_at_start = false;
        }
        app.pen_touch.prompt.done = true;
    }
}

// ------------------------------------------------------------------ soft keys

/// What the strip's buttons asked for this frame.
#[derive(Default)]
struct StripActions {
    toggle: bool,
    mode: bool,
    settings: bool,
}

/// The strip's buttons: the contract handle, the Finger / Pen only switch and the soft keys.
fn strip_contents(app: &mut PhotocraftApp, ui: &mut Ui) -> StripActions {
    let mut a = StripActions::default();
    let open = app.pen_touch.settings.soft_keys_open;
    let show_keys = open && app.pen_touch.settings.soft_keys_visible;
    ui.spacing_mut().item_spacing.x = 4.0;
    let handle = if open { "«" } else { "»" };
    if ui
        .add(egui::Button::new(handle).min_size(vec2(22.0, 0.0)))
        .on_hover_text(if open { "Contract the soft keys" } else { "Show the soft keys" })
        .clicked()
    {
        a.toggle = true;
    }
    let pen_only = app.pen_touch.stylus_only();
    if ui
        .add(egui::Button::new(if pen_only { "Pen only" } else { "Finger" }).selected(pen_only).min_size(vec2(62.0, 0.0)))
        .on_hover_text(if pen_only {
            "Pen only: fingers never draw; one finger pans the canvas, two fingers pan, zoom and rotate it. Tap for Finger mode."
        } else {
            "Finger mode: fingers and the pen both draw. Tap for Pen only."
        })
        .clicked()
    {
        a.mode = true;
    }
    if !show_keys {
        return a;
    }
    egui::ScrollArea::horizontal().id_salt("soft-key-scroll").auto_shrink([false, true]).show(ui, |ui| {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 4.0;
            let keys = app.pen_touch.settings.soft_keys.clone();
            for key in &keys {
                soft_key_button(app, ui, key);
            }
            if ui.add(egui::Button::new("…").min_size(vec2(24.0, 0.0))).on_hover_text("Edit the soft keys").clicked() {
                a.settings = true;
            }
        });
    });
    a
}

fn apply_strip(app: &mut PhotocraftApp, a: StripActions) {
    if a.toggle {
        app.pen_touch.settings.soft_keys_open = !app.pen_touch.settings.soft_keys_open;
    }
    if a.mode {
        app.pen_touch.toggle_input_mode();
    }
    if a.settings {
        crate::prefs_ui::open_preferences(app, "tools");
    }
}

/// The strip under the menu bar (desktop): the Finger / Pen only switch and the soft keys. It
/// contracts to a thin handle (the switch stays). Hosts with their own top bar call
/// [`soft_keys_inline`] there and set `pen_touch.strip_in_host_bar`, which turns this panel off.
pub fn soft_key_strip(app: &mut PhotocraftApp, ui: &mut Ui) {
    if app.pen_touch.strip_in_host_bar {
        return;
    }
    let show_keys = app.pen_touch.settings.soft_keys_open && app.pen_touch.settings.soft_keys_visible;
    let t = crate::theme::Tokens::get(ui.ctx());
    let height = if show_keys { 32.0 } else { 22.0 };
    let mut actions = StripActions::default();
    egui::Panel::top("soft_key_strip")
        .exact_size(height)
        .frame(egui::Frame::NONE.fill(t.chrome).inner_margin(egui::Margin { left: 6, right: 6, top: 2, bottom: 2 }))
        .show(ui, |ui| {
            ui.horizontal_centered(|ui| actions = strip_contents(app, ui));
        });
    apply_strip(app, actions);
}

/// The same buttons inside a host's own top bar, in `width` points (they scroll when they do not
/// fit). Sets `pen_touch.strip_in_host_bar` so the panel above stays away.
pub fn soft_keys_inline(app: &mut PhotocraftApp, ui: &mut Ui, width: f32) {
    app.pen_touch.strip_in_host_bar = true;
    let mut actions = StripActions::default();
    ui.allocate_ui_with_layout(vec2(width.max(60.0), 34.0), egui::Layout::left_to_right(egui::Align::Center), |ui| {
        actions = strip_contents(app, ui);
    });
    apply_strip(app, actions);
}

/// How much room the inline strip wants (a handle and the switch, plus the keys while open).
pub fn soft_keys_inline_width(app: &PhotocraftApp) -> f32 {
    let s = &app.pen_touch.settings;
    if s.soft_keys_open && s.soft_keys_visible { 460.0 } else { 100.0 }
}

/// One soft key. Modifier keys latch (tap to hold, tap again to let go); the other keys are held
/// while the finger is down, so a hold works (Space for the Hand tool) and a quick tap is one press.
fn soft_key_button(app: &mut PhotocraftApp, ui: &mut Ui, key: &SoftKey) {
    let spec = key.keys.trim();
    if spec.is_empty() {
        return;
    }
    if spec == super::settings::RECENT {
        if ui.add(egui::Button::new(key.caption()).min_size(vec2(40.0, 0.0))).on_hover_text("Switch to the previous tool").clicked() {
            app.pen_touch.switch_to_recent_tool();
        }
        return;
    }
    let modifier = super::buttons::is_modifier_only(spec);
    let latched = modifier && app.pen_touch.keys.is_latched(spec);
    let held = !modifier && app.pen_touch.keys.is_held(spec);
    let resp = ui.add(egui::Button::new(key.caption()).selected(latched || held).min_size(vec2(40.0, 0.0))).on_hover_text(spec);
    if modifier {
        if resp.clicked() {
            app.pen_touch.keys.latch(spec);
        }
        return;
    }
    let down = resp.is_pointer_button_down_on();
    if down && !held {
        app.pen_touch.keys.press(spec);
    } else if !down && held {
        app.pen_touch.keys.release(spec);
    } else if resp.clicked() && !held {
        app.pen_touch.keys.tap(spec);
    }
}

// ------------------------------------------------------------------ settings

/// Basic keys the Pick menu offers.
const BASIC_KEYS: [&str; 14] =
    ["Ctrl", "Alt", "Shift", "Ctrl+Shift", "Ctrl+Alt", "Alt+Shift", "Space", "Enter", "Escape", "Tab", "Delete", "Backspace", "[", "]"];

/// The settings block at the top of Preferences › Tools. Changes apply at once.
pub fn settings_block(app: &mut PhotocraftApp, ui: &mut Ui) {
    let commands = command_keys(app);
    let mut s = app.pen_touch.settings.clone();
    egui::CollapsingHeader::new(RichText::new("Pen & Touch").strong()).id_salt("pen-touch-settings").default_open(true).show(ui, |ui| {
        ui.label(RichText::new("These settings apply immediately.").weak().small());

        ui.add_space(4.0);
        ui.label(RichText::new("Device").strong());
        ui.horizontal(|ui| {
            ui.radio_value(&mut s.device, DeviceKind::ActiveStylus, "With an active stylus");
            ui.radio_value(&mut s.device, DeviceKind::Touch, "Without an active stylus");
        });
        ui.checkbox(&mut s.ask_at_start, "Ask which device this is when the app starts");

        for (n, cfg) in [(1, &mut s.button1), (2, &mut s.button2)] {
            ui.add_space(6.0);
            pen_button_block(ui, n, cfg, &commands);
        }

        ui.add_space(6.0);
        ui.label(RichText::new("Input mode").strong());
        ui.label(RichText::new("The Finger / Pen only button in the top bar switches quickly.").weak().small());
        ui.horizontal(|ui| {
            ui.radio_value(&mut s.input_mode, InputMode::Finger, "Finger: fingers and pen draw");
            ui.radio_value(&mut s.input_mode, InputMode::StylusOnly, "Pen only: only the pen draws");
        });
        ui.add_enabled_ui(s.stylus_only(), |ui| {
            ui.checkbox(&mut s.stylus_only_zoom, "Two fingers zoom the canvas");
            ui.checkbox(&mut s.stylus_only_rotate, "Two fingers rotate the canvas");
            ui.checkbox(&mut s.stylus_only_pan, "Fingers pan the canvas (one finger, or two)");
        });

        ui.add_space(6.0);
        ui.label(RichText::new("Fingers on an active-stylus screen").strong());
        ui.add_enabled_ui(s.device.has_active_stylus(), |ui| {
            ui.checkbox(&mut s.finger_move, "A finger tap clicks and a drag moves the item (the pen keeps painting; Finger mode)");
            ui.checkbox(&mut s.finger_hold, "Holding a finger stays a held press (no right click)");
        });
        if !s.device.has_active_stylus() {
            ui.label(RichText::new("Choose \"With an active stylus\" to use these.").weak().small());
        }

        ui.add_space(6.0);
        ui.label(RichText::new("Soft keys").strong());
        ui.checkbox(&mut s.soft_keys_visible, "Show the soft keys in the top bar");
        soft_keys_editor(ui, &mut s.soft_keys, &commands);
    });
    if s != app.pen_touch.settings {
        let buttons_changed =
            s.button1 != app.pen_touch.settings.button1 || s.button2 != app.pen_touch.settings.button2 || s.device != app.pen_touch.settings.device;
        app.pen_touch.settings = s;
        if buttons_changed {
            app.pen_touch.release_held();
        }
    }
}

fn pen_button_block(ui: &mut Ui, n: usize, cfg: &mut PenButtonCfg, commands: &[(String, String)]) {
    ui.label(RichText::new(format!("Pen button {n}")).strong());
    ui.checkbox(&mut cfg.enabled, "Use this button");
    ui.add_enabled_ui(cfg.enabled, |ui| {
        shortcut_row(ui, &format!("b{n}-tap"), "Press", &mut cfg.tap, commands, true);
        ui.add_enabled(cfg.tap.trim() != super::settings::RECENT, egui::Checkbox::new(&mut cfg.tap_toggles_back, "Press again returns to the previous tool"));
        shortcut_row(ui, &format!("b{n}-hold"), "Hold", &mut cfg.hold, commands, true);
        ui.horizontal(|ui| {
            ui.label("Hold after");
            ui.add(egui::DragValue::new(&mut cfg.hold_ms).range(100..=3000).suffix(" ms"));
        });
        ui.label(
            RichText::new("Ctrl, Alt, Shift: one press holds it, the next lets go. Hold keys stay down while the button is held. \"@recent\" switches between the last two tools.")
                .weak()
                .small(),
        );
    });
}

/// `label`, a key combination field with Record and Pick, and a warning for a combination PhotoCraft can't press.
fn shortcut_row(ui: &mut Ui, id: &str, label: &str, keys: &mut String, commands: &[(String, String)], enabled: bool) {
    ui.add_enabled_ui(enabled, |ui| {
        ui.horizontal(|ui| {
            ui.label(label);
            keys_editor(ui, egui::Id::new(("pen-touch-keys", id)), keys, commands);
        });
    });
}

/// A key combination field: type it, record it from the keyboard, or pick one.
fn keys_editor(ui: &mut Ui, id: egui::Id, keys: &mut String, commands: &[(String, String)]) {
    let valid = virtual_keys::is_valid(keys);
    let mut edit = egui::TextEdit::singleline(keys).desired_width(130.0).hint_text("Ctrl+Shift+Z");
    if !valid {
        edit = edit.text_color(egui::Color32::LIGHT_RED);
    }
    ui.add(edit);

    let rec_id = id.with("record");
    let recording = ui.data(|d| d.get_temp::<bool>(rec_id)).unwrap_or(false);
    if ui.selectable_label(recording, if recording { "Press a key…" } else { "Record" }).clicked() {
        ui.data_mut(|d| d.insert_temp(rec_id, !recording));
    }
    if recording {
        let got = ui.input(|i| {
            i.events.iter().find_map(|e| match e {
                egui::Event::Key { key, pressed: true, modifiers, .. } if !crate::prefs_ui::is_modifier_key(*key) => {
                    crate::prefs_ui::shortcut_text(*key, *modifiers)
                }
                _ => None,
            })
        });
        if let Some(text) = got {
            *keys = text;
            ui.data_mut(|d| d.insert_temp(rec_id, false));
        }
        ui.ctx().request_repaint();
    }

    ui.menu_button("Pick", |ui| {
        ui.set_min_width(220.0);
        if ui.button("Switch between recent tools").clicked() {
            *keys = super::settings::RECENT.to_string();
            ui.close();
        }
        ui.separator();
        for k in BASIC_KEYS {
            if ui.button(k).clicked() {
                *keys = k.to_string();
                ui.close();
            }
        }
        if keys_nonempty(commands) {
            ui.separator();
            let filter_id = id.with("filter");
            let mut filter = ui.data(|d| d.get_temp::<String>(filter_id)).unwrap_or_default();
            ui.add(egui::TextEdit::singleline(&mut filter).hint_text("Search commands…").desired_width(200.0));
            let needle = filter.trim().to_lowercase();
            ui.data_mut(|d| d.insert_temp(filter_id, filter));
            egui::ScrollArea::vertical().max_height(220.0).id_salt("pick-commands").show(ui, |ui| {
                for (label, sc) in
                    commands.iter().filter(|(l, s)| needle.is_empty() || l.to_lowercase().contains(&needle) || s.to_lowercase().contains(&needle)).take(80)
                {
                    if ui.button(format!("{label}   {sc}")).clicked() {
                        *keys = sc.clone();
                        ui.close();
                    }
                }
            });
        }
    });
    if !valid {
        ui.label(RichText::new("Unknown key").color(egui::Color32::LIGHT_RED).small());
    }
}

fn keys_nonempty(commands: &[(String, String)]) -> bool {
    !commands.is_empty()
}

/// The list of soft keys: edit, remove, add, reset.
fn soft_keys_editor(ui: &mut Ui, keys: &mut Vec<SoftKey>, commands: &[(String, String)]) {
    let mut remove: Option<usize> = None;
    for (i, key) in keys.iter_mut().enumerate() {
        ui.horizontal(|ui| {
            ui.add(egui::TextEdit::singleline(&mut key.label).desired_width(70.0).hint_text("Label"));
            keys_editor(ui, egui::Id::new(("pen-touch-soft", i)), &mut key.keys, commands);
            if ui.small_button("Remove").clicked() {
                remove = Some(i);
            }
        });
    }
    if let Some(i) = remove {
        keys.remove(i);
    }
    ui.horizontal(|ui| {
        if ui.add_enabled(keys.len() < MAX_SOFT_KEYS, egui::Button::new("Add key")).clicked() {
            keys.push(SoftKey::new("Key", "Enter"));
        }
        if ui.button("Reset soft keys").clicked() {
            *keys = default_soft_keys();
        }
    });
    ui.label(RichText::new("Ctrl, Alt, Shift: tap to hold, tap again to let go. Other keys are pressed while you touch them.").weak().small());
}

/// Commands that have a shortcut: label and effective shortcut, for the Pick menu.
fn command_keys(app: &PhotocraftApp) -> Vec<(String, String)> {
    let mut out: Vec<(String, String)> = crate::prefs_ui::shortcut_items(app)
        .into_iter()
        .filter_map(|(id, label, _, default)| {
            let sc = crate::shortcuts::effective_shortcut(app, &id, default.as_deref())?;
            (!sc.is_empty() && virtual_keys::is_valid(&sc)).then_some((label, sc))
        })
        .collect();
    out.sort();
    out.dedup();
    out
}
