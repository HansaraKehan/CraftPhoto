//! Simulated key presses. Nothing here talks to the operating system: key events are added to
//! egui's input before the frame runs, so every shortcut PhotoCraft knows (tool letters, Ctrl+T,
//! custom bindings from Edit › Keyboard Shortcuts, temporary tools such as Space) reacts exactly as
//! it does to the real keyboard.
//!
//! Three ways to press:
//!
//! - [`VirtualKeys::tap`]: press, and let go on the next frame (egui must see both).
//! - [`VirtualKeys::press`] / [`VirtualKeys::release`]: hold keys for as long as needed (the pen
//!   button's hold action, a soft key under a finger).
//! - [`VirtualKeys::latch`]: flip held modifiers on and off (a soft Ctrl key, a pen button that
//!   toggles Shift). Held modifiers are added to everything egui receives, so a latched Ctrl also
//!   makes the next touch a Ctrl-click.

use std::collections::VecDeque;

use egui::{Event, Key, Modifiers, RawInput};

use super::buttons::is_modifier_only;

/// A parsed key combination.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Spec {
    /// Modifiers and one key (`Ctrl+Shift+Z`).
    Keys { mods: Modifiers, key: Key },
    /// Modifiers alone (`Ctrl+Alt`).
    Mods(Modifiers),
}

/// egui keeps `command` in step with `ctrl` (elsewhere) or `mac_cmd` (macOS); keep that true for
/// modifiers built by hand.
pub fn normalize(mut m: Modifiers) -> Modifiers {
    if cfg!(target_os = "macos") {
        m.command = m.command || m.mac_cmd;
        m.mac_cmd = m.command;
    } else {
        m.command = m.command || m.ctrl;
        m.ctrl = m.command;
    }
    m
}

fn flags(m: Modifiers) -> [bool; 4] {
    [m.ctrl, m.alt, m.shift, cfg!(target_os = "macos") && m.mac_cmd]
}

fn from_flags(f: [bool; 4]) -> Modifiers {
    normalize(Modifiers { ctrl: f[0], alt: f[1], shift: f[2], mac_cmd: f[3], command: false })
}

/// Parse `Ctrl+Shift+Z`, `E`, `Enter`, `Ctrl+Alt`; `None` for anything PhotoCraft can't press.
pub fn parse(spec: &str) -> Option<Spec> {
    let spec = spec.trim();
    if spec.is_empty() {
        return None;
    }
    if is_modifier_only(spec) {
        let mut m = Modifiers::NONE;
        for part in spec.split('+') {
            match part.trim() {
                "Ctrl" => m.ctrl = true,
                "Cmd" => m.command = true,
                "Alt" => m.alt = true,
                "Shift" => m.shift = true,
                _ => return None,
            }
        }
        return Some(Spec::Mods(normalize(m)));
    }
    let sc = crate::shortcuts::parse(spec)?;
    Some(Spec::Keys { mods: normalize(sc.modifiers), key: sc.logical_key })
}

/// Is `spec` something [`VirtualKeys`] can press? (The settings editor warns when it is not.)
pub fn is_valid(spec: &str) -> bool {
    spec.trim().is_empty() || spec.trim() == super::settings::RECENT || parse(spec).is_some()
}

fn or(a: Modifiers, b: Modifiers) -> Modifiers {
    Modifiers { alt: a.alt || b.alt, ctrl: a.ctrl || b.ctrl, shift: a.shift || b.shift, mac_cmd: a.mac_cmd || b.mac_cmd, command: a.command || b.command }
}

fn is_none(m: Modifiers) -> bool {
    m == Modifiers::NONE
}

fn key_event(key: Key, pressed: bool, modifiers: Modifiers) -> Event {
    Event::Key { key, physical_key: Some(key), pressed, repeat: false, modifiers }
}

/// Most queued steps (a runaway source can't pile up input without bound).
const MAX_QUEUE: usize = 64;

#[derive(Clone, Debug, Default)]
pub struct VirtualKeys {
    /// Modifiers latched on (soft Ctrl, a toggling pen button): Ctrl, Alt, Shift, ⌘ (macOS).
    latched: [bool; 4],
    /// Keys being held: the spec text, its modifiers and its key.
    held: Vec<(String, Modifiers, Option<Key>)>,
    /// One step per frame: taps are a press step then a release step.
    steps: VecDeque<Vec<Event>>,
    /// Key presses waiting to go into the next frame (holds, which need no release step).
    now: Vec<Event>,
    /// Did the last frame tell egui about held modifiers? (So the release is announced once.)
    sent_mods: bool,
}

impl VirtualKeys {
    /// Modifiers held right now by latches and holds.
    pub fn held_modifiers(&self) -> Modifiers {
        self.held.iter().fold(from_flags(self.latched), |m, (_, h, _)| or(m, *h))
    }

    /// Are all the modifiers of `spec` latched on?
    pub fn is_latched(&self, spec: &str) -> bool {
        match parse(spec) {
            Some(Spec::Mods(m)) => {
                let want = flags(m);
                want.iter().any(|w| *w) && want.iter().zip(self.latched).all(|(w, on)| !*w || on)
            }
            _ => false,
        }
    }

    /// Is anything pressed, latched or waiting? (The shell keeps frames coming while it is.)
    pub fn busy(&self) -> bool {
        !self.steps.is_empty() || !self.now.is_empty()
    }

    /// Is `spec` held down by [`Self::press`]?
    pub fn is_held(&self, spec: &str) -> bool {
        self.held.iter().any(|(s, _, _)| s == spec.trim())
    }

    /// Press and release `spec`, one frame apart.
    pub fn tap(&mut self, spec: &str) {
        let Some(parsed) = parse(spec) else { return };
        if self.steps.len() + 2 > MAX_QUEUE {
            return;
        }
        match parsed {
            Spec::Keys { mods, key } => {
                self.steps.push_back(vec![key_event(key, true, mods)]);
                self.steps.push_back(vec![key_event(key, false, mods)]);
            }
            // Pressing modifiers alone changes nothing a shortcut can see for one frame: latch.
            Spec::Mods(_) => self.latch(spec),
        }
    }

    /// Hold `spec` down until [`Self::release`].
    pub fn press(&mut self, spec: &str) {
        let spec = spec.trim();
        let Some(parsed) = parse(spec) else { return };
        if self.is_held(spec) || self.held.len() >= 8 {
            return;
        }
        match parsed {
            Spec::Keys { mods, key } => {
                self.now.push(key_event(key, true, mods));
                self.held.push((spec.to_string(), mods, Some(key)));
            }
            Spec::Mods(mods) => self.held.push((spec.to_string(), mods, None)),
        }
    }

    /// Let go of `spec` (a no-op when it is not held).
    pub fn release(&mut self, spec: &str) {
        let spec = spec.trim();
        let Some(i) = self.held.iter().position(|(s, _, _)| s == spec) else { return };
        let (_, mods, key) = self.held.remove(i);
        if let Some(key) = key {
            self.now.push(key_event(key, false, mods));
        }
    }

    /// Flip the modifiers of `spec` between held and released: if all of them are on, they all
    /// go off, otherwise they all go on.
    pub fn latch(&mut self, spec: &str) {
        let Some(Spec::Mods(m)) = parse(spec) else { return };
        let on = self.is_latched(spec);
        for (slot, want) in self.latched.iter_mut().zip(flags(m)) {
            if want {
                *slot = !on;
            }
        }
    }

    pub fn clear_latches(&mut self) {
        self.latched = [false; 4];
    }

    /// Let go of everything (focus lost, settings changed).
    pub fn release_all(&mut self) {
        let held = std::mem::take(&mut self.held);
        for (_, mods, key) in held {
            if let Some(key) = key {
                self.now.push(key_event(key, false, mods));
            }
        }
        self.latched = [false; 4];
    }

    /// Put this frame's simulated input into `raw`: key events first (a tap's press and its
    /// release go into different frames), then held modifiers on every
    /// event that carries modifiers.
    pub fn inject(&mut self, raw: &mut RawInput) {
        let mods = self.held_modifiers();
        raw.events.append(&mut self.now);
        if let Some(step) = self.steps.pop_front() {
            raw.events.extend(step);
        }
        // egui has no modifier state on RawInput: it follows `ModifiersChanged` events, and a
        // real keyboard's own events may reset it, so a held modifier is restated every frame.
        if !is_none(mods) {
            raw.events.insert(0, Event::ModifiersChanged(mods));
            self.sent_mods = true;
        } else if self.sent_mods {
            raw.events.insert(0, Event::ModifiersChanged(Modifiers::NONE));
            self.sent_mods = false;
            return;
        } else {
            return;
        }
        for e in &mut raw.events {
            match e {
                Event::Key { modifiers, .. } | Event::PointerButton { modifiers, .. } | Event::MouseWheel { modifiers, .. } => {
                    *modifiers = or(*modifiers, mods)
                }
                _ => {}
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn frame(v: &mut VirtualKeys) -> RawInput {
        let mut raw = RawInput::default();
        v.inject(&mut raw);
        raw
    }

    fn keys(raw: &RawInput) -> Vec<(Key, bool, Modifiers)> {
        raw.events
            .iter()
            .filter_map(|e| match e {
                Event::Key { key, pressed, modifiers, .. } => Some((*key, *pressed, *modifiers)),
                _ => None,
            })
            .collect()
    }

    #[test]
    fn parsing() {
        assert_eq!(parse("E"), Some(Spec::Keys { mods: Modifiers::NONE, key: Key::E }));
        assert!(matches!(parse("Ctrl+Shift+Z"), Some(Spec::Keys { key: Key::Z, mods }) if mods.ctrl && mods.shift && !mods.alt));
        assert!(matches!(parse("Ctrl+Alt"), Some(Spec::Mods(m)) if m.ctrl && m.alt && !m.shift));
        assert_eq!(parse(""), None);
        assert_eq!(parse("Ctrl+Banana"), None);
        assert!(is_valid("") && is_valid("Enter") && !is_valid("Ctrl+Banana"));
    }

    #[test]
    fn a_tap_is_a_press_then_a_release_in_the_next_frame() {
        let mut v = VirtualKeys::default();
        v.tap("Ctrl+Shift+Z");
        assert!(v.busy());
        let a = keys(&frame(&mut v));
        assert_eq!(a.len(), 1);
        assert!(a[0].1 && a[0].0 == Key::Z && a[0].2.ctrl && a[0].2.shift);
        let b = keys(&frame(&mut v));
        assert!(b.len() == 1 && !b[0].1);
        assert!(!v.busy());
        assert!(frame(&mut v).events.is_empty());
    }

    #[test]
    fn a_hold_presses_once_and_releases_once() {
        let mut v = VirtualKeys::default();
        v.press("Space");
        v.press("Space");
        assert_eq!(keys(&frame(&mut v)).len(), 1);
        assert!(v.is_held("Space") && keys(&frame(&mut v)).is_empty());
        v.release("Space");
        let r = keys(&frame(&mut v));
        assert!(r.len() == 1 && !r[0].1);
        v.release("Space");
        assert!(keys(&frame(&mut v)).is_empty());
    }

    #[test]
    fn a_held_modifier_reaches_the_input_state_and_every_event() {
        let mut v = VirtualKeys::default();
        v.press("Alt");
        let mut raw = RawInput::default();
        raw.events.push(Event::PointerButton { pos: egui::pos2(1.0, 1.0), button: egui::PointerButton::Primary, pressed: true, modifiers: Modifiers::NONE });
        v.inject(&mut raw);
        assert!(v.held_modifiers().alt);
        assert!(matches!(raw.events[1], Event::PointerButton { modifiers, .. } if modifiers.alt));
        v.release("Alt");
        frame(&mut v);
        assert!(!v.held_modifiers().alt);
    }

    #[test]
    fn latching_toggles_and_a_combo_works() {
        let mut v = VirtualKeys::default();
        v.latch("Ctrl");
        assert!(v.is_latched("Ctrl") && !v.is_latched("Alt"));
        frame(&mut v);
        let m = v.held_modifiers();
        assert!(m.ctrl && m.command == !cfg!(target_os = "macos"));
        v.latch("Shift");
        v.latch("Ctrl");
        assert!(!v.is_latched("Ctrl") && v.is_latched("Shift"));
        frame(&mut v);
        let m = v.held_modifiers();
        assert!(!m.ctrl && m.shift && !m.command);
        v.latch("Shift");
        frame(&mut v);
        assert_eq!(v.held_modifiers(), Modifiers::NONE);
    }

    #[test]
    fn a_latched_modifier_rides_on_a_tapped_key() {
        let mut v = VirtualKeys::default();
        v.latch("Shift");
        v.tap("B");
        let a = keys(&frame(&mut v));
        assert!(a[0].2.shift);
    }

    #[test]
    fn release_all_lets_go_of_everything() {
        let mut v = VirtualKeys::default();
        v.press("Space");
        v.press("Ctrl");
        v.latch("Shift");
        frame(&mut v);
        v.release_all();
        let raw = frame(&mut v);
        assert!(keys(&raw).iter().all(|k| !k.1) && keys(&raw).len() == 1);
        assert_eq!(v.held_modifiers(), Modifiers::NONE);
        assert!(!v.is_held("Space"));
    }

    #[test]
    fn junk_and_floods_are_harmless() {
        let mut v = VirtualKeys::default();
        v.tap("Nope");
        v.press("Nope");
        v.latch("Nope");
        assert!(!v.busy());
        for _ in 0..1000 {
            v.tap("A");
        }
        let mut n = 0;
        while v.busy() {
            frame(&mut v);
            n += 1;
        }
        assert!(n <= MAX_QUEUE);
    }
}
