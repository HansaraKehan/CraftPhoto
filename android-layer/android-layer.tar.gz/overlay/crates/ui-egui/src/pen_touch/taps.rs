//! Two- and three-finger taps: a short touch of 2 or 3 fingers that barely moves. Pure logic (no
//! egui): the shell feeds it every touch event and it answers with the finger count when the last
//! finger lifts after a tap.
//!
//! A tap needs every finger down within [`JOIN_SECS`] of the first, none of them moving more than
//! [`MOVE_LIMIT`] points, all lifted within [`MAX_SECS`] of the first touch, and no stylus down at
//! any moment of it. Fingers that landed outside the canvas spoil it.

use super::gestures::Phase;

/// Every finger must be down this soon after the first one (seconds).
pub const JOIN_SECS: f64 = 0.30;
/// The whole touch lasts at most this long (seconds).
pub const MAX_SECS: f64 = 0.45;
/// A finger that travels further than this (points) makes it a drag, not a tap.
pub const MOVE_LIMIT: f32 = 18.0;
/// A touch that never ended (a lost event) is forgotten after this long (seconds).
const STALE_SECS: f64 = 5.0;

#[derive(Clone, Copy, Debug)]
struct Down {
    id: u64,
    origin: [f32; 2],
}

#[derive(Clone, Copy, Debug)]
struct Touch {
    started: f64,
    peak: usize,
    ok: bool,
}

#[derive(Clone, Debug, Default)]
pub struct TapDetector {
    down: Vec<Down>,
    touch: Option<Touch>,
    pens: usize,
}

impl TapDetector {
    pub fn reset(&mut self) {
        *self = Self::default();
    }

    /// One touch event at `time` (seconds). `pen`: a stylus contact. `eligible`: the contact started
    /// on the canvas (and gestures are on). Returns the finger count (2 or 3) of a finished tap.
    pub fn touch(&mut self, id: u64, phase: Phase, pos: [f32; 2], time: f64, pen: bool, eligible: bool) -> Option<u8> {
        if !pos[0].is_finite() || !pos[1].is_finite() {
            return None;
        }
        if pen {
            match phase {
                Phase::Start => {
                    self.pens += 1;
                    if let Some(t) = self.touch.as_mut() {
                        t.ok = false;
                    }
                }
                Phase::Move => {}
                Phase::End => self.pens = self.pens.saturating_sub(1),
            }
            return None;
        }
        match phase {
            Phase::Start => {
                if self.touch.is_some_and(|t| time - t.started > STALE_SECS) {
                    self.down.clear();
                    self.touch = None;
                }
                self.down.retain(|d| d.id != id);
                match self.touch.as_mut() {
                    None => self.touch = Some(Touch { started: time, peak: 1, ok: eligible && self.pens == 0 }),
                    Some(t) => {
                        if !eligible || time - t.started > JOIN_SECS {
                            t.ok = false;
                        }
                    }
                }
                if self.down.len() < 16 {
                    self.down.push(Down { id, origin: pos });
                }
                if let Some(t) = self.touch.as_mut() {
                    t.peak = t.peak.max(self.down.len());
                }
                None
            }
            Phase::Move => {
                let far = self.down.iter().find(|d| d.id == id).is_some_and(|d| (pos[0] - d.origin[0]).hypot(pos[1] - d.origin[1]) > MOVE_LIMIT);
                if far && let Some(t) = self.touch.as_mut() {
                    t.ok = false;
                }
                None
            }
            Phase::End => {
                self.down.retain(|d| d.id != id);
                if !self.down.is_empty() {
                    return None;
                }
                let t = self.touch.take()?;
                if t.ok && time - t.started <= MAX_SECS && (2..=3).contains(&t.peak) { u8::try_from(t.peak).ok() } else { None }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn down(d: &mut TapDetector, id: u64, t: f64) -> Option<u8> {
        d.touch(id, Phase::Start, [100.0 + id as f32 * 40.0, 100.0], t, false, true)
    }

    fn up(d: &mut TapDetector, id: u64, t: f64) -> Option<u8> {
        d.touch(id, Phase::End, [100.0 + id as f32 * 40.0, 100.0], t, false, true)
    }

    #[test]
    fn two_fingers_tap() {
        let mut d = TapDetector::default();
        down(&mut d, 1, 0.0);
        down(&mut d, 2, 0.05);
        assert_eq!(up(&mut d, 1, 0.15), None);
        assert_eq!(up(&mut d, 2, 0.17), Some(2));
    }

    #[test]
    fn three_fingers_tap() {
        let mut d = TapDetector::default();
        for (i, t) in [(1, 0.0), (2, 0.02), (3, 0.06)] {
            down(&mut d, i, t);
        }
        up(&mut d, 3, 0.2);
        up(&mut d, 2, 0.21);
        assert_eq!(up(&mut d, 1, 0.22), Some(3));
    }

    #[test]
    fn one_finger_four_fingers_slow_or_moving_are_no_tap() {
        let mut d = TapDetector::default();
        down(&mut d, 1, 0.0);
        assert_eq!(up(&mut d, 1, 0.1), None);
        for i in 1..=4 {
            down(&mut d, i, 0.0);
        }
        for i in 1..=4 {
            assert_eq!(up(&mut d, i, 0.1), None);
        }
        down(&mut d, 1, 0.0);
        down(&mut d, 2, 0.0);
        up(&mut d, 1, 0.3);
        assert_eq!(up(&mut d, 2, 0.6), None);
        down(&mut d, 1, 1.0);
        down(&mut d, 2, 1.0);
        d.touch(1, Phase::Move, [200.0, 100.0], 1.05, false, true);
        up(&mut d, 1, 1.1);
        assert_eq!(up(&mut d, 2, 1.1), None);
    }

    #[test]
    fn a_late_second_finger_or_a_pen_spoils_it() {
        let mut d = TapDetector::default();
        down(&mut d, 1, 0.0);
        down(&mut d, 2, 0.4);
        up(&mut d, 1, 0.42);
        assert_eq!(up(&mut d, 2, 0.43), None);
        down(&mut d, 1, 1.0);
        d.touch(9, Phase::Start, [0.0, 0.0], 1.01, true, true);
        down(&mut d, 2, 1.02);
        up(&mut d, 1, 1.1);
        assert_eq!(up(&mut d, 2, 1.1), None);
        d.touch(9, Phase::End, [0.0, 0.0], 1.2, true, true);
        down(&mut d, 1, 2.0);
        d.touch(2, Phase::Start, [140.0, 100.0], 2.0, false, false);
        up(&mut d, 1, 2.1);
        assert_eq!(up(&mut d, 2, 2.1), None);
    }

    #[test]
    fn it_works_again_after_a_tap() {
        let mut d = TapDetector::default();
        for round in 0..3 {
            let t = f64::from(round);
            down(&mut d, 1, t);
            down(&mut d, 2, t);
            up(&mut d, 1, t + 0.1);
            assert_eq!(up(&mut d, 2, t + 0.1), Some(2));
        }
    }
}
