//! The stylus barrel button state machine. Pure logic (no egui): it turns button presses and
//! releases, and the passing of time, into [`Out`] requests the shell carries out.
//!
//! One button has a *tap* action and a *hold* action:
//!
//! - With no hold action the tap fires the moment the button goes down.
//! - With a hold action, a press released before the hold time is a tap (fired on release); a press
//!   kept down past it starts the hold: its keys go down and stay down until the button is let go.
//! - Presses can be counted: a *double* and a *triple* press have their own actions. When any of
//!   them is set, a press waits [`PenButtonCfg::multi_seconds`] for the next one, and the action of
//!   the count reached fires (at once when the highest configured count is reached).
//! - A tap on a tool key (`E`) remembers the tool it left; the next tap goes back to that tool
//!   instead of sending the key again ([`Out::RestoreTool`]).
//! - A tap made only of modifiers (`Ctrl`, `Alt+Shift`) is a latch: the first tap holds them, the
//!   next lets go ([`Out::Latch`]).

use super::settings::PenButtonCfg;

/// What the shell must do.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Out {
    /// Press and release these keys (one frame apart).
    Tap(String),
    /// A tool key: press and release it, and remember the tool that was active.
    ToolKey(String),
    /// Go back to the tool remembered by the last [`Out::ToolKey`].
    RestoreTool,
    /// Flip these modifiers between held and released.
    Latch(String),
    /// Hold these keys down.
    Press(String),
    /// Let go of keys held by [`Out::Press`].
    Release(String),
}

/// Is this combination made only of modifier names?
pub fn is_modifier_only(spec: &str) -> bool {
    let spec = spec.trim();
    !spec.is_empty() && spec.split('+').all(|p| matches!(p.trim(), "Ctrl" | "Cmd" | "Alt" | "Shift"))
}

/// The state of one barrel button.
#[derive(Clone, Debug, Default)]
pub struct ButtonState {
    down_at: Option<f64>,
    hold_fired: bool,
    held: String,
    /// The press count whose tool key was the last thing sent and has not gone back yet.
    toggled: Option<u8>,
    /// Quick presses counted so far, waiting for the next one or the end of the window.
    count: u8,
    last_release: f64,
}

impl ButtonState {
    pub fn is_down(&self) -> bool {
        self.down_at.is_some()
    }

    /// Waiting for the hold time to pass (the shell keeps frames coming).
    pub fn waiting_for_hold(&self) -> bool {
        self.down_at.is_some() && !self.hold_fired
    }

    /// Waiting for the hold time or for the next press of a multi-press (frames must keep coming).
    pub fn waiting(&self) -> bool {
        self.waiting_for_hold() || self.count > 0
    }

    /// The button went down at `now` (seconds).
    pub fn press(&mut self, cfg: &PenButtonCfg, now: f64) -> Vec<Out> {
        if !cfg.enabled || self.down_at.is_some() {
            return Vec::new();
        }
        self.down_at = Some(now);
        self.hold_fired = false;
        if cfg.hold.trim().is_empty() && cfg.max_level() <= 1 {
            self.count = 0;
            self.fire(cfg, 1)
        } else {
            Vec::new()
        }
    }

    /// Time moved to `now`: a button held past its hold time starts its hold, and a pending
    /// multi-press whose window ran out fires.
    pub fn tick(&mut self, cfg: &PenButtonCfg, now: f64) -> Vec<Out> {
        let Some(t0) = self.down_at else {
            if self.count > 0 && now - self.last_release >= cfg.multi_seconds() {
                let level = std::mem::take(&mut self.count);
                return self.fire(cfg, level);
            }
            return Vec::new();
        };
        if self.hold_fired || cfg.hold.trim().is_empty() || now - t0 < cfg.hold_seconds() {
            return Vec::new();
        }
        self.hold_fired = true;
        self.count = 0;
        self.held = cfg.hold.trim().to_string();
        vec![Out::Press(self.held.clone())]
    }

    /// The button came up at `now`.
    pub fn release(&mut self, cfg: &PenButtonCfg, now: f64) -> Vec<Out> {
        let Some(t0) = self.down_at.take() else { return Vec::new() };
        if self.hold_fired {
            self.hold_fired = false;
            return vec![Out::Release(std::mem::take(&mut self.held))];
        }
        if !cfg.hold.trim().is_empty() && now - t0 >= cfg.hold_seconds() {
            // Held long enough but no frame ran in between: a quick press of the hold keys.
            self.count = 0;
            return vec![Out::Tap(cfg.hold.trim().to_string())];
        }
        if cfg.hold.trim().is_empty() && cfg.max_level() <= 1 {
            // The press already fired when the button went down.
            return Vec::new();
        }
        self.count = self.count.saturating_add(1);
        self.last_release = now;
        if self.count >= cfg.max_level().max(1) {
            let level = std::mem::take(&mut self.count);
            return self.fire(cfg, level);
        }
        Vec::new()
    }

    /// Everything the button holds must be let go (focus lost, settings changed, button removed).
    pub fn cancel(&mut self) -> Vec<Out> {
        self.down_at = None;
        self.count = 0;
        let was_held = std::mem::take(&mut self.hold_fired);
        let keys = std::mem::take(&mut self.held);
        if was_held && !keys.is_empty() { vec![Out::Release(keys)] } else { Vec::new() }
    }

    /// The tool key did not change the tool: the next press of it sends it again.
    pub fn disarm_toggle(&mut self) {
        self.toggled = None;
    }

    pub fn toggled(&self) -> bool {
        self.toggled.is_some()
    }

    /// The action for `level` presses (1 = tap, 2 = double, 3 = triple).
    fn fire(&mut self, cfg: &PenButtonCfg, level: u8) -> Vec<Out> {
        let keys = cfg.action(level).trim();
        if keys.is_empty() {
            return Vec::new();
        }
        if keys == super::settings::RECENT {
            // "Switch to the previous tool" is its own toggle: it needs no tool-key bookkeeping.
            self.toggled = None;
            return vec![Out::Tap(keys.to_string())];
        }
        if self.toggled == Some(level) {
            self.toggled = None;
            return vec![Out::RestoreTool];
        }
        self.toggled = None;
        if is_modifier_only(keys) {
            return vec![Out::Latch(keys.to_string())];
        }
        if cfg.tap_toggles_back {
            self.toggled = Some(level);
            return vec![Out::ToolKey(keys.to_string())];
        }
        vec![Out::Tap(keys.to_string())]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg(tap: &str, hold: &str) -> PenButtonCfg {
        PenButtonCfg { enabled: true, tap: tap.into(), hold: hold.into(), tap_toggles_back: true, hold_ms: 300, ..Default::default() }
    }

    fn multi(tap: &str, double: &str, triple: &str) -> PenButtonCfg {
        PenButtonCfg { double: double.into(), triple: triple.into(), multi_ms: 300, ..cfg(tap, "") }
    }

    /// One quick press and release, `gap` seconds after `t`.
    fn quick(b: &mut ButtonState, c: &PenButtonCfg, t: f64) -> Vec<Out> {
        let mut out = b.press(c, t);
        out.extend(b.release(c, t + 0.05));
        out
    }

    #[test]
    fn a_double_press_fires_its_own_action_at_once() {
        let (c, mut b) = (multi("B", "E", ""), ButtonState::default());
        assert!(quick(&mut b, &c, 0.0).is_empty(), "the single press waits for a possible second");
        assert_eq!(quick(&mut b, &c, 0.2), vec![Out::ToolKey("E".into())]);
        assert!(b.tick(&c, 5.0).is_empty(), "the single press did not fire as well");
    }

    #[test]
    fn a_single_press_fires_when_the_window_runs_out() {
        let (c, mut b) = (multi("B", "E", ""), ButtonState::default());
        assert!(quick(&mut b, &c, 0.0).is_empty());
        assert!(b.waiting());
        assert!(b.tick(&c, 0.2).is_empty());
        let out = b.tick(&c, 0.4);
        assert_eq!(out.len(), 1, "{out:?}");
        assert!(!b.waiting());
    }

    #[test]
    fn the_same_double_press_again_goes_back_to_the_previous_tool() {
        let (c, mut b) = (multi("", "E", ""), ButtonState::default());
        quick(&mut b, &c, 0.0);
        assert_eq!(quick(&mut b, &c, 0.15), vec![Out::ToolKey("E".into())]);
        quick(&mut b, &c, 2.0);
        assert_eq!(quick(&mut b, &c, 2.15), vec![Out::RestoreTool]);
    }

    #[test]
    fn a_triple_press_waits_for_the_third() {
        let (c, mut b) = (multi("A", "B", "C"), ButtonState::default());
        quick(&mut b, &c, 0.0);
        assert!(quick(&mut b, &c, 0.15).is_empty(), "two presses might still become three");
        let out = quick(&mut b, &c, 0.3);
        assert!(matches!(out.as_slice(), [Out::ToolKey(k)] if k == "C"), "{out:?}");
    }

    #[test]
    fn a_hold_cancels_pending_presses() {
        let mut c = multi("A", "B", "");
        c.hold = "Space".into();
        let mut b = ButtonState::default();
        quick(&mut b, &c, 0.0);
        b.press(&c, 0.2);
        assert_eq!(b.tick(&c, 0.7), vec![Out::Press("Space".into())]);
        assert_eq!(b.release(&c, 1.0), vec![Out::Release("Space".into())]);
        assert!(b.tick(&c, 3.0).is_empty(), "nothing fires from the cancelled press");
    }

    #[test]
    fn the_recent_tool_action_is_a_plain_tap_every_time() {
        let mut b = ButtonState::default();
        let c = cfg("@recent", "");
        assert_eq!(b.press(&c, 0.0), vec![Out::Tap("@recent".into())]);
        b.release(&c, 0.1);
        assert_eq!(b.press(&c, 1.0), vec![Out::Tap("@recent".into())]);
    }

    #[test]
    fn a_tool_key_tap_fires_at_once_and_the_next_tap_goes_back() {
        let (c, mut b) = (cfg("E", ""), ButtonState::default());
        assert_eq!(b.press(&c, 0.0), vec![Out::ToolKey("E".into())]);
        assert!(b.release(&c, 0.05).is_empty());
        assert_eq!(b.press(&c, 1.0), vec![Out::RestoreTool]);
        b.release(&c, 1.05);
        // And the cycle starts over.
        assert_eq!(b.press(&c, 2.0), vec![Out::ToolKey("E".into())]);
    }

    #[test]
    fn a_tool_key_that_changed_nothing_is_sent_again() {
        let (c, mut b) = (cfg("E", ""), ButtonState::default());
        b.press(&c, 0.0);
        b.release(&c, 0.1);
        b.disarm_toggle();
        assert_eq!(b.press(&c, 1.0), vec![Out::ToolKey("E".into())]);
    }

    #[test]
    fn a_tap_that_is_not_a_tool_key_repeats() {
        let mut c = cfg("Ctrl+Z", "");
        c.tap_toggles_back = false;
        let mut b = ButtonState::default();
        for t in [0.0, 1.0] {
            assert_eq!(b.press(&c, t), vec![Out::Tap("Ctrl+Z".into())]);
            b.release(&c, t + 0.1);
        }
    }

    #[test]
    fn modifier_only_taps_latch_and_unlatch() {
        let (c, mut b) = (cfg("Ctrl+Shift", ""), ButtonState::default());
        assert_eq!(b.press(&c, 0.0), vec![Out::Latch("Ctrl+Shift".into())]);
        b.release(&c, 0.1);
        assert_eq!(b.press(&c, 1.0), vec![Out::Latch("Ctrl+Shift".into())]);
    }

    #[test]
    fn with_a_hold_action_a_quick_press_taps_on_release() {
        let (c, mut b) = (cfg("E", "Space"), ButtonState::default());
        assert!(b.press(&c, 0.0).is_empty());
        assert!(b.tick(&c, 0.1).is_empty());
        assert_eq!(b.release(&c, 0.15), vec![Out::ToolKey("E".into())]);
    }

    #[test]
    fn a_long_press_holds_its_keys_until_release_and_never_taps() {
        let (c, mut b) = (cfg("E", "Space"), ButtonState::default());
        assert!(b.press(&c, 0.0).is_empty());
        assert!(b.waiting_for_hold());
        assert_eq!(b.tick(&c, 0.4), vec![Out::Press("Space".into())]);
        assert!(!b.waiting_for_hold());
        assert!(b.tick(&c, 0.9).is_empty(), "held once");
        assert_eq!(b.release(&c, 1.0), vec![Out::Release("Space".into())]);
        assert!(!b.is_down());
        // The tap state was untouched.
        assert!(!b.toggled());
    }

    #[test]
    fn a_hold_that_no_frame_saw_is_a_quick_press_of_the_hold_keys() {
        let (c, mut b) = (cfg("E", "Alt"), ButtonState::default());
        b.press(&c, 0.0);
        assert_eq!(b.release(&c, 2.0), vec![Out::Tap("Alt".into())]);
    }

    #[test]
    fn hold_only_buttons_do_nothing_on_a_tap() {
        let (c, mut b) = (cfg("", "Shift"), ButtonState::default());
        b.press(&c, 0.0);
        assert!(b.release(&c, 0.1).is_empty());
        b.press(&c, 1.0);
        assert_eq!(b.tick(&c, 1.5), vec![Out::Press("Shift".into())]);
        assert_eq!(b.release(&c, 2.0), vec![Out::Release("Shift".into())]);
    }

    #[test]
    fn disabled_buttons_and_repeated_presses_are_ignored() {
        let mut c = cfg("E", "");
        c.enabled = false;
        let mut b = ButtonState::default();
        assert!(b.press(&c, 0.0).is_empty() && !b.is_down());
        c.enabled = true;
        assert_eq!(b.press(&c, 0.0).len(), 1);
        assert!(b.press(&c, 0.01).is_empty(), "a second press without a release");
        assert!(b.release(&c, 0.1).is_empty());
        assert!(b.release(&c, 0.2).is_empty(), "a release without a press");
    }

    #[test]
    fn cancel_lets_go_of_held_keys_once() {
        let (c, mut b) = (cfg("", "Ctrl"), ButtonState::default());
        b.press(&c, 0.0);
        b.tick(&c, 1.0);
        assert_eq!(b.cancel(), vec![Out::Release("Ctrl".into())]);
        assert!(b.cancel().is_empty());
        assert!(b.release(&c, 2.0).is_empty());
    }

    #[test]
    fn modifier_only_detection() {
        for s in ["Ctrl", "Alt", "Shift", "Cmd", "Ctrl+Shift", "Ctrl+Alt+Shift"] {
            assert!(is_modifier_only(s), "{s}");
        }
        for s in ["", "E", "Ctrl+Z", "Ctrl+", "Space", "Ctrl++"] {
            assert!(!is_modifier_only(s), "{s}");
        }
    }
}
