//! Pen & Touch settings: what is stored in `Preferences::pen_touch` (JSON owned by the shell).
//!
//! Every behaviour has its own on/off switch, so a user can keep the pen button actions and turn
//! the finger behaviour off, or the other way round. Key combinations are written the way the
//! rest of PhotoCraft writes shortcuts (`Ctrl+Shift+Z`, `E`, `Enter`); a combination made only of
//! modifiers (`Ctrl`, `Alt+Shift`) is a *latch*: one press holds it, the next press lets go.

use serde::{Deserialize, Serialize};

/// Which kind of device the user draws on.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum DeviceKind {
    /// Not chosen yet (the start-up question has not been answered). Behaves like [`Self::Touch`].
    #[default]
    Unset,
    /// A screen with an active stylus (S Pen, Surface Pen, Apple Pencil style): the pen paints,
    /// fingers move things.
    ActiveStylus,
    /// A screen without an active stylus: fingers paint, and nothing presses Enter for you.
    Touch,
}

impl DeviceKind {
    pub fn has_active_stylus(self) -> bool {
        self == DeviceKind::ActiveStylus
    }
}

/// What touching the canvas does.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum InputMode {
    /// Fingers and the pen both work the tools.
    #[default]
    Finger,
    /// Only the pen works the tools. A finger on the canvas never draws; two fingers pan, zoom and
    /// rotate the canvas.
    StylusOnly,
}

impl InputMode {
    pub fn toggled(self) -> Self {
        match self {
            InputMode::Finger => InputMode::StylusOnly,
            InputMode::StylusOnly => InputMode::Finger,
        }
    }
}

/// A key combination that is no key: switch to the tool used before this one (and back again).
pub const RECENT: &str = "@recent";

fn first_version() -> u32 {
    1
}

/// What a stored settings file's layout is (older ones are brought up to date on load).
pub const VERSION: u32 = 3;

/// One stylus barrel button: a tap action, and a separate action while it is held.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PenButtonCfg {
    pub enabled: bool,
    /// Keys sent when the button is pressed and let go quickly. Empty: nothing.
    pub tap: String,
    /// A tap that switches tools (`E` for the Eraser) goes back to the previous tool on the next
    /// tap instead of sending the keys again.
    pub tap_toggles_back: bool,
    /// Keys sent when the button is pressed twice quickly. Empty: nothing (two taps are two taps).
    pub double: String,
    /// Keys sent when the button is pressed three times quickly. Empty: nothing.
    pub triple: String,
    /// How long after a press the next one still counts toward the same multi-press, in milliseconds.
    pub multi_ms: u32,
    /// Keys held down for as long as the button is held past [`Self::hold_ms`]. Empty: nothing.
    pub hold: String,
    /// How long the button must be held before it counts as a hold, in milliseconds.
    pub hold_ms: u32,
}

impl Default for PenButtonCfg {
    fn default() -> Self {
        Self {
            enabled: false,
            tap: String::new(),
            tap_toggles_back: true,
            double: String::new(),
            triple: String::new(),
            multi_ms: 300,
            hold: String::new(),
            hold_ms: 350,
        }
    }
}

impl PenButtonCfg {
    /// The keys for `level` presses: 1 = tap, 2 = double, 3 = triple.
    pub fn action(&self, level: u8) -> &str {
        match level {
            1 => &self.tap,
            2 => &self.double,
            3 => &self.triple,
            _ => "",
        }
    }

    /// The most presses that have an action (0 when none does).
    pub fn max_level(&self) -> u8 {
        (1..=3u8).rev().find(|l| !self.action(*l).trim().is_empty()).unwrap_or(0)
    }

    /// The multi-press window, kept in a range a hand can manage.
    pub fn multi_seconds(&self) -> f64 {
        f64::from(self.multi_ms.clamp(150, 800)) / 1000.0
    }

    /// The hold time, kept in a range a hand can manage.
    pub fn hold_seconds(&self) -> f64 {
        f64::from(self.hold_ms.clamp(100, 3000)) / 1000.0
    }
}

/// What a two- or three-finger tap does.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct FingerTapCfg {
    pub enabled: bool,
    /// Keys sent when the tap happens (a key, a combination, or `@recent`). Empty: nothing.
    pub action: String,
}

impl FingerTapCfg {
    pub fn new(enabled: bool, action: &str) -> Self {
        Self { enabled, action: action.into() }
    }

    /// The keys to send, when the tap is on and has an action.
    pub fn keys(&self) -> Option<&str> {
        let a = self.action.trim();
        (self.enabled && !a.is_empty()).then_some(a)
    }
}

impl Default for FingerTapCfg {
    fn default() -> Self {
        Self { enabled: true, action: String::new() }
    }
}

/// A button of the soft-key strip.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct SoftKey {
    pub label: String,
    /// The key combination it sends (see the module documentation).
    pub keys: String,
}

impl SoftKey {
    pub fn new(label: &str, keys: &str) -> Self {
        Self { label: label.into(), keys: keys.into() }
    }

    /// What the button shows: its label, or its keys when it has none.
    pub fn caption(&self) -> &str {
        if !self.label.trim().is_empty() {
            self.label.as_str()
        } else if self.keys.trim() == RECENT {
            "Recent tool"
        } else {
            self.keys.as_str()
        }
    }
}

/// Most soft keys the strip keeps (a hand-edited file can't flood the bar).
pub const MAX_SOFT_KEYS: usize = 24;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PenTouchSettings {
    /// Layout of the stored settings; see [`VERSION`]. A file without it is the first layout.
    #[serde(default = "first_version")]
    pub version: u32,
    // ---- device
    pub device: DeviceKind,
    /// Ask which device this is each time the app starts.
    pub ask_at_start: bool,

    // ---- pen buttons
    /// The stylus's first barrel button.
    pub button1: PenButtonCfg,
    /// The stylus's second barrel button (or the eraser button of pens that have one).
    pub button2: PenButtonCfg,

    // ---- finger or stylus-only input
    pub input_mode: InputMode,
    /// Stylus-only mode: two fingers zoom the canvas.
    pub stylus_only_zoom: bool,
    /// Stylus-only mode: two fingers rotate the canvas.
    pub stylus_only_rotate: bool,
    /// Stylus-only mode: two fingers pan the canvas.
    pub stylus_only_pan: bool,

    /// The first-launch quick tour was finished or skipped.
    pub tour_done: bool,

    // ---- finger taps
    /// A short tap of two fingers on the canvas (default: Undo).
    pub tap2: FingerTapCfg,
    /// A short tap of three fingers on the canvas (default: Redo).
    pub tap3: FingerTapCfg,

    // ---- panels and windows
    /// A vertical swipe that starts on a list row or slider in a panel or window scrolls it (those
    /// widgets otherwise keep the drag for themselves, so only the scroll bar worked).
    pub touch_scroll: bool,

    // ---- fingers on an active-stylus device
    /// A finger drag moves the picked item (the Move tool while the finger is down) instead of
    /// painting; the pen keeps painting.
    pub finger_move: bool,
    /// A finger held still stays a held press; it never turns into a right click.
    pub finger_hold: bool,

    // ---- pen pointer
    /// A ring follows the pen over the screen (hovering and touching), so you see where it is.
    pub show_pen_pointer: bool,
    /// The ring's diameter in points.
    pub pen_pointer_size: f32,
    /// The ring takes the current brush's size (at the view's zoom, and the pen's pressure when the
    /// brush uses pressure for size) while a brush-like tool is active; the size above is the
    /// fallback for other tools.
    pub pen_pointer_follows_brush: bool,

    // ---- soft keys
    /// The soft-key strip is shown.
    pub soft_keys_visible: bool,
    /// The strip is open (not contracted to its handle).
    pub soft_keys_open: bool,
    pub soft_keys: Vec<SoftKey>,
}

impl Default for PenTouchSettings {
    fn default() -> Self {
        Self {
            version: VERSION,
            device: DeviceKind::Unset,
            ask_at_start: true,
            button1: PenButtonCfg { enabled: true, tap: RECENT.into(), tap_toggles_back: false, hold: "Space".into(), ..PenButtonCfg::default() },
            button2: PenButtonCfg { enabled: false, tap: "Ctrl+Z".into(), tap_toggles_back: false, hold: "Alt".into(), ..PenButtonCfg::default() },
            input_mode: InputMode::Finger,
            stylus_only_zoom: true,
            stylus_only_rotate: true,
            stylus_only_pan: true,
            tour_done: false,
            tap2: FingerTapCfg::new(true, "Ctrl+Z"),
            tap3: FingerTapCfg::new(true, "Ctrl+Shift+Z"),
            touch_scroll: true,
            finger_move: true,
            finger_hold: true,
            show_pen_pointer: false,
            pen_pointer_size: 28.0,
            pen_pointer_follows_brush: true,
            soft_keys_visible: true,
            soft_keys_open: true,
            soft_keys: default_soft_keys(),
        }
    }
}

/// The strip a new install starts with.
pub fn default_soft_keys() -> Vec<SoftKey> {
    vec![
        SoftKey::new("Ctrl", "Ctrl"),
        SoftKey::new("Alt", "Alt"),
        SoftKey::new("Shift", "Shift"),
        SoftKey::new("Enter", "Enter"),
        SoftKey::new("Esc", "Escape"),
    ]
}

impl PenTouchSettings {
    /// Read the stored JSON. A missing, hand-edited or old value never breaks the app: whatever
    /// does not read back keeps its default.
    pub fn from_json(v: &serde_json::Value) -> Self {
        let mut s = serde_json::from_value::<Self>(v.clone()).unwrap_or_default();
        if s.version < 2 {
            // Version 2: the first pen button switches between recent tools by default, and the
            // strip has no Undo / Redo (the top bar has them).
            if s.button1.tap == "E" && s.button1.hold == "Space" {
                s.button1.tap = RECENT.into();
                s.button1.tap_toggles_back = false;
            }
            s.soft_keys.retain(|k| !((k.keys == "Ctrl+Z" && k.label == "Undo") || (k.keys == "Ctrl+Shift+Z" && k.label == "Redo")));
            s.version = VERSION;
        }
        s.soft_keys.truncate(MAX_SOFT_KEYS);
        s
    }

    pub fn to_json(&self) -> serde_json::Value {
        serde_json::to_value(self).unwrap_or(serde_json::Value::Null)
    }

    /// Finger behaviour that only makes sense next to an active stylus.
    pub fn finger_move_on(&self) -> bool {
        self.device.has_active_stylus() && self.finger_move
    }

    pub fn finger_hold_on(&self) -> bool {
        self.device.has_active_stylus() && self.finger_hold
    }

    /// The pointer ring's diameter, kept in a range that stays visible and does not cover the page.
    pub fn pointer_diameter(&self) -> f32 {
        if self.pen_pointer_size.is_finite() { self.pen_pointer_size.clamp(8.0, 120.0) } else { 28.0 }
    }

    pub fn stylus_only(&self) -> bool {
        self.input_mode == InputMode::StylusOnly
    }

    /// Do finger taps count? Only where a finger on the canvas does not paint: Pen only mode, or an
    /// active-stylus screen whose fingers move things.
    pub fn finger_taps_on(&self) -> bool {
        self.stylus_only() || self.finger_move_on()
    }

    /// The keys a tap of `fingers` (2 or 3) sends.
    pub fn tap_keys(&self, fingers: u8) -> Option<&str> {
        match fingers {
            2 => self.tap2.keys(),
            3 => self.tap3.keys(),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_round_trip_and_a_bad_value_falls_back() {
        let d = PenTouchSettings::default();
        assert_eq!(PenTouchSettings::from_json(&d.to_json()), d);
        assert_eq!(PenTouchSettings::from_json(&serde_json::Value::Null), d);
        assert_eq!(PenTouchSettings::from_json(&serde_json::json!("junk")), d);
        let partial = PenTouchSettings::from_json(&serde_json::json!({"device": "activeStylus"}));
        assert_eq!(partial.device, DeviceKind::ActiveStylus);
        assert_eq!(partial.input_mode, InputMode::Finger);
        assert!(partial.stylus_only_zoom);
    }

    #[test]
    fn finger_behaviour_needs_an_active_stylus() {
        let mut s = PenTouchSettings::default();
        assert!(!s.finger_move_on() && !s.finger_hold_on());
        s.device = DeviceKind::Touch;
        assert!(!s.finger_move_on());
        s.device = DeviceKind::ActiveStylus;
        assert!(s.finger_move_on() && s.finger_hold_on());
        s.finger_move = false;
        assert!(!s.finger_move_on());
    }

    #[test]
    fn finger_taps_default_to_undo_and_redo_and_can_be_turned_off() {
        let mut s = PenTouchSettings::default();
        assert_eq!(s.tap_keys(2), Some("Ctrl+Z"));
        assert_eq!(s.tap_keys(3), Some("Ctrl+Shift+Z"));
        assert_eq!(s.tap_keys(4), None);
        s.tap2.enabled = false;
        assert_eq!(s.tap_keys(2), None);
        s.tap3.action = "  ".into();
        assert_eq!(s.tap_keys(3), None);
        // An older file without taps gets the defaults.
        let old = PenTouchSettings::from_json(&serde_json::json!({"version": 2}));
        assert_eq!(old.tap2, FingerTapCfg::new(true, "Ctrl+Z"));
        assert!(!old.finger_taps_on());
        let mut p = PenTouchSettings::default();
        p.input_mode = InputMode::StylusOnly;
        assert!(p.finger_taps_on());
    }

    #[test]
    fn the_input_mode_toggles_and_is_stored() {
        let mut s = PenTouchSettings::default();
        assert!(!s.stylus_only());
        s.input_mode = s.input_mode.toggled();
        assert!(s.stylus_only());
        assert_eq!(PenTouchSettings::from_json(&s.to_json()).input_mode, InputMode::StylusOnly);
        assert_eq!(s.input_mode.toggled(), InputMode::Finger);
    }

    #[test]
    fn the_soft_key_list_is_capped() {
        let many = serde_json::json!({"softKeys": (0..100).map(|i| serde_json::json!({"label": i.to_string(), "keys": "A"})).collect::<Vec<_>>()});
        assert_eq!(PenTouchSettings::from_json(&many).soft_keys.len(), MAX_SOFT_KEYS);
    }

    #[test]
    fn an_old_file_gets_the_recent_tool_button_and_loses_undo_redo() {
        let old = serde_json::json!({
            "button1": {"enabled": true, "tap": "E", "tapTogglesBack": true, "hold": "Space", "holdMs": 350},
            "softKeys": [{"label": "Ctrl", "keys": "Ctrl"}, {"label": "Undo", "keys": "Ctrl+Z"}, {"label": "Redo", "keys": "Ctrl+Shift+Z"}, {"label": "Mine", "keys": "B"}]
        });
        let s = PenTouchSettings::from_json(&old);
        assert_eq!(s.button1.tap, RECENT);
        assert!(!s.button1.tap_toggles_back);
        assert_eq!(s.soft_keys.iter().map(|k| k.label.as_str()).collect::<Vec<_>>(), ["Ctrl", "Mine"]);
        assert_eq!(s.version, VERSION);
        // A button the user changed is left alone.
        let own = serde_json::json!({"button1": {"enabled": true, "tap": "B", "hold": ""}});
        assert_eq!(PenTouchSettings::from_json(&own).button1.tap, "B");
    }
}
