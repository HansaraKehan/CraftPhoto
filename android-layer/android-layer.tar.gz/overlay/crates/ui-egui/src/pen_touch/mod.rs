//! Pen & Touch: stylus barrel buttons, simulated key presses, the finger / stylus-only input mode,
//! finger behaviour on active-stylus screens, and the soft-key strip.
//!
//! Everything works by *adding input* before egui's frame runs (`raw_input`), so the editor's own
//! shortcut handling stays the one place that decides what a key does:
//!
//! - [`virtual_keys`]: simulated key presses and latched modifiers.
//! - [`buttons`]: the barrel button state machine (tap, hold, toggle back to the previous tool).
//! - [`gestures`]: two-finger pan, pinch and twist from raw touch contacts.
//! - [`settings`]: what is stored in `Preferences::pen_touch`.
//! - [`ui`]: the settings block (Preferences › Tools), the start-up question, the soft-key strip.
//!
//! How a platform reports the stylus barrel buttons: as the mouse's *Back* (first button) and
//! *Forward* (second button) buttons. The Android window layer maps `BUTTON_STYLUS_PRIMARY` and
//! `BUTTON_STYLUS_SECONDARY` to them (see `android-layer`); any other source can call
//! [`PenTouch::pen_button`]. A stylus touch carries [`PEN_TOUCH_FLAG`] in its touch id, so a pen
//! contact is told from a finger.
//!
//! **Stylus-only mode** (the Finger / Pen only button in the strip): a finger that lands on the
//! canvas never reaches the tools, and two fingers pan, zoom and rotate the view about their
//! midpoint. Fingers on the panels, menus and floating windows work as usual. The pen's own
//! pointer events are rebuilt from its touch events while a finger or palm is down, because egui
//! follows only the first contact.

pub mod buttons;
pub mod gestures;
pub mod settings;
pub mod ui;
pub mod virtual_keys;

use std::time::Duration;

use egui::{Event, PointerButton, pos2};

use crate::PhotocraftApp;
use crate::state::Tool;
use buttons::{ButtonState, Out};
use gestures::{Gestures, Phase};
pub use settings::{DeviceKind, PenButtonCfg, PenTouchSettings, RECENT, SoftKey};
pub use virtual_keys::VirtualKeys;

/// Set in the touch id of a contact made by a stylus tip.
pub const PEN_TOUCH_FLAG: u64 = 1 << 48;
/// Set in the touch id of a contact made by a stylus's eraser end.
pub const ERASER_TOUCH_FLAG: u64 = 1 << 49;

/// Is this touch id a stylus contact?
pub fn is_pen_id(id: u64) -> bool {
    id & (PEN_TOUCH_FLAG | ERASER_TOUCH_FLAG) != 0
}

/// A touch contact being followed.
#[derive(Clone, Copy, Debug)]
struct Contact {
    id: u64,
    pen: bool,
    /// A finger that landed on the canvas in stylus-only mode: the tools never see it.
    blocked: bool,
    /// It landed on the canvas (not on a panel, menu or window).
    canvas: bool,
    /// Where it was last seen (a lone blocked finger pans the view by what it moved; a scrolling
    /// finger scrolls by what it moved).
    last: egui::Pos2,
    /// Where and when it landed.
    press: egui::Pos2,
    started: f64,
    /// A swipe on a panel or window that this module turned into scrolling.
    scroll: bool,
}

#[derive(Debug, Default)]
pub struct PenTouch {
    pub settings: PenTouchSettings,
    /// The settings as last written to the preferences.
    saved: Option<PenTouchSettings>,
    pub keys: VirtualKeys,
    buttons: [ButtonState; 2],
    gestures: Gestures,
    contacts: Vec<Contact>,

    // ---- barrel buttons
    /// The tool a tool-key tap left, per button.
    tool_before: [Option<Tool>; 2],
    /// Frames since a tool key was sent, per button, while checking that it changed the tool.
    tool_check: [Option<u32>; 2],
    restore_tool: Vec<Tool>,

    /// Where the pen is (hovering or touching) and when it was last seen, for the pointer ring.
    pen_pos: Option<egui::Pos2>,
    pen_seen: f64,
    pen_touching: bool,
    /// The pen's latest pressure, 0..1.
    pen_force: f32,
    /// The tool in use and the one before it ("switch between recent tools").
    recent: [Option<Tool>; 2],
    /// A "switch to the previous tool" was asked for (by a pen button or a soft key).
    switch_recent: bool,
    /// A pen contact was down at some point of the frame.
    pen_frame: bool,
    /// The strip is drawn by the host app's own top bar ([`ui::soft_keys_inline`]), not as a panel.
    pub strip_in_host_bar: bool,

    /// The last frame's finger gesture.
    pub frame: Option<gestures::Frame>,
    /// A pen contact whose pointer press this module built itself (stylus-only mode).
    synth_pen: Option<u64>,

    // ---- fingers on an active-stylus screen
    finger_tool_before: Option<Tool>,

    // ---- start-up question
    /// Shells that want the question at launch turn this on ([`PhotocraftApp::enable_pen_touch_prompt`]).
    pub prompt_enabled: bool,
    pub(crate) prompt: ui::Prompt,
}

impl PenTouch {
    /// Ask for the previous tool (the "Switch between recent tools" action).
    pub fn switch_to_recent_tool(&mut self) {
        self.switch_recent = true;
    }

    /// Report a stylus barrel button from a source that does not use the mouse-button mapping.
    /// `index` 0 is the first button, 1 the second.
    pub fn pen_button(&mut self, index: usize, pressed: bool, now: f64) -> Vec<Out> {
        let (Some(cfg), Some(state)) = (button_cfg(&self.settings, index), self.buttons.get_mut(index)) else { return Vec::new() };
        if pressed { state.press(cfg, now) } else { state.release(cfg, now) }
    }

    /// Is stylus-only mode on?
    pub fn stylus_only(&self) -> bool {
        self.settings.stylus_only()
    }

    /// The Finger / Pen only button: flip the mode.
    pub fn toggle_input_mode(&mut self) {
        self.settings.input_mode = self.settings.input_mode.toggled();
        self.gestures.reset();
        self.contacts.clear();
        self.synth_pen = None;
    }

    /// Let go of the keys the pen buttons and soft keys hold (a button's settings changed).
    pub fn release_held(&mut self) {
        for b in &mut self.buttons {
            let _ = b.cancel();
        }
        self.keys.release_all();
    }

    /// Let go of everything simulated.
    pub fn release_everything(&mut self) {
        self.release_held();
        self.gestures.reset();
        self.contacts.clear();
        self.synth_pen = None;
    }

    fn contact(&self, id: u64) -> Option<Contact> {
        self.contacts.iter().find(|c| c.id == id).copied()
    }
}

fn button_cfg(s: &PenTouchSettings, index: usize) -> Option<&PenButtonCfg> {
    match index {
        0 => Some(&s.button1),
        1 => Some(&s.button2),
        _ => None,
    }
}

impl PhotocraftApp {
    /// Ask which device this is when the app starts (the question has a "Don't ask again" button
    /// and a switch in Preferences › Tools). Shells call this once after construction.
    pub fn enable_pen_touch_prompt(&mut self) {
        self.pen_touch.prompt_enabled = true;
    }
}

/// Read the stored settings at launch.
pub fn restore(app: &mut PhotocraftApp) {
    let saved = app.session.prefs().pen_touch.clone();
    app.pen_touch.settings = PenTouchSettings::from_json(&saved);
    app.pen_touch.saved = Some(app.pen_touch.settings.clone());
}

/// Write the settings to the preferences when they changed. Cheap: one struct compare per frame.
pub fn persist(app: &mut PhotocraftApp) {
    if app.pen_touch.saved.as_ref() == Some(&app.pen_touch.settings) {
        return;
    }
    app.pen_touch.saved = Some(app.pen_touch.settings.clone());
    let now = app.pen_touch.settings.to_json();
    if app.session.prefs().pen_touch != now {
        app.session.prefs.edit(|p| p.pen_touch = now);
    }
}

/// Add this frame's simulated input to `raw` and follow the touch contacts. Called from
/// `raw_input_hook`, after the pen contacts were observed.
pub(crate) fn raw_input(app: &mut PhotocraftApp, ctx: &egui::Context, raw: &mut egui::RawInput) {
    let now = raw.time.unwrap_or(0.0);

    // Focus lost: nothing may stay held.
    if raw.events.iter().any(|e| matches!(e, Event::WindowFocused(false))) {
        app.pen_touch.release_everything();
    }

    pen_buttons(app, ctx, raw, now);
    track_pen_pointer(app, raw, now);
    touches(app, ctx, raw);
    app.pen_touch.keys.inject(raw);
    if app.pen_touch.keys.busy() {
        ctx.request_repaint();
    }
}

/// Follow the pen for the pointer ring: its touch contacts, and its hover (which the platform layer
/// reports as pointer moves in a frame that has no touch events and no finger down).
fn track_pen_pointer(app: &mut PhotocraftApp, raw: &egui::RawInput, now: f64) {
    if !app.pen_touch.settings.show_pen_pointer {
        app.pen_touch.pen_pos = None;
        return;
    }
    let touch_frame = raw.events.iter().any(|e| matches!(e, Event::Touch { .. }));
    let finger_down = app.pen_touch.contacts.iter().any(|c| !c.pen);
    for e in &raw.events {
        match e {
            Event::Touch { id, phase, pos, force, .. } if is_pen_contact(app, id.0) => {
                app.pen_touch.pen_force = force.unwrap_or(1.0);
                app.pen_touch.pen_pos = Some(*pos);
                app.pen_touch.pen_seen = now;
                app.pen_touch.pen_touching = !matches!(phase, egui::TouchPhase::End | egui::TouchPhase::Cancel);
            }
            Event::PointerMoved(pos) if !touch_frame && !finger_down => {
                app.pen_touch.pen_force = 1.0;
                app.pen_touch.pen_pos = Some(*pos);
                app.pen_touch.pen_seen = now;
            }
            Event::PointerGone => app.pen_touch.pen_pos = None,
            _ => {}
        }
    }
}

/// The ring's diameter: the current brush's size on screen (with the pen's pressure, when the brush
/// uses pressure for size), or the size from the settings.
fn pointer_diameter(app: &PhotocraftApp) -> f32 {
    let s = &app.pen_touch.settings;
    if s.pen_pointer_follows_brush
        && app.ui.tool.is_brushlike()
        && let Some(xf) = crate::canvas::ViewXform::active(app)
    {
        let brush = &app.session.tools.brush;
        let mut d = brush.size * xf.zoom;
        if app.pen_touch.pen_touching && brush.pressure_size {
            d *= app.pen_touch.pen_force.clamp(0.05, 1.0);
        }
        if d.is_finite() {
            return d.clamp(6.0, 800.0);
        }
    }
    s.pointer_diameter()
}

/// Draw the pointer ring where the pen is. Called at the end of the frame.
fn paint_pen_pointer(app: &PhotocraftApp, ctx: &egui::Context) {
    let s = &app.pen_touch.settings;
    let Some(pos) = app.pen_touch.pen_pos.filter(|_| s.show_pen_pointer) else { return };
    let now = ctx.input(|i| i.time);
    // A hover the platform stopped reporting (the pen left the screen) fades out.
    let age = now - app.pen_touch.pen_seen;
    if age > 1.5 && !app.pen_touch.pen_touching {
        return;
    }
    let r = pointer_diameter(app) / 2.0;
    let painter = ctx.layer_painter(egui::LayerId::new(egui::Order::Tooltip, egui::Id::new("pen-touch-pointer")));
    if app.pen_touch.pen_touching {
        painter.circle_filled(pos, r, egui::Color32::from_rgba_unmultiplied(255, 255, 255, 40));
    }
    painter.circle_stroke(pos, r, egui::Stroke::new(3.0, egui::Color32::from_black_alpha(160)));
    painter.circle_stroke(pos, r, egui::Stroke::new(1.5, egui::Color32::WHITE));
    painter.circle_filled(pos, 2.0, egui::Color32::WHITE);
    ctx.request_repaint_after(Duration::from_millis(250));
}

/// Barrel buttons: the Back/Forward mouse buttons the platform layer maps them to.
fn pen_buttons(app: &mut PhotocraftApp, ctx: &egui::Context, raw: &mut egui::RawInput, now: f64) {
    let enabled = [app.pen_touch.settings.button1.enabled, app.pen_touch.settings.button2.enabled];
    let mut events: Vec<(usize, bool)> = Vec::new();
    raw.events.retain(|e| match e {
        Event::PointerButton { button: b @ (PointerButton::Extra1 | PointerButton::Extra2), pressed, .. } => {
            let index = usize::from(*b == PointerButton::Extra2);
            if enabled[index] {
                events.push((index, *pressed));
                false
            } else {
                true
            }
        }
        _ => true,
    });
    for (index, pressed) in events {
        let outs = app.pen_touch.pen_button(index, pressed, now);
        carry_out(app, index, outs);
    }
    for index in 0..2 {
        let Some(cfg) = button_cfg(&app.pen_touch.settings, index).cloned() else { continue };
        let Some(state) = app.pen_touch.buttons.get_mut(index) else { continue };
        if !cfg.enabled {
            let outs = state.cancel();
            carry_out(app, index, outs);
            continue;
        }
        let outs = state.tick(&cfg, now);
        let waiting = state.waiting();
        carry_out(app, index, outs);
        if waiting {
            ctx.request_repaint_after(Duration::from_millis(40));
        }
    }
}

fn carry_out(app: &mut PhotocraftApp, index: usize, outs: Vec<Out>) {
    for out in outs {
        match out {
            Out::Tap(spec) if spec == RECENT => app.pen_touch.switch_recent = true,
            Out::Tap(spec) => app.pen_touch.keys.tap(&spec),
            Out::ToolKey(spec) => {
                if let Some(slot) = app.pen_touch.tool_before.get_mut(index) {
                    *slot = Some(app.ui.tool);
                }
                if let Some(slot) = app.pen_touch.tool_check.get_mut(index) {
                    *slot = Some(0);
                }
                app.pen_touch.keys.tap(&spec);
            }
            Out::RestoreTool => {
                if let Some(tool) = app.pen_touch.tool_before.get_mut(index).and_then(Option::take) {
                    app.pen_touch.restore_tool.push(tool);
                }
                if let Some(slot) = app.pen_touch.tool_check.get_mut(index) {
                    *slot = None;
                }
            }
            Out::Latch(spec) => app.pen_touch.keys.latch(&spec),
            Out::Press(spec) => app.pen_touch.keys.press(&spec),
            Out::Release(spec) => app.pen_touch.keys.release(&spec),
        }
    }
}

/// Where a finger counts as "on the canvas": inside the canvas and not over a window or popup.
/// Is this contact a stylus? The platform layer flags stylus ids. Elsewhere a contact that
/// hovered, or that presses with force, is a pen. On Android every finger reports pressure, so
/// only the id flag counts there.
fn is_pen_contact(app: &PhotocraftApp, id: u64) -> bool {
    is_pen_id(id) || (!cfg!(target_os = "android") && app.stylus.pen_contacts.is_pen(egui::TouchId(id)))
}

fn on_canvas(ctx: &egui::Context, canvas: Option<egui::Rect>, pos: egui::Pos2) -> bool {
    canvas.is_some_and(|r| r.contains(pos)) && ctx.layer_id_at(pos).is_none_or(|l| l.order == egui::Order::Background)
}

/// May a swipe that started at `pos` scroll what is there? Yes when the widget on top that takes
/// drags is a row or slider (wide, short, senses clicks too). A scroll area's own background is left to
/// egui, and so are title bars, scroll bars, resize handles and colour fields.
fn scroll_target(ctx: &egui::Context, pos: egui::Pos2) -> bool {
    let layer = ctx.layer_id_at(pos).unwrap_or_else(egui::LayerId::background);
    ctx.viewport(|v| {
        v.prev_pass
            .widgets
            .get_layer(layer)
            .filter(|w| w.enabled && w.sense.senses_drag() && w.interact_rect.contains(pos))
            .last()
            .is_some_and(|w| w.sense.senses_click() && w.rect.height() < 64.0 && w.rect.width() > w.rect.height() * 1.5)
    })
}

/// Follow the touch contacts: gestures, stylus-only mode, the finger tool.
fn touches(app: &mut PhotocraftApp, ctx: &egui::Context, raw: &mut egui::RawInput) {
    let now = raw.time.unwrap_or(0.0);
    let touch_scroll = app.pen_touch.settings.touch_scroll;
    // Events that turn a swipe on a panel into scrolling, and whether any swipe is scrolling.
    let mut inject: Vec<Event> = Vec::new();
    let mut scrolling_any = false;
    let stylus_only = app.pen_touch.settings.stylus_only();
    let canvas = crate::canvas::ViewXform::active(app).map(|x| x.rect);
    let mut blocked_seen = false;
    // The pen's own contact events this frame, for rebuilding its pointer: (id, phase, pos).
    let mut pen_events: Vec<(u64, Phase, egui::Pos2)> = Vec::new();
    let mut blocked_ids: Vec<u64> = Vec::new();
    // What a lone blocked finger moved this frame: (where it was, where it is).
    let mut one_finger: Option<(egui::Pos2, egui::Pos2)> = None;
    // A pen down before this frame counts through the frame it lifts in.
    app.pen_touch.pen_frame = app.pen_touch.contacts.iter().any(|c| c.pen);

    for e in &raw.events {
        let Event::Touch { id, phase, pos, .. } = e else { continue };
        let id = id.0;
        let pos = *pos;
        let phase = match phase {
            egui::TouchPhase::Start => Phase::Start,
            egui::TouchPhase::Move => Phase::Move,
            egui::TouchPhase::End | egui::TouchPhase::Cancel => Phase::End,
        };
        let contact = match phase {
            Phase::Start => {
                let pen = is_pen_contact(app, id);
                let blocked = stylus_only && !pen && on_canvas(ctx, canvas, pos);
                let c = Contact { id, pen, blocked, canvas: on_canvas(ctx, canvas, pos), last: pos, press: pos, started: now, scroll: false };
                app.pen_touch.contacts.retain(|x| x.id != id);
                if app.pen_touch.contacts.len() >= 16 {
                    app.pen_touch.contacts.remove(0);
                }
                app.pen_touch.contacts.push(c);
                Some(c)
            }
            _ => app.pen_touch.contact(id),
        };
        // A move for a contact never seen to start is a hovering pen, no finger.
        let Some(c) = contact else { continue };
        // A vertical swipe that starts on a row or slider of a panel or window scrolls it.
        let mut scrolling = c.scroll;
        if touch_scroll && !c.pen && !c.canvas && !c.blocked {
            let mut from = c.last;
            if phase == Phase::Move && !scrolling && now - c.started <= 0.6 {
                let d = pos - c.press;
                if d.y.abs() >= 8.0 && d.y.abs() > 1.4 * d.x.abs() && scroll_target(ctx, c.press) {
                    scrolling = true;
                    from = c.press;
                    // Let go of the press far away: the widget under it gets no click and no drag.
                    let far = pos2(-10_000.0, -10_000.0);
                    inject.push(Event::PointerMoved(far));
                    inject.push(Event::PointerButton { pos: far, button: PointerButton::Primary, pressed: false, modifiers: Default::default() });
                }
            }
            if scrolling && phase == Phase::Move {
                inject.push(Event::PointerMoved(pos));
                inject.push(Event::MouseWheel { unit: egui::MouseWheelUnit::Point, delta: pos - from, modifiers: Default::default() });
            }
            if scrolling && phase == Phase::End {
                inject.push(Event::PointerGone);
            }
            if let Some(slot) = app.pen_touch.contacts.iter_mut().find(|x| x.id == id) {
                slot.scroll = scrolling;
                if scrolling {
                    slot.last = pos;
                }
            }
        }
        scrolling_any |= scrolling;
        if phase == Phase::End {
            app.pen_touch.contacts.retain(|x| x.id != id);
        }
        app.pen_touch.gestures.touch(id, phase, [pos.x, pos.y], c.pen);
        if c.blocked
            && phase == Phase::Move
            && let Some(slot) = app.pen_touch.contacts.iter_mut().find(|x| x.id == id)
        {
            let from = std::mem::replace(&mut slot.last, pos);
            one_finger = Some(match one_finger {
                Some((first, _)) => (first, pos),
                None => (from, pos),
            });
        }
        if c.blocked {
            blocked_seen = true;
            blocked_ids.push(id);
        }
        if c.pen {
            app.pen_touch.pen_frame = true;
            pen_events.push((id, phase, pos));
        }
    }

    if scrolling_any {
        // The scrolling finger is no pointer: its own press, moves and release go, ours come.
        raw.events.retain(|e| !matches!(e, Event::PointerMoved(_) | Event::PointerButton { .. } | Event::PointerGone));
        raw.events.extend(inject);
        ctx.request_repaint();
    }

    let frame = app.pen_touch.gestures.end_frame();
    app.pen_touch.frame = Some(frame);

    finger_tool(app);

    if !stylus_only {
        app.pen_touch.synth_pen = None;
        return;
    }

    // Two fingers on the canvas move the view.
    if frame.is_gesture() && frame.moved() && canvas.is_some_and(|r| r.contains(pos2(frame.mid[0], frame.mid[1]))) {
        let blocked_pair = app.pen_touch.contacts.iter().filter(|c| c.blocked).count() >= 2;
        if blocked_pair {
            navigate(app, &frame);
            ctx.request_repaint();
        }
    }

    // One finger on the canvas pans it.
    if let Some((from, to)) = one_finger
        && !frame.is_gesture()
        && app.pen_touch.contacts.iter().filter(|c| c.blocked).count() == 1
        && from != to
    {
        let pan = gestures::Frame { scale: 1.0, rotation: 0.0, mid: [to.x, to.y], prev_mid: [from.x, from.y], ..frame };
        navigate(app, &pan);
        ctx.request_repaint();
    }

    // The tools never see a blocked finger. While one is down, egui's pointer belongs to it, so the
    // pen's pointer is rebuilt from its own touch events.
    let blocked_down = app.pen_touch.contacts.iter().any(|c| c.blocked);
    let replace = blocked_seen || blocked_down || app.pen_touch.synth_pen.is_some();
    if !replace {
        return;
    }
    raw.events.retain(|e| match e {
        Event::Touch { id, phase, .. } => matches!(phase, egui::TouchPhase::End | egui::TouchPhase::Cancel) || !blocked_ids.contains(&id.0),
        Event::PointerMoved(_) | Event::PointerButton { .. } => false,
        _ => true,
    });
    let modifiers = app.pen_touch.keys.held_modifiers();
    for (id, phase, pos) in pen_events {
        match phase {
            Phase::Start => {
                app.pen_touch.synth_pen = Some(id);
                raw.events.push(Event::PointerMoved(pos));
                raw.events.push(Event::PointerButton { pos, button: PointerButton::Primary, pressed: true, modifiers });
            }
            Phase::Move => {
                if app.pen_touch.synth_pen == Some(id) {
                    raw.events.push(Event::PointerMoved(pos));
                }
            }
            Phase::End => {
                if app.pen_touch.synth_pen == Some(id) {
                    app.pen_touch.synth_pen = None;
                    raw.events.push(Event::PointerMoved(pos));
                    raw.events.push(Event::PointerButton { pos, button: PointerButton::Primary, pressed: false, modifiers });
                }
            }
        }
    }
}

fn wrap_degrees(a: f32) -> f32 {
    let r = (a + 180.0).rem_euclid(360.0) - 180.0;
    if r.is_finite() { r } else { 0.0 }
}

/// Pan, zoom and rotate the active view by what two fingers did, keeping the document point that
/// was under their midpoint under it.
fn navigate(app: &mut PhotocraftApp, frame: &gestures::Frame) {
    let Some(index) = app.session.active_index() else { return };
    let Some(before) = crate::canvas::ViewXform::active(app) else { return };
    let Some(size) = app.session.active().map(|st| [st.doc.size.width, st.doc.size.height]) else { return };
    let s = app.pen_touch.settings.clone();
    let (prev, mid) = (pos2(frame.prev_mid[0], frame.prev_mid[1]), pos2(frame.mid[0], frame.mid[1]));
    let anchor = before.to_doc(prev);
    let flip = app.ui.view.flip_horizontal;
    {
        let Some(v) = app.ui.views.get_mut(index) else { return };
        if s.stylus_only_zoom && frame.scale.is_finite() && frame.scale > 0.0 {
            v.zoom = crate::zoom_levels::clamp(v.zoom * frame.scale, size);
        }
        if s.stylus_only_rotate && frame.rotation.is_finite() {
            let degrees = frame.rotation.to_degrees();
            v.rotation = wrap_degrees(v.rotation + if flip { -degrees } else { degrees });
        }
        v.fit_pending = false;
        v.fill_pending = false;
    }
    let Some(after) = crate::canvas::ViewXform::active(app) else { return };
    let under = after.to_doc(if s.stylus_only_pan { mid } else { prev });
    let Some(v) = app.ui.views.get_mut(index) else { return };
    let (dx, dy) = ((anchor[0] - under[0]) as f32, (anchor[1] - under[1]) as f32);
    if dx.is_finite() && dy.is_finite() {
        v.center = [v.center[0] + dx, v.center[1] + dy];
    }
}

/// An active-stylus screen: a finger is the Move tool while it is down, the pen keeps painting.
/// Not in stylus-only mode, where a finger works no tool at all.
fn finger_tool(app: &mut PhotocraftApp) {
    // Only a finger that landed on the canvas: one on a panel or window (scrolling the brush or
    // layers list) must not change the tool under it.
    let on_canvas = app.pen_touch.contacts.iter().any(|c| !c.pen && c.canvas);
    let pen_down = app.pen_touch.contacts.iter().any(|c| c.pen);
    if !app.pen_touch.settings.finger_move_on() || app.pen_touch.settings.stylus_only() || !on_canvas {
        restore_finger_tool(app);
        return;
    }
    if app.pen_touch.finger_tool_before.is_none() && !pen_down && finger_move_applies(app) {
        app.pen_touch.finger_tool_before = Some(app.ui.tool);
        app.ui.tool = Tool::Move;
    }
}

/// Put the tool back, unless the user picked another one meanwhile.
fn restore_finger_tool(app: &mut PhotocraftApp) {
    if let Some(tool) = app.pen_touch.finger_tool_before.take()
        && app.ui.tool == Tool::Move
    {
        app.ui.tool = tool;
    }
}

/// Where a finger may borrow the Move tool: not while another tool holds state a tool change would
/// end (type, transform, a pen path, a crop).
fn finger_move_applies(app: &PhotocraftApp) -> bool {
    let t = app.ui.tool;
    !(t == Tool::Move || t == Tool::Hand || t == Tool::Zoom || t.is_type() || t.is_type_mask())
        && app.ui.transform.is_none()
        && app.ui.text_edit.is_none()
        && app.ui.pen.is_none()
        && app.ui.crop_rect.is_none()
        && app.ui.polygon.is_empty()
        && app.ui.dialogs.is_empty()
        && app.session.active().is_some()
}

/// Press-and-hold is no right click while a pen is down, and (when the finger-hold option is on,
/// on an active-stylus screen) while a finger is down. With both off a held finger right-clicks as
/// egui always does. Called from `raw_input_hook` in place of the pen-only rule; `stylus_pen_down`
/// is what the generic pen detection saw (unreliable on Android, where fingers press with force).
pub(crate) fn long_press(app: &PhotocraftApp, ctx: &egui::Context, stylus_pen_down: bool) {
    let pen = if cfg!(target_os = "android") { app.pen_touch.pen_frame } else { stylus_pen_down || app.pen_touch.pen_frame };
    let finger = app.pen_touch.settings.finger_hold_on() && app.pen_touch.frame.is_some_and(|f| f.fingers > 0);
    crate::stylus::pen_hold_is_no_right_click(ctx, pen || finger);
}

/// Once per frame, before the panels: finish what the raw input started (put tools back).
pub fn apply(app: &mut PhotocraftApp, ctx: &egui::Context) {
    switch_recent_tool(app, ctx);
    // Pen button tool memory: back to the previous tool; and give up when a key changed nothing.
    for tool in std::mem::take(&mut app.pen_touch.restore_tool) {
        let _ = crate::menus::invoke(app, ctx, &crate::tool_shortcuts::id(tool), serde_json::json!({}));
    }
    for index in 0..2 {
        let Some(frames) = app.pen_touch.tool_check.get(index).copied().flatten() else { continue };
        let before = app.pen_touch.tool_before.get(index).copied().flatten();
        if frames >= 3 {
            if before == Some(app.ui.tool)
                && let Some(b) = app.pen_touch.buttons.get_mut(index)
            {
                b.disarm_toggle();
                if let Some(slot) = app.pen_touch.tool_before.get_mut(index) {
                    *slot = None;
                }
            }
            if let Some(slot) = app.pen_touch.tool_check.get_mut(index) {
                *slot = None;
            }
        } else if let Some(slot) = app.pen_touch.tool_check.get_mut(index) {
            *slot = Some(frames + 1);
        }
    }
}

/// Once per frame, after the panels: keep the settings saved and ask the start-up question.
pub fn finish(app: &mut PhotocraftApp, ctx: &egui::Context) {
    persist(app);
    ui::prompt(app, ctx);
    paint_pen_pointer(app, ctx);
}

/// Follow the tool in use, and go to the one before it when asked. A tool a finger borrows (Move
/// while it drags) is not a choice and is left out of the history.
fn switch_recent_tool(app: &mut PhotocraftApp, ctx: &egui::Context) {
    let tool = app.ui.tool;
    let borrowed = app.pen_touch.finger_tool_before.is_some();
    if !borrowed && app.pen_touch.recent[0] != Some(tool) {
        app.pen_touch.recent[1] = app.pen_touch.recent[0];
        app.pen_touch.recent[0] = Some(tool);
    }
    if !std::mem::take(&mut app.pen_touch.switch_recent) {
        return;
    }
    if let Some(previous) = app.pen_touch.recent[1].filter(|t| *t != tool) {
        let _ = crate::menus::invoke(app, ctx, &crate::tool_shortcuts::id(previous), serde_json::json!({}));
    }
}
