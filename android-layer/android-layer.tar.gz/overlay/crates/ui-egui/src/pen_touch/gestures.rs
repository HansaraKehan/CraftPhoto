//! Two-finger gestures from raw touch contacts. Pure logic (no egui): the shell feeds it every
//! touch event of a frame and reads back what the first two fingers did.
//!
//! Pen contacts are counted apart and never make a gesture, so a stylus resting on the glass
//! neither starts nor joins a pinch.

pub type Pos = [f32; 2];

/// Fingers closer than this (points) give no stable angle or ratio.
const MIN_SPAN: f32 = 12.0;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Start,
    Move,
    End,
}

#[derive(Clone, Copy, Debug, PartialEq)]
struct Finger {
    id: u64,
    pos: Pos,
}

/// What the fingers did in one frame.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Frame {
    /// Fingers (not pens) on the glass at the end of the frame.
    pub fingers: usize,
    /// A pen contact is down.
    pub pen_down: bool,
    /// Distance ratio since the last frame (1 = unchanged).
    pub scale: f32,
    /// Turn since the last frame, radians, clockwise positive on screen.
    pub rotation: f32,
    /// Midpoint of the first two fingers now (zero without a gesture).
    pub mid: Pos,
    /// Where that midpoint was at the last frame (equal to `mid` when there is no delta yet).
    pub prev_mid: Pos,
    /// The second finger came down this frame: a gesture begins.
    pub started: bool,
    /// The gesture ended this frame (fewer than two fingers now).
    pub ended: bool,
}

impl Frame {
    pub fn is_gesture(&self) -> bool {
        self.fingers >= 2
    }

    /// Did the fingers change anything this frame?
    pub fn moved(&self) -> bool {
        self.scale != 1.0 || self.rotation != 0.0 || self.mid != self.prev_mid
    }
}

#[derive(Clone, Debug, Default)]
pub struct Gestures {
    fingers: Vec<Finger>,
    pens: Vec<u64>,
    /// The two fingers, their distance, angle and midpoint at the last frame.
    last: Option<((u64, u64), f32, f32, Pos)>,
    was_gesture: bool,
}

/// Most contacts remembered (a stuck id can't grow the list without bound).
const MAX_CONTACTS: usize = 16;

fn wrap(a: f32) -> f32 {
    let r = (a + std::f32::consts::PI).rem_euclid(std::f32::consts::TAU) - std::f32::consts::PI;
    if r.is_finite() { r } else { 0.0 }
}

impl Gestures {
    pub fn fingers(&self) -> usize {
        self.fingers.len()
    }

    pub fn pen_down(&self) -> bool {
        !self.pens.is_empty()
    }

    /// One touch event. `pen`: the contact is a stylus.
    pub fn touch(&mut self, id: u64, phase: Phase, pos: Pos, pen: bool) {
        if !pos[0].is_finite() || !pos[1].is_finite() {
            return;
        }
        if pen {
            match phase {
                Phase::Start => {
                    if !self.pens.contains(&id) && self.pens.len() < MAX_CONTACTS {
                        self.pens.push(id);
                    }
                }
                Phase::Move => {}
                Phase::End => self.pens.retain(|p| *p != id),
            }
            return;
        }
        match phase {
            Phase::Start => {
                self.fingers.retain(|f| f.id != id);
                if self.fingers.len() >= MAX_CONTACTS {
                    self.fingers.remove(0);
                }
                self.fingers.push(Finger { id, pos });
            }
            Phase::Move => {
                if let Some(f) = self.fingers.iter_mut().find(|f| f.id == id) {
                    f.pos = pos;
                }
            }
            Phase::End => self.fingers.retain(|f| f.id != id),
        }
    }

    /// Everything gone (focus lost, the window hid).
    pub fn reset(&mut self) {
        *self = Self::default();
    }

    /// Close the frame: what the first two fingers did since the last one.
    pub fn end_frame(&mut self) -> Frame {
        let gesture = self.fingers.len() >= 2;
        let started = gesture && !self.was_gesture;
        let ended = !gesture && self.was_gesture;
        if started {
            self.last = None;
        }
        let (mut scale, mut rotation) = (1.0, 0.0);
        let mut mid = [0.0, 0.0];
        let mut prev_mid = mid;
        if let (true, Some(a), Some(b)) = (gesture, self.fingers.first().copied(), self.fingers.get(1).copied()) {
            let (dx, dy) = (b.pos[0] - a.pos[0], b.pos[1] - a.pos[1]);
            let dist = dx.hypot(dy);
            let angle = dy.atan2(dx);
            mid = [(a.pos[0] + b.pos[0]) / 2.0, (a.pos[1] + b.pos[1]) / 2.0];
            prev_mid = mid;
            let key = (a.id, b.id);
            if let Some((k, d0, a0, m0)) = self.last
                && k == key
            {
                prev_mid = m0;
                if dist >= MIN_SPAN && d0 >= MIN_SPAN {
                    scale = (dist / d0).clamp(0.5, 2.0);
                    rotation = wrap(angle - a0);
                }
            }
            self.last = Some((key, dist, angle, mid));
        } else {
            self.last = None;
        }
        self.was_gesture = gesture;
        Frame { fingers: self.fingers.len(), pen_down: !self.pens.is_empty(), scale, rotation, mid, prev_mid, started, ended }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn two_fingers(g: &mut Gestures, a: Pos, b: Pos) {
        g.touch(1, Phase::Start, a, false);
        g.touch(2, Phase::Start, b, false);
    }

    #[test]
    fn a_single_finger_is_no_gesture() {
        let mut g = Gestures::default();
        g.touch(1, Phase::Start, [10.0, 10.0], false);
        let f = g.end_frame();
        assert_eq!((f.fingers, f.is_gesture(), f.started), (1, false, false));
    }

    #[test]
    fn the_second_finger_starts_a_gesture_and_the_lift_ends_it() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [100.0, 0.0]);
        let f = g.end_frame();
        assert!(f.started && f.is_gesture() && !f.moved());
        assert_eq!(f.mid, [50.0, 0.0]);
        g.touch(2, Phase::End, [100.0, 0.0], false);
        let f = g.end_frame();
        assert!(f.ended && !f.is_gesture());
    }

    #[test]
    fn spreading_scales() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [100.0, 0.0]);
        g.end_frame();
        g.touch(2, Phase::Move, [150.0, 0.0], false);
        let f = g.end_frame();
        assert!((f.scale - 1.5).abs() < 1e-4 && f.rotation.abs() < 1e-4);
        assert!(f.moved());
    }

    #[test]
    fn dragging_both_fingers_pans_by_the_midpoint() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [100.0, 0.0]);
        g.end_frame();
        g.touch(1, Phase::Move, [30.0, 20.0], false);
        g.touch(2, Phase::Move, [130.0, 20.0], false);
        let f = g.end_frame();
        assert_eq!((f.prev_mid, f.mid), ([50.0, 0.0], [80.0, 20.0]));
        assert!((f.scale - 1.0).abs() < 1e-4 && f.rotation.abs() < 1e-4);
    }

    #[test]
    fn turning_rotates_clockwise_positive() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [100.0, 0.0]);
        g.end_frame();
        // The second finger swings down (screen y grows downward): clockwise.
        g.touch(2, Phase::Move, [0.0, 100.0], false);
        let f = g.end_frame();
        assert!((f.rotation - std::f32::consts::FRAC_PI_2).abs() < 1e-4);
        assert!((f.scale - 1.0).abs() < 1e-4);
    }

    #[test]
    fn rotation_takes_the_short_way_round_the_half_turn() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [-100.0, 5.0]);
        g.end_frame();
        g.touch(2, Phase::Move, [-100.0, -5.0], false);
        let f = g.end_frame();
        assert!(f.rotation.abs() < 0.2, "{}", f.rotation);
    }

    #[test]
    fn pens_never_join_a_gesture() {
        let mut g = Gestures::default();
        g.touch(1, Phase::Start, [0.0, 0.0], false);
        g.touch(9, Phase::Start, [100.0, 0.0], true);
        let f = g.end_frame();
        assert!(f.pen_down && !f.is_gesture() && f.fingers == 1);
        g.touch(9, Phase::End, [100.0, 0.0], true);
        assert!(!g.end_frame().pen_down);
    }

    #[test]
    fn a_new_finger_pair_does_not_jump() {
        let mut g = Gestures::default();
        two_fingers(&mut g, [0.0, 0.0], [100.0, 0.0]);
        g.end_frame();
        g.touch(3, Phase::Start, [50.0, 300.0], false);
        g.end_frame();
        g.touch(1, Phase::End, [0.0, 0.0], false);
        let f = g.end_frame();
        assert_eq!((f.scale, f.rotation), (1.0, 0.0));
        assert_eq!(f.mid, f.prev_mid);
    }

    #[test]
    fn hostile_input_is_ignored() {
        let mut g = Gestures::default();
        g.touch(1, Phase::Start, [f32::NAN, 0.0], false);
        g.touch(2, Phase::Start, [f32::INFINITY, 0.0], false);
        assert_eq!(g.fingers(), 0);
        for id in 0..100 {
            g.touch(id, Phase::Start, [id as f32, 0.0], false);
        }
        assert!(g.fingers() <= MAX_CONTACTS);
        let f = g.end_frame();
        assert!(f.scale.is_finite() && f.rotation.is_finite());
        let mut g = Gestures::default();
        two_fingers(&mut g, [5.0, 5.0], [5.0, 5.0]);
        g.end_frame();
        g.touch(2, Phase::Move, [50.0, 5.0], false);
        let f = g.end_frame();
        assert_eq!((f.scale, f.rotation), (1.0, 0.0));
    }
}
