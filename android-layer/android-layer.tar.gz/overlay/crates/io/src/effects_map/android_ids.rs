//! Photoshop effect keys written as stringIDs are mapped to their charIDs (Android layer).

use super::{Descriptor, Id, Value};

// Action descriptors may encode the same Photoshop key as a four-character
// charID or a stringID. Normalize known equivalents only; unknown data remains
// preserved in the original PSD block.
pub(super) fn normalize_effect_ids(d: &mut Descriptor, depth: usize) {
    if depth >= 32 {
        return;
    }
    const IDS: &[(&str, &str)] = &[
        ("dropShadow", "DrSh"),
        ("innerShadow", "IrSh"),
        ("outerGlow", "OrGl"),
        ("innerGlow", "IrGl"),
        ("bevelEmboss", "ebbl"),
        ("chromeFX", "ChFX"),
        ("solidFill", "SoFi"),
        ("gradientFill", "GrFl"),
        ("frameFX", "FrFX"),
        ("enabled", "enab"),
        ("mode", "Md  "),
        ("opacity", "Opct"),
        ("color", "Clr "),
        ("red", "Rd  "),
        ("green", "Grn "),
        ("blue", "Bl  "),
        ("distance", "Dstn"),
        ("chokeMatte", "Ckmt"),
        ("localLightingAngle", "lagl"),
        ("useGlobalAngle", "uglg"),
        ("size", "Sz  "),
        ("style", "Styl"),
        ("paintType", "PntT"),
        ("scale", "Scl "),
        ("angle", "Angl"),
        ("gradient", "Grad"),
        ("reverse", "Rvrs"),
        ("align", "Algn"),
    ];
    for (id, value) in &mut d.items {
        if let Some((_, short)) = IDS.iter().find(|(long, _)| id.is(long)) {
            *id = Id::new(short);
        }
        match value {
            Value::Descriptor(child) | Value::GlobalObject(child) => normalize_effect_ids(child, depth + 1),
            Value::List(items) => {
                for item in items {
                    if let Value::Descriptor(child) | Value::GlobalObject(child) = item {
                        normalize_effect_ids(child, depth + 1);
                    }
                }
            }
            _ => {}
        }
    }
}

