<!--
  Written for you with every android-layer zip; the workflow reads it from inside the zip.
  - The FIRST "## " section is the release notes of the next build: only what is new in it.
    It is left out of the notes if the previous release already showed it.
  - "- " lines are features: they are collected from every section into the README's feature list.
  - "* " lines are fixes and changes: shown in the release notes, not in the README.
-->
# What's new in the Android edition

## Quick tour, hover presses and a longer press window
- 🎓 **Quick tour.** The first time you start the app, a short animated tour shows the gestures and pen actions with their default actions, rings the buttons you need to tap, and ends by saying everything is customizable. Replay it from **Help → Quick tour: pen and touch…** or **Preferences → Tools → Pen & Touch → Show the quick tour**.
- ⏱️ **Longer press window.** The wait for the next press of a double or triple press is now 500 ms by default (it was 300 ms) and can be set up to 1000 ms. Saved settings that still had 300 ms move to 500 ms.
* 🖊️ Double and triple pen-button presses now work while the pen only hovers; the pen no longer has to touch the screen.
* 🔧 The Android layer follows upstream 0.20.1. The start page now uses upstream's own narrow layout, with the follow-the-developer link in place of Discord.

## v5.0 · Finger taps, new upstream
- 👆 **Two- and three-finger taps.** A quick tap of 2 or 3 fingers on the canvas runs an action. Defaults: 2 fingers = Undo, 3 fingers = Redo. Each has its own on/off switch and a custom action (a key, a combination, or *Switch between recent tools*) under Preferences → Tools → Pen & Touch → *Finger taps*. They work in Pen only mode, and on an active-stylus screen where fingers move things (never where a finger paints, so a tap can't leave a dot).
* 🔧 **Ported to upstream 59cb4c4** (egui 0.37). The Android window layer is now upstream's own winit fork plus the stylus and mouse patch.

## v4.1 · Layers scrolling
- 📜 Swiping on a Layers row, thumbnail or eye column now scrolls the list. Swipes on any short button, row, thumbnail or slider in panels and windows scroll them; title bars and scroll bars still drag.
* 🔧 Android import follows upstream's new import options.

## v4.0 · Brush-sized pointer and swipe scrolling
- ⭕ **The pen pointer ring now matches your brush automatically.** It follows the current brush size at the canvas zoom, and shrinks and grows with pen pressure when the brush uses pressure for size. Other tools use the fixed size from Preferences. Turn the matching off in Preferences → Tools → Pen & Touch → *Pen pointer*.
- 📜 **Swipe to scroll panels and windows.** A quick up or down swipe that starts on a list row or slider (Brushes, Layers and similar) now scrolls the panel instead of fighting the row. Switch: *Panels and windows* in the same settings block.
* 🔧 Ported to the newest upstream and fixed two build errors (test-only code compiled into the app, and the pointer-size equality error).

## v3.0 · Updates, press counts and the pen pointer
- 🔔 **Update checker.** The app looks for a newer build on this repository's Releases page at start (at most every 6 hours, silent offline) and offers **Download / Later / Skip this version**. The app now declares the Internet permission for this.
- 🔢 **Press-count shortcuts.** Each pen button has *Press*, *Press twice* and *Press 3 times* actions, each a key, a combination, a tool or *Switch between recent tools*. Doing the same tool press again returns to the previous tool, so double press can pick Eraser and double press again goes back. A *Next press within* setting (default 300 ms) controls the window. A hold cancels a pending count.
- ⭕ **Pen pointer ring.** Preferences → Tools → Pen & Touch → *Pen pointer*: show a ring where the pen hovers and touches, and pick its size (8–120 pt). Off by default.
- 👋 **Discord link replaced.** The start page button, the About dialog and the Help menu entry now invite people to follow the developer on GitHub (https://github.com/HansaraKehan) instead of upstream's Discord.
* 🧪 More tests for the button state machine (double and triple presses, repeat-to-go-back, hold cancelling a count).

## v2.2 · Scrolling fix
* 🐛 **Touching panels and windows no longer changes your tool.** On active-stylus devices a finger used to switch to the Move tool wherever it touched, which could rebuild the Brush or Layers window mid-scroll. Now it only happens for a finger that lands on the canvas.

## v2.1 · One-finger canvas pan
- ✋ **Pen only mode: one finger pans the canvas.** Two fingers still pan, zoom and rotate.
- The "pan" switch in Preferences now covers both one and two fingers.

## v2.0 · Soft keys, recent tools, and the finger fix
- ⌨️ **Soft keys moved into the top bar**, to the right of Layers / Options, instead of a third bar. They contract with «.
- 🔁 **Pen button 1 now switches between recent tools by default.** Press once to go to the previous tool, press again to return. Available for any pen button or soft key as *Switch between recent tools*.
* 🧹 **Undo and Redo removed from the strip** (the top bar already has them). Your saved settings are cleaned up once; keys you added yourself stay.
* 🐛 **Fingers are no longer mistaken for pens on Android.** Every finger reports pressure on Android, which made the app treat fingers as pens. That caused two bugs:
  * Pen only mode did not block fingers.
  * A held finger never right-clicked, even with the option off.
  Both are fixed. A held finger right-clicks again unless *Holding a finger stays a held press* is on.
* 🐛 Fixed a build error: simulated Ctrl/Alt/Shift now reach the editor through `ModifiersChanged` events.
* 🔧 The layer now targets the **current upstream** (0.11.1) instead of an October 15 snapshot, so the build no longer needs `UPSTREAM_REF`.
* 🧪 The hook script is anchor-based: if upstream moves the lines it edits, the build stops with a message naming the missing line instead of silently dropping a feature.

## v1.0 · First release
- 🖊️ **Pen barrel buttons.** Press and hold are separate actions, each a key or a combination. Modifier combinations latch (press to hold, press again to release).
- ⌨️ **Soft-key strip** with Ctrl, Alt, Shift, Enter and Esc, editable in Preferences, with Record and Pick helpers and a limit of 24 keys.
- 🔀 **Finger ⇄ Pen only** button for quick switching.
- 🧭 **Two-finger canvas navigation** in Pen only mode: pan, zoom and rotate about the midpoint, each with its own switch.
- 👆 **Active-stylus devices:** a finger drags items with the Move tool while the pen keeps painting; a held finger can stay a held press instead of right-clicking.
- 🧰 **Device question at start-up** (*with / without an active stylus*) with a **Don't ask again** button, also in Preferences → Tools → Pen & Touch. Devices without an active stylus never get Enter pressed for you.
- 🤖 **Android stylus support** in the window layer: barrel buttons arrive as pen buttons, and stylus tip and eraser contacts are told apart from fingers.
- 💾 All settings are saved with your preferences.
