# Pen & Touch

Stylus barrel buttons, simulated key presses, a Finger / Pen only switch, finger behaviour on
active-stylus screens and a strip of soft keys. Code: `crates/ui-egui/src/pen_touch/`. Settings:
Edit › Preferences › Tools › **Pen & Touch** (they apply at once and are stored in
`Preferences::pen_touch`). Every behaviour has its own on/off switch.

## How keys are simulated

Nothing talks to the operating system. Key events are added to egui's input before each frame, so every
shortcut PhotoCraft knows reacts exactly as to the real keyboard: tool letters, `Ctrl+T`, bindings from
Edit › Keyboard Shortcuts, temporary tools such as `Space`.

A key combination is written like any shortcut: `E`, `Ctrl+Shift+Z`, `Enter`, `Escape`, `Space`.
A combination made only of modifiers (`Ctrl`, `Alt`, `Shift`, `Ctrl+Shift`) is a **latch**: one press holds it,
the next press lets go. Held modifiers are added to everything egui receives, so a latched `Ctrl` also makes
the next touch a Ctrl-click. In every key field you can type a combination, press **Record** and press it, or use **Pick**
(basic keys, or any command that has a shortcut).

## Device

At start the app asks whether the screen has an **active stylus** or not. **Don't ask again** saves the answer
and stops the question; the same choice and an "Ask at start" switch live in Preferences.

| | Active stylus | No active stylus |
|---|---|---|
| Finger tap / drag | click / moves the item (Move tool while the finger is down; switch: "A finger tap clicks…") | paints |
| Finger held still | stays a held press, never a right click (switch) | normal |

## Pen buttons

Each of the two barrel buttons has a **press** action and a **hold** action:

* **Press** (released before the hold time): sends the keys. A tool key such as `E` remembers the tool it left; **press
  again** goes back to the previous tool ("Press again returns to the previous tool" switch). A modifier-only press latches.
* **Hold** (kept down past "Hold after", default 350 ms): the keys go down and stay down as long as the button is held
  (for example `Space` for the Hand tool, `Alt` for the eyedropper, `Ctrl` for Move).
* With no hold action the press fires the moment the button goes down.

Defaults: button 1 = press `E`, hold `Space`; button 2 off (press `Ctrl+Z`, hold `Alt` once enabled).

## Finger / Pen only

The **Finger / Pen only** button under the menu bar (also in Preferences) switches quickly.

* **Finger**: fingers and pen both work the tools.
* **Pen only**: a finger that lands on the canvas never draws or moves anything. **Two fingers pan, zoom and rotate the
  canvas** about their midpoint (each of the three has a switch). Fingers on panels, menus and floating windows
  still work. If a palm rests on the canvas, the pen keeps drawing.

## Soft keys

The strip under the menu bar holds buttons that simulate keys; `«` contracts it to a thin handle (the Finger / Pen only
switch stays). Defaults: `Ctrl`, `Alt`, `Shift` (tap to hold, tap again to let go), `Enter`, `Esc`, `Undo`, `Redo`.
Other keys are pressed while you touch them, so holding `Space` works. Add, remove, rename and re-key them in
Preferences (up to 24); the `…` button opens that page.

## Platform notes

* The barrel buttons arrive as the mouse's Back (button 1) and Forward (button 2). The Android layer maps
  `BUTTON_STYLUS_PRIMARY` and `BUTTON_STYLUS_SECONDARY` to them, and marks a stylus touch with `PEN_TOUCH_FLAG` in its touch
  id. Other backends can call `PenTouch::pen_button(index, pressed, now)`.
* A desktop mouse's side buttons also trigger a pen button while that button is enabled.
