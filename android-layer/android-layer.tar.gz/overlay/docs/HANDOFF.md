# Handoff: PhotoCraft Android Pen & Touch edition

Paste the **Starter prompt** (bottom) into a new chat, and attach this file plus the latest
`android-layer.tar.gz`. Everything the assistant needs to continue is below.

## 1. What this project is

* Repo: `https://github.com/HansaraKehan/CraftPhoto` (a fork of `storytold/photocraft`, a Rust / egui /
  wgpu Photoshop-style editor). The owner works **only in the GitHub web UI** (no IDE, no git CLI, no
  local build) and builds the Android APK with a GitHub Actions workflow.
* The workflow `.github/workflows/android-release.yml` does **not** build the fork's own source. It:
  1. checks out the fork (for `android-layer/` and `WHATS-NEW.md`) into `fork/`,
  2. checks out upstream `storytold/photocraft` (ref = input `ref`, else repository variable
     `UPSTREAM_REF`, else `main`) into `src/`,
  3. extracts `fork/android-layer/android-layer.tar.gz`, runs `git apply --3way android-layer.patch`
     (failure = "The Android patch no longer applies"), copies `overlay/` over the tree, runs
     `translate_en.py` (which first runs `pen_touch_integrate.py`),
  4. builds `photocraft-android` for aarch64, signs the APK, publishes a GitHub release with
     automatic notes (the newest `WHATS-NEW.md` section + upstream commits since the last release).
* Tag format `android-v<VERSION>-<upstream sha7>`; a forced rebuild of the same sha adds `-r<run>`.
* Version code = minutes since 1970 at build time (used by the in-app update checker).

## 2. The layer (`android-layer/android-layer.tar.gz`)

```
android-layer.patch      Android edits to upstream (panels, canvas, dialogs, menus, type tool...).
                         Made against an upstream commit; breaks when upstream edits the same lines.
translate_en.py          Translates Chinese UI strings to English, adds Help > updates link, then
                         runs pen_touch_integrate.py first.
overlay/                 Files copied over upstream after the patch:
  crates/ui-egui/src/pen_touch/   mod.rs settings.rs buttons.rs virtual_keys.rs gestures.rs ui.rs
  pen_touch_integrate.py          anchor-based insertions into lib.rs, prefs_ui.rs, stylus.rs,
                                  engine prefs.rs, desktop main.rs, + Discord rebranding
  apps/photocraft-android/        Android shell (android.rs top bar with soft keys, etc.)
  vendor/winit/...                Android winit with stylus buttons + stylus touch-id flags
  packaging/android/              AndroidManifest.xml (INTERNET permission), Java:
                                  PhotoCraftActivity.java, FileBrowserBridge.java, UpdateChecker.java
  docs/pen-touch.md
```

## 3. Features and defaults (the owner's requirements)

* Pen barrel buttons 1 and 2 arrive as mouse Back/Forward. Each has Press, Press twice, Press 3 times
  (window `multi_ms`, default 300), and Hold (separate action while held, default 350 ms). Each action is a key,
  a combination (`Ctrl+Shift+Z`), a modifier latch (`Ctrl`: press holds, press again releases), or
  `@recent` (switch between the last two tools). "Doing the same tool press again returns to the
  previous tool" (`tap_toggles_back`).
  Defaults: button 1 press = `@recent`, hold = `Space`; button 2 off (Ctrl+Z / Alt).
* Soft keys in the Android top bar (right of Layers/Options): Finger / Pen only toggle, Ctrl, Alt, Shift,
  Enter, Esc (no Undo/Redo: the top bar has them), a contract handle `«`, and a `…` editor. Modifiers latch.
* Device question at start (with an active stylus / without) with "Don't ask again", also in
  Preferences > Tools > Pen & Touch. Without an active stylus nothing presses Enter for you.
* Active-stylus devices: a finger on the **canvas** borrows the Move tool; a held finger stays a held
  press (no right click) only when that option is on. Each behaviour has its own switch.
* Pen only mode: fingers never draw; one finger pans the canvas, two fingers pan/zoom/rotate
  (each switchable). Fingers on panels/menus/windows work normally.
* Pen pointer ring (optional): follows the pen hover/touch; matches the brush size at the view zoom and
  pen pressure by default; fixed size fallback.
* Swipe scrolling: a quick vertical swipe on a list row or slider scrolls panels/windows (switchable).
* Update checker (`UpdateChecker.java`): at start, at most every 6 h, asks GitHub for the latest release
  of `HansaraKehan/CraftPhoto`; dialog with Download / Later / Skip this version.
* Branding: the upstream Discord invite (start page, About, Help menu) is replaced by
  "Follow the developer on GitHub" -> `https://github.com/HansaraKehan`. License and attribution notices
  must stay (MIT / Apache-2.0).
* Release notes are automatic: newest `## ` section of `WHATS-NEW.md` + upstream commits.

## 4. The owner's rules (follow these)

* Never ask the owner to use git, an IDE or a terminal. Instructions are for the **GitHub web UI**
  (upload/replace a file, run the workflow from the right branch, repository variables).
* Deliver one drop-in file whenever possible: `android-layer.tar.gz` (plus `README.md`,
  `WHATS-NEW.md`, `android-release.yml` when they change). Put each file's exact path in the message.
* When the owner ships a change, **write a new top section for `WHATS-NEW.md`** (same format).
* Don't ask clarifying questions when a sensible default exists; state the assumption.
* Be honest about what is untested. Nothing can be compiled in the assistant's sandbox (crates.io is
  unreachable), so the owner's GitHub build is the first compile. Ask for the **first error lines
  with their `-->` file/line** from the failed log.
* Keep answers short; say what changed and what to do next.

## 5. How to port the layer when upstream breaks the patch

The assistant's sandbox can reach github.com for git clone (not crates.io).

1. `git clone https://github.com/storytold/photocraft up` (full history). Find the commit the
   old patch was made against (the one where `git apply --check android-layer.patch` passes; scan
   commits by date near the patch's date).
2. Branch `layer` at that commit, apply the patch, commit. Branch `merged` from it, `git merge origin/main`,
   resolve conflicts keeping **both** sides (Android behaviour on top of upstream's new code), commit.
3. New patch = `git diff origin/main merged`. Test: fresh clone of `origin/main`, `git apply --3way`,
   copy `overlay/`, run `pen_touch_integrate.py` (must print `ok`), grep for leftover `<<<<<<<`.
4. **Lessons from earlier breaks**
   * Keep `#[cfg(test)]` on test-only `#[path = "..._tests.rs"] mod` lines when joining conflict sides
     (a lost marker compiled `egui_kittest` into the app).
   * egui 0.36: `RawInput` has no `modifiers` (use `Event::ModifiersChanged`). `f32` fields cannot
     derive `Eq`.
   * On Android every finger reports pressure: treat a touch as a pen only by the stylus touch-id flag
     (`PEN_TOUCH_FLAG` 1<<48, `ERASER_TOUCH_FLAG` 1<<49 set by the vendored winit).
   * Fingers must not change tools when they touch panels (only canvas touches borrow Move).
   * Upstream's panel ScrollAreas give drags to click_and_drag rows/sliders: touch scrolling there needs the
     swipe-to-wheel conversion in `pen_touch::touches`.
5. Repackage: `tar -czf android-layer.tar.gz --owner=0 --group=0 ./android-layer.patch ./translate_en.py ./overlay`
   (the three entries must be at the archive root).

## 6. Known open points / ideas

* All of v2-v4 code is uncompiled until the owner's build runs; expect small compile fixes.
* The swipe-scroll heuristic (wide, short click+drag widget, vertical swipe within 0.6 s) is unproven on
  device. If it misfires, tune `scroll_target` / thresholds in `pen_touch/mod.rs`.
* Not done: a manual "Check for updates now" button; per-tool pointer styling; rotating/transforming a
  selection by touch (dropped by the owner).
* `UPSTREAM_REF` can pin a known-good upstream commit while the patch is ported.

## 7. Starter prompt for a new chat

> I maintain an Android edition of PhotoCraft at github.com/HansaraKehan/CraftPhoto, built by the GitHub
> Actions workflow `android-release.yml` from upstream `storytold/photocraft` plus
> `android-layer/android-layer.tar.gz`. I only use the GitHub web UI. I have attached HANDOFF.md (read it
> first: it explains the layer, my rules, features and how to port the patch) and my current
> `android-layer.tar.gz`. My request: <WHAT YOU WANT>. Deliver a drop-in `android-layer.tar.gz` and a new
> `WHATS-NEW.md` section, and tell me exactly which files to replace where. If my build fails I will paste
> the first error lines.


## Update (upstream 59cb4c4, egui 0.37)
* `vendor/winit` is now upstream's winit fork (storytold/winit a517b38) with our Android patch merged in (`src/lib.rs`, `platform_impl/android/{mod,keycodes,input_state}.rs`); `Cargo.toml` keeps upstream's egui fork patches and points only `winit` to `vendor/winit`.
* eframe is built with `wgpu` only on Android (no `clipboard`); AccessKit stays desktop-only.
* `Event::MouseWheel` now needs `source: MouseWheelSource::Unknown`.
* Android import closure uses `ImportOptions` (`import_with_options`).
* New `pen_touch/taps.rs`: 2/3 finger taps (`tap2`, `tap3` settings, defaults Ctrl+Z / Ctrl+Shift+Z).


## Update (upstream d42f9da)
* Upstream split many files into folders. The layer's edits now live in: `panels/{toolbar,layers,layer_row,layer_drag}.rs`, `prefs/prefs_ui/{appearance,fields,dialogs}.rs`, `tools/type_tool/options_bar.rs`, `dialogs/new_doc_ui.rs`, `canvas/start_screen.rs`, `menus/{bar,render}.rs`, `engine/src/prefs/validate.rs`.
* `pen_touch_integrate.py` anchors: `lib.rs`, `app.rs`, `app/frame.rs`, `prefs/prefs_ui/{startup,fields}.rs`, `input/stylus.rs`. `translate_en.py` lists the new file paths.
* The layer's own unit tests for the old UI-size, compact new-document and touch-layer code were dropped in the port (they only run in `cargo test`).


## Port to upstream 1f984bf
Merged canvas.rs (paint_canvas now takes `&paint_input`), dialogs.rs (upstream split into `dialog_body`/`button_row`/`default_max_width`; the compact New Document, UI-size settings and pin tweaks were re-applied there) and panels/layer_row.rs (upstream split into `eye_column`, `select_row_on_click`, `handle_row_double_click`, `row_context_menu`; the touch gesture code was re-applied on top). The patch was regenerated with `git diff origin/main HEAD`; a fresh clone applies it and `translate_en.py` prints `pen_touch_integrate: ok`.
