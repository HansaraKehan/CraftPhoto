<div align="center">

# 🎨 PhotoCraft · Android Pen & Touch Edition

**A Photoshop-style editor on your tablet, built for a stylus.**
Barrel-button actions · on-screen modifier keys · pen-only drawing · finger canvas navigation

[What's new](../../releases) · [Get the app](#-get-the-app) · [Settings guide](#-settings-guide) · [Troubleshooting](#-troubleshooting)

</div>

---

## ✨ Highlights

| | Feature | What it does |
|---|---|---|
| 🖊️ | **Pen barrel buttons** | Press the button for one action, hold it for another. Both can be key combinations. |
| 🔁 | **Recent-tool switch** | Press the pen button once to jump to your previous tool, press again to come back. |
| ⌨️ | **Soft keys in the top bar** | Ctrl, Alt, Shift, Enter, Esc and any shortcut you choose, always one tap away. The bar contracts when you don't need it. |
| 🔒 | **Latching modifiers** | Tap Ctrl/Alt/Shift once to hold it, tap again to release. Works from the pen button too. |
| ✋ | **Finger ⇄ Pen only** | One button switches modes. In Pen only mode fingers never draw. |
| 🧭 | **Finger navigation** | In Pen only mode: one finger pans the canvas, two fingers pan, zoom and rotate it. |
| 👆 | **Active-stylus mode** | On devices with an active stylus, a finger drags items and the pen paints. |
| 🔢 | **Press counts** | Single, double and triple presses of a pen button each run their own action (a tool, a key, a combination). |
| ⭕ | **Pen pointer ring** | Optional ring that follows the pen while it hovers and touches. It matches the current brush size automatically, pressure included. |
| 👆 | **Finger taps** | Tap with 2 fingers to Undo and with 3 fingers to Redo, or give each its own action or switch it off. |
| 🎓 | **Quick tour** | A first-launch walkthrough with small animations; replay it from Help → Quick tour or Preferences → Tools → Pen & Touch. |
| 📜 | **Swipe scrolling** | A quick vertical swipe on a list row or slider scrolls panels and windows. |
| 🔔 | **Update checker** | Tells you when a new build is on this repository's Releases page. |
| ⚙️ | **Everything is switchable** | Each behaviour has its own on/off switch in Preferences. |

---

## 📲 Get the app

This repository builds an Android APK on GitHub — no computer or IDE needed.

1. Open the **Actions** tab → **Android release** → **Run workflow**.
2. Choose the branch that holds your `android-layer/android-layer.tar.gz`.
3. Leave **Publish a release** on to get a GitHub Release (with notes). Switch it **off** to only build: the APK appears under **Artifacts** on the run page and nothing is released.
4. When the run finishes, download the APK from **Releases** (or the run's **Artifacts**) and install it.

> 💡 **How it works:** the workflow downloads the latest upstream
> [PhotoCraft](https://github.com/storytold/photocraft), applies the Android layer from
> `android-layer/android-layer.tar.gz` on top, and builds the result. Your features, the way the layer is
> applied and each release's "what's new" all live inside that one file, so the workflow file rarely changes.

### 🔔 Update notifications

When the app starts it quietly asks GitHub for the newest release of this repository (at most every
6 hours; nothing happens offline). If a newer build exists, a dialog offers **Download**, **Later** or
**Skip this version**. Download opens the APK in your browser. Android asks you to allow the install
the first time. *Help → Get the Android app / updates…* opens the Releases page any time.

### Staying up to date

* The layer follows upstream's newest code. Most of it is separate files plus one-line hooks, and the patch part is applied file by file with fallbacks. If upstream still changes something the layer cannot absorb, the run stops with **"The Android patch no longer applies"** and lists the files. Send me the log and the layer gets ported again.
* Each release's notes show only the Android features that are new in it, then what changed upstream since the previous release.
* To freeze a known-good version, add a repository variable `UPSTREAM_REF` (Settings → Secrets and variables → Actions → Variables) set to an upstream commit hash. Delete it to follow the latest upstream again.

---

## 🖐️ How it feels to use

### Pen button
| You do | Default action |
|---|---|
| **Press** pen button 1 | Switch to the previous tool. Press again to go back. |
| **Hold** pen button 1 | Holds **Space** (pan the canvas) for as long as you hold it. |
| **Press twice / three times** | Not set by default. Give each its own action in Preferences. |
| Pen button 2 | Off by default. Press = `Ctrl+Z`, hold = `Alt` once enabled. |

Any action can be a single key (`E`), a combination (`Ctrl+Shift+Z`), a modifier latch (`Ctrl`), or the
special **Switch between recent tools**.

### Top-bar strip
```
« │ Finger │ Ctrl │ Alt │ Shift │ Enter │ Esc │ …
```
* **«** contracts the strip; **»** brings it back. The Finger / Pen only button always stays.
* **Ctrl / Alt / Shift** latch: lit = held.
* Other keys are pressed while your finger is on them (hold Space to pan, quick tap for one press).
* **…** opens the soft-key editor.

### Finger vs. Pen only
| Mode | Pen | One finger | Two fingers |
|---|---|---|---|
| **Finger** | Draws | Draws | Tool-dependent |
| **Pen only** | Draws | **Pans** the canvas | **Pan, zoom, rotate** the canvas |

Fingers on panels, menus and windows always work normally in both modes.

---

## ⚙️ Settings guide

Open **Preferences → Tools → Pen & Touch**. Changes apply immediately.

| Setting | Meaning |
|---|---|
| **Device** | *With an active stylus* or *Without*. Asked at start-up (with **Don't ask again**). Fingers-move behaviour and the held-finger option need an active stylus. |
| **Pen button 1 / 2** | Enable, choose the press action and the hold action, set the hold delay. |
| **Press twice / Press 3 times** | Extra actions for quick repeat presses. *Next press within* sets how long the app waits for the next press (default 500 ms). Doing the same tool press again returns to the previous tool. |
| **Pen pointer** | *Show a pointer ring where the pen is*; *Match the brush size automatically* (default on); *Size for other tools*. Off by default. |
| **Panels and windows** | *Swipe up or down on a list row or slider to scroll*. On by default. |
| **Input mode** | Finger or Pen only (same as the top-bar button). |
| **Two fingers zoom / rotate / pan** | Turn each canvas gesture on or off. |
| **A finger tap clicks and a drag moves the item** | Active-stylus devices: fingers borrow the Move tool, the pen keeps painting. |
| **Holding a finger stays a held press** | Active-stylus devices: no right-click on a held finger. Off = a held finger right-clicks. |
| **Soft keys** | Show/hide the strip; add, rename, remove or reset keys. Each key accepts a key combination. |

### Key combination cheat sheet
| Write | Result |
|---|---|
| `E` | Press E |
| `Ctrl+Shift+Z` | Redo |
| `Ctrl` or `Alt+Shift` | Latch: first press holds, next press releases |
| `Space` | Pressed while the button is held |
| `@recent` | Switch between the last two tools |
| Press twice → `E` | Double press selects Eraser; double press again goes back |

Use **Record** to capture a key by pressing it, or **Pick** to choose from the list of commands.

---

## 🛠️ Troubleshooting

| Problem | Try this |
|---|---|
| **Build says the patch no longer applies** | Upstream changed. Set `UPSTREAM_REF` to a good commit, or send the log to have the layer ported. |
| **Build fails with a Rust error** | Copy the first red `error[...]` lines from the failed run and send them. |
| **Pen button does nothing** | Check *Use this button* is on for that button in Preferences → Tools → Pen & Touch. |
| **Fingers still draw in Pen only mode** | Confirm the strip shows **Pen only** (highlighted). Fingers on panels are meant to work. |
| **A window won't scroll by touch** | Turn off *A finger tap clicks and a drag moves the item* and test again. Report which windows are affected. |
| **Wrong device question at start** | Change it under Preferences → Tools → Pen & Touch → Device. |

---

## 🧱 What's inside

```
android-layer/
└── android-layer.tar.gz
    ├── android-layer.patch       Android edits to upstream (layout, touch UI, dialogs)
    ├── translate_en.py           Runs after the patch; also hooks the pen & touch module in
    └── overlay/
        ├── crates/ui-egui/src/pen_touch/   Pen buttons, soft keys, modes, settings
        ├── vendor/winit/…                  Stylus support for the Android window layer
        └── apps/photocraft-android/…       The Android app shell and top bar
```

More detail: [`docs/pen-touch.md`](docs/pen-touch.md).

---

## ℹ️ Status

This edition is under active testing. The code was written without a local compiler, so each build is
the first real test — expect a few fix-up rounds. Bug reports with build logs or a short description
of what happened are very welcome.

## 👋 Follow the developer

The start page and the Help menu carry a **Follow the developer on GitHub** button for
[HansaraKehan](https://github.com/HansaraKehan), who maintains this Android edition. Stars, issues and
build logs are welcome.

## 📜 Credits & licence

PhotoCraft is © its authors, dual-licensed MIT / Apache-2.0 — see `LICENSE-MIT`, `LICENSE-APACHE` and
`ATTRIBUTION.md`; keep those notices when you redistribute. This is an unofficial build, not made or supported by the PhotoCraft team. The Android layer and the Pen & Touch module are provided under the same terms.

## 🆕 Android features

Kept up to date automatically from each release.

<!-- android-features:start -->
- 🎓 **Quick tour.** The first time you start the app, a short animated tour shows the gestures and pen actions with their default actions, rings the buttons you need to tap, and ends by saying everything is customizable. Replay it from **Help → Quick tour: pen and touch…** or **Preferences → Tools → Pen & Touch → Show the quick tour**.
- ⏱️ **Longer press window.** The wait for the next press of a double or triple press is now 500 ms by default (it was 300 ms) and can be set up to 1000 ms. Saved settings that still had 300 ms move to 500 ms.
- 👆 **Two- and three-finger taps.** A quick tap of 2 or 3 fingers on the canvas runs an action. Defaults: 2 fingers = Undo, 3 fingers = Redo. Each has its own on/off switch and a custom action (a key, a combination, or *Switch between recent tools*) under Preferences → Tools → Pen & Touch → *Finger taps*. They work in Pen only mode, and on an active-stylus screen where fingers move things (never where a finger paints, so a tap can't leave a dot).
- 📜 Swiping on a Layers row, thumbnail or eye column now scrolls the list. Swipes on any short button, row, thumbnail or slider in panels and windows scroll them; title bars and scroll bars still drag.
- ⭕ **The pen pointer ring now matches your brush automatically.** It follows the current brush size at the canvas zoom, and shrinks and grows with pen pressure when the brush uses pressure for size. Other tools use the fixed size from Preferences. Turn the matching off in Preferences → Tools → Pen & Touch → *Pen pointer*.
- 📜 **Swipe to scroll panels and windows.** A quick up or down swipe that starts on a list row or slider (Brushes, Layers and similar) now scrolls the panel instead of fighting the row. Switch: *Panels and windows* in the same settings block.
- 🔔 **Update checker.** The app looks for a newer build on this repository's Releases page at start (at most every 6 hours, silent offline) and offers **Download / Later / Skip this version**. The app now declares the Internet permission for this.
- 🔢 **Press-count shortcuts.** Each pen button has *Press*, *Press twice* and *Press 3 times* actions, each a key, a combination, a tool or *Switch between recent tools*. Doing the same tool press again returns to the previous tool, so double press can pick Eraser and double press again goes back. A *Next press within* setting (default 300 ms) controls the window. A hold cancels a pending count.
- ⭕ **Pen pointer ring.** Preferences → Tools → Pen & Touch → *Pen pointer*: show a ring where the pen hovers and touches, and pick its size (8–120 pt). Off by default.
- 👋 **Discord link replaced.** The start page button, the About dialog and the Help menu entry now invite people to follow the developer on GitHub (https://github.com/HansaraKehan) instead of upstream's Discord.
- ✋ **Pen only mode: one finger pans the canvas.** Two fingers still pan, zoom and rotate.
- The "pan" switch in Preferences now covers both one and two fingers.
- ⌨️ **Soft keys moved into the top bar**, to the right of Layers / Options, instead of a third bar. They contract with «.
- 🔁 **Pen button 1 now switches between recent tools by default.** Press once to go to the previous tool, press again to return. Available for any pen button or soft key as *Switch between recent tools*.
- 🖊️ **Pen barrel buttons.** Press and hold are separate actions, each a key or a combination. Modifier combinations latch (press to hold, press again to release).
- ⌨️ **Soft-key strip** with Ctrl, Alt, Shift, Enter and Esc, editable in Preferences, with Record and Pick helpers and a limit of 24 keys.
- 🔀 **Finger ⇄ Pen only** button for quick switching.
- 🧭 **Two-finger canvas navigation** in Pen only mode: pan, zoom and rotate about the midpoint, each with its own switch.
- 👆 **Active-stylus devices:** a finger drags items with the Move tool while the pen keeps painting; a held finger can stay a held press instead of right-clicking.
- 🧰 **Device question at start-up** (*with / without an active stylus*) with a **Don't ask again** button, also in Preferences → Tools → Pen & Touch. Devices without an active stylus never get Enter pressed for you.
- 🤖 **Android stylus support** in the window layer: barrel buttons arrive as pen buttons, and stylus tip and eraser contacts are told apart from fingers.
- 💾 All settings are saved with your preferences.
<!-- android-features:end -->
