<div align="center">

# 🎨 PhotoCraft · Android Pen & Touch Edition

**A Photoshop-style editor on your tablet, built for a stylus.**
Barrel-button actions · on-screen modifier keys · pen-only drawing · finger canvas navigation

[What's new](WHATS-NEW.md) · [Get the app](#-get-the-app) · [Settings guide](#-settings-guide) · [Troubleshooting](#-troubleshooting)

</div>

---

## ✨ Highlights

| | Feature | What it does |
|---|---|---|
| 🖊️ | **Pen barrel buttons** | Press the button for one action, hold it for another. Both can be key combinations. |
| 🔁 | **Recent-tool switch** | Press the pen button once to jump to your previous tool, press again to come back. |
| ⌨️ | **Soft keys in the top bar** | Ctrl, Alt, Shift, Enter, Esc and any shortcut you choose, always one tap away. The bar contracts when you don't need it. |
| 🔒 | **Latching modifiers** | Tap Ctrl/Alt/Shift once to hold it, tap again to release. Works from the pen button too. |
| ✋ | **Finger ⇄ Pen only** | One button switches modes. In Pen only mode fingers never draw. |
| 🧭 | **Finger navigation** | In Pen only mode: one finger pans the canvas, two fingers pan, zoom and rotate it. |
| 👆 | **Active-stylus mode** | On devices with an active stylus, a finger drags items and the pen paints. |
| 🔢 | **Press counts** | Single, double and triple presses of a pen button each run their own action (a tool, a key, a combination). |
| ⭕ | **Pen pointer ring** | Optional ring that follows the pen while it hovers and touches. It matches the current brush size automatically, pressure included. |
| 👆 | **Finger taps** | Tap with 2 fingers to Undo and with 3 fingers to Redo, or give each its own action or switch it off. |
| 🎓 | **Quick tour** | A first-launch walkthrough with small animations; replay it from Help → Quick tour or Preferences → Tools → Pen & Touch. |
| 📜 | **Swipe scrolling** | A quick vertical swipe on a list row or slider scrolls panels and windows. |
| 🔔 | **Update checker** | Tells you when a new build is on this repository's Releases page. |
| ⚙️ | **Everything is switchable** | Each behaviour has its own on/off switch in Preferences. |

---

## 📲 Get the app

This repository builds an Android APK on GitHub — no computer or IDE needed.

1. Open the **Actions** tab → **Android release** → **Run workflow**.
2. Choose the branch that holds your `android-layer/android-layer.tar.gz`.
3. When the run finishes, download the APK from **Releases** (or the run's artifacts) and install it.

> 💡 **How it works:** the workflow downloads the latest upstream
> [PhotoCraft](https://github.com/storytold/photocraft), applies the Android layer from
> `android-layer/android-layer.tar.gz` on top, and builds the result. Your features live in that
> one file.

### 🔔 Update notifications

When the app starts it quietly asks GitHub for the newest release of this repository (at most every
6 hours; nothing happens offline). If a newer build exists, a dialog offers **Download**, **Later** or
**Skip this version**. Download opens the APK in your browser. Android asks you to allow the install
the first time. *Help → Get the Android app / updates…* opens the Releases page any time.

### Staying up to date

* The layer follows upstream's newest code. If upstream changes the same lines the layer edits, the run stops with
  **"The Android patch no longer applies"**. Send me the log and the layer gets ported again.
* To freeze a known-good version, add a repository variable `UPSTREAM_REF` (Settings → Secrets and variables → Actions → Variables) set to an upstream commit hash. Delete it to follow the latest upstream again.

---

## 🖐️ How it feels to use

### Pen button
| You do | Default action |
|---|---|
| **Press** pen button 1 | Switch to the previous tool. Press again to go back. |
| **Hold** pen button 1 | Holds **Space** (pan the canvas) for as long as you hold it. |
| **Press twice / three times** | Not set by default. Give each its own action in Preferences. |
| Pen button 2 | Off by default. Press = `Ctrl+Z`, hold = `Alt` once enabled. |

Any action can be a single key (`E`), a combination (`Ctrl+Shift+Z`), a modifier latch (`Ctrl`), or the
special **Switch between recent tools**.

### Top-bar strip
```
« │ Finger │ Ctrl │ Alt │ Shift │ Enter │ Esc │ …
```
* **«** contracts the strip; **»** brings it back. The Finger / Pen only button always stays.
* **Ctrl / Alt / Shift** latch: lit = held.
* Other keys are pressed while your finger is on them (hold Space to pan, quick tap for one press).
* **…** opens the soft-key editor.

### Finger vs. Pen only
| Mode | Pen | One finger | Two fingers |
|---|---|---|---|
| **Finger** | Draws | Draws | Tool-dependent |
| **Pen only** | Draws | **Pans** the canvas | **Pan, zoom, rotate** the canvas |

Fingers on panels, menus and windows always work normally in both modes.

---

## ⚙️ Settings guide

Open **Preferences → Tools → Pen & Touch**. Changes apply immediately.

| Setting | Meaning |
|---|---|
| **Device** | *With an active stylus* or *Without*. Asked at start-up (with **Don't ask again**). Fingers-move behaviour and the held-finger option need an active stylus. |
| **Pen button 1 / 2** | Enable, choose the press action and the hold action, set the hold delay. |
| **Press twice / Press 3 times** | Extra actions for quick repeat presses. *Next press within* sets how long the app waits for the next press (default 500 ms). Doing the same tool press again returns to the previous tool. |
| **Pen pointer** | *Show a pointer ring where the pen is*; *Match the brush size automatically* (default on); *Size for other tools*. Off by default. |
| **Panels and windows** | *Swipe up or down on a list row or slider to scroll*. On by default. |
| **Input mode** | Finger or Pen only (same as the top-bar button). |
| **Two fingers zoom / rotate / pan** | Turn each canvas gesture on or off. |
| **A finger tap clicks and a drag moves the item** | Active-stylus devices: fingers borrow the Move tool, the pen keeps painting. |
| **Holding a finger stays a held press** | Active-stylus devices: no right-click on a held finger. Off = a held finger right-clicks. |
| **Soft keys** | Show/hide the strip; add, rename, remove or reset keys. Each key accepts a key combination. |

### Key combination cheat sheet
| Write | Result |
|---|---|
| `E` | Press E |
| `Ctrl+Shift+Z` | Redo |
| `Ctrl` or `Alt+Shift` | Latch: first press holds, next press releases |
| `Space` | Pressed while the button is held |
| `@recent` | Switch between the last two tools |
| Press twice → `E` | Double press selects Eraser; double press again goes back |

Use **Record** to capture a key by pressing it, or **Pick** to choose from the list of commands.

---

## 🛠️ Troubleshooting

| Problem | Try this |
|---|---|
| **Build says the patch no longer applies** | Upstream changed. Set `UPSTREAM_REF` to a good commit, or send the log to have the layer ported. |
| **Build fails with a Rust error** | Copy the first red `error[...]` lines from the failed run and send them. |
| **Pen button does nothing** | Check *Use this button* is on for that button in Preferences → Tools → Pen & Touch. |
| **Fingers still draw in Pen only mode** | Confirm the strip shows **Pen only** (highlighted). Fingers on panels are meant to work. |
| **A window won't scroll by touch** | Turn off *A finger tap clicks and a drag moves the item* and test again. Report which windows are affected. |
| **Wrong device question at start** | Change it under Preferences → Tools → Pen & Touch → Device. |

---

## 🧱 What's inside

```
android-layer/
└── android-layer.tar.gz
    ├── android-layer.patch       Android edits to upstream (layout, touch UI, dialogs)
    ├── translate_en.py           Runs after the patch; also hooks the pen & touch module in
    └── overlay/
        ├── crates/ui-egui/src/pen_touch/   Pen buttons, soft keys, modes, settings
        ├── vendor/winit/…                  Stylus support for the Android window layer
        └── apps/photocraft-android/…       The Android app shell and top bar
```

More detail: [`docs/pen-touch.md`](docs/pen-touch.md).

---

## ℹ️ Status

This edition is under active testing. The code was written without a local compiler, so each build is
the first real test — expect a few fix-up rounds. Bug reports with build logs or a short description
of what happened are very welcome.

## 👋 Follow the developer

The start page and the Help menu carry a **Follow the developer on GitHub** button for
[HansaraKehan](https://github.com/HansaraKehan), who maintains this Android edition. Stars, issues and
build logs are welcome.

## 📜 Credits & licence

PhotoCraft is © its authors, dual-licensed MIT / Apache-2.0 — see `LICENSE-MIT`, `LICENSE-APACHE` and
`ATTRIBUTION.md`; keep those notices when you redistribute. This is an unofficial build, not made or supported by the PhotoCraft team. The Android layer and the Pen & Touch module are provided under the same terms.
