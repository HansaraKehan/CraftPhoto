#!/usr/bin/env python3
"""Put the Android layer on top of an upstream checkout. Run it with the upstream checkout as the
working directory. It lives inside android-layer.tar.gz, so improving it never needs a workflow edit.

1. Apply android-layer.patch. Whole patch first (`git apply --3way`); if that fails, file by file:
   3-way merge, then GNU `patch` with fuzz (it ignores up to 3 lines of changed context, which is
   what most upstream drift is). A file that still fails is reported by name.
2. Copy overlay/ (files the layer adds) and run translate_en.py, which also runs the anchor-based
   integration (pen_touch_integrate.py) and reports any anchor that moved.
"""
import pathlib
import re
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()


def run(*cmd, check=False, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def apply_patch() -> list[str]:
    patch = HERE / "android-layer.patch"
    if run("git", "apply", "--3way", "--whitespace=nowarn", str(patch)).returncode == 0:
        print("patch: applied cleanly")
        return []
    run("git", "reset", "-q", "--hard")
    text = patch.read_text(encoding="utf-8", errors="surrogateescape")
    chunks = re.split(r"(?m)^(?=diff --git )", text)
    failed: list[str] = []
    fuzzed: list[str] = []
    tmp = ROOT / ".layer-chunk.patch"
    for chunk in chunks:
        m = re.match(r"diff --git a/(\S+) b/(\S+)", chunk)
        if not m:
            continue
        name = m.group(2)
        tmp.write_text(chunk, encoding="utf-8", errors="surrogateescape")
        if run("git", "apply", "--3way", "--whitespace=nowarn", str(tmp)).returncode == 0:
            continue
        run("git", "checkout", "-q", "--", name)
        run("git", "reset", "-q", "--", name)
        r = run("patch", "-p1", "-F3", "--batch", "--no-backup-if-mismatch", "-i", str(tmp))
        rej = pathlib.Path(name + ".rej")
        if r.returncode == 0 and not rej.exists():
            fuzzed.append(name)
            continue
        run("git", "checkout", "-q", "--", name)
        for stray in (rej, pathlib.Path(name + ".orig")):
            if stray.exists():
                stray.unlink()
        failed.append(name)
    tmp.unlink(missing_ok=True)
    for name in fuzzed:
        print(f"patch: {name} applied with fuzz (upstream changed nearby; check it compiles)")
    return failed


def main() -> int:
    failed = apply_patch()
    if failed:
        print("::error::The Android patch no longer applies to this upstream version.")
        print("Files with conflicts:")
        for name in failed:
            print(name)
        return 1
    shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
    shutil.copy(HERE / "translate_en.py", ROOT / "translate_en.py")
    return subprocess.call([sys.executable, "translate_en.py"])


if __name__ == "__main__":
    sys.exit(main())
